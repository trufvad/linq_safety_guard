import glob
import logging
import os

from .base import Detection, DetectionResult, InferenceEngine, Timings
from .engines import OnnxEngine, RemoteTpuEngine, TpuEngine, TpuSimEngine

log = logging.getLogger(__name__)


def tpu_available(cfg) -> tuple[bool, str]:
    """Есть ли физический LinQ TPU: модуль pytpu, устройство /dev/tpu* и файл .tpu."""
    try:
        import pytpu  # noqa: F401
    except Exception:  # noqa: BLE001
        return False, "модуль pytpu не установлен"
    if not glob.glob("/dev/tpu*"):
        return False, "устройство /dev/tpu* не найдено"
    if not os.path.isfile(cfg.tpu_program):
        return False, f"нет файла модели {cfg.tpu_program}"
    return True, "ok"


def create_engine(cfg) -> InferenceEngine:
    """ENGINE=auto|tpu|onnx|tpu_sim|remote — переключение без правок кода конвейера.

    auto: LinQ TPU, если он доступен, иначе ONNX Runtime на CPU/GPU. Ошибка при
    открытии TPU тоже приводит к откату на ONNX — проект запускается на любой машине.
    """
    common = dict(
        labels=cfg.labels, input_size=cfg.input_size,
        conf_thres=min(cfg.conf_thres, getattr(cfg, "phone_conf", cfg.conf_thres)),   # общий порог — в конвейере
        iou_thres=cfg.iou_thres, keep_classes=cfg.keep_class_ids,
    )
    kind = cfg.engine.lower()
    if kind == "auto":
        ok, reason = tpu_available(cfg)
        if ok:
            try:
                eng = TpuEngine(cfg.tpu_program, input_name=cfg.input_name, **common)
                log.info("ENGINE=auto -> LinQ TPU (%s)", cfg.tpu_program)
                return eng
            except Exception as e:  # noqa: BLE001
                log.warning("ENGINE=auto: TPU не открылся (%s), откат на ONNX", e)
        else:
            log.info("ENGINE=auto: TPU недоступен (%s) -> ONNX Runtime", reason)
        return OnnxEngine(cfg.model_path, **common)
    if kind == "onnx":
        return OnnxEngine(cfg.model_path, **common)
    if kind == "tpu":
        return TpuEngine(cfg.tpu_program, input_name=cfg.input_name, **common)
    if kind == "tpu_sim":
        return TpuSimEngine(cfg.model_path, cfg.tpu_program, **common)
    if kind == "remote":
        return RemoteTpuEngine(cfg.remote_url, input_name=cfg.input_name, **common)
    raise ValueError(f"unknown ENGINE={cfg.engine}")


__all__ = ["Detection", "DetectionResult", "InferenceEngine", "Timings", "create_engine", "tpu_available",
           "OnnxEngine", "TpuEngine", "TpuSimEngine", "RemoteTpuEngine"]
