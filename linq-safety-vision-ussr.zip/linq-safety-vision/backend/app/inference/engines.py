"""Конкретные движки: ONNX Runtime, LinQ TPU (pytpu), эмуляция TPU, удалённый TPU-воркер."""
from __future__ import annotations

import io
import logging
import threading
from contextlib import ExitStack
from typing import Dict

import numpy as np

from .base import InferenceEngine


log = logging.getLogger(__name__)


def _check_tpu(program_path: str, engine: InferenceEngine):
    """Читает паспорт .tpu, подхватывает имя входа и громко сообщает о проблемах."""
    from .tpu_meta import read_tpu_info

    info = read_tpu_info(program_path, engine.input_size, len(engine.labels))
    if info.inputs:
        engine.input_name = info.inputs[0].name
    engine.warnings = list(info.warnings)
    log.info("tpu model %s: kind=%s inputs=%s outputs=%s", program_path, info.kind,
             [(i.name, i.shape) for i in info.inputs], [(o.name, o.shape) for o in info.outputs])
    for w in info.warnings:
        log.error("TPU MODEL PROBLEM: %s", w)
    return info


class OnnxEngine(InferenceEngine):
    """Локальная отладка на CPU/GPU, пока Участник 1 собирает .tpu."""

    name = "onnxruntime"

    def __init__(self, model_path: str, **kw) -> None:
        import onnxruntime as ort

        self.session = ort.InferenceSession(
            model_path, providers=["CUDAExecutionProvider", "CPUExecutionProvider"]
            if "CUDAExecutionProvider" in ort.get_available_providers() else ["CPUExecutionProvider"],
        )
        inp = self.session.get_inputs()[0]
        kw.setdefault("input_name", inp.name)
        super().__init__(**kw)
        self._dtype = np.float16 if "float16" in inp.type else np.float32
        self._outputs = [o.name for o in self.session.get_outputs()]
        self._lock = threading.Lock()

    def _infer(self, inputs: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        feed = {k: v.astype(self._dtype) for k, v in inputs.items()}
        with self._lock:
            res = self.session.run(self._outputs, feed)
        return dict(zip(self._outputs, res))


class TpuEngine(InferenceEngine):
    """LinQ TPU через pytpu (запускать на машине с /dev/tpu*).

    Программа загружается один раз и держится открытой; вызовы sync()
    сериализуются локом — один ускоритель обслуживает все камеры по очереди.
    """

    name = "linq_tpu"

    def __init__(self, program_path: str, device_index: int = 0, **kw) -> None:
        super().__init__(**kw)
        self.model_info = _check_tpu(program_path, self)
        import pytpu as tpu  # доступен только на сервере хакатона

        devices = tpu.Device.list_devices()
        if not devices:
            raise RuntimeError("TPU not found, check `ls /dev/tpu*`")
        self._stack = ExitStack()
        dev = self._stack.enter_context(tpu.Device.open(devices[device_index]))
        prog = self._stack.enter_context(dev.load(program_path))
        self._inference = self._stack.enter_context(prog.inference())
        self._lock = threading.Lock()

    def _infer(self, inputs: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        with self._lock:
            return self._inference.sync(inputs)

    def close(self) -> None:
        self._stack.close()


class TpuSimEngine(OnnxEngine):
    """Эмуляция TPU на обычном компьютере: ONNX + квантование выходов шкалами из .tpu.

    Работает, если выходы ONNX совпадают по форме с выходами .tpu (полный граф
    с output0, или обрезанный ONNX с тремя головами). Нужен, чтобы до сервера
    увидеть, как int8 на выходе повлияет на детекции.
    """

    name = "linq_tpu_sim"

    def __init__(self, model_path: str, program_path: str, **kw) -> None:
        import json
        import zipfile

        super().__init__(model_path, **kw)
        self.model_info = _check_tpu(program_path, self)
        with zipfile.ZipFile(program_path) as z:
            meta = json.loads(z.read("metadata.json"))
        self._qparams = {}
        for group in meta["outputs"].values():
            for name, v in group.items():
                scales = np.asarray(v["scales"], np.float32).reshape(v.get("scale_shape") or [1])
                zp = np.asarray(v.get("zero_points") or [0.0], np.float32).reshape(scales.shape)
                self._qparams[tuple(v["user_shape"])] = (scales, zp)

    def _infer(self, inputs):
        out = super()._infer(inputs)
        res = {}
        for k, v in out.items():
            qp = self._qparams.get(tuple(v.shape))
            if qp is None:
                res[k] = v
                continue
            s, zp = qp                                     # выход: x = q * scale
            q = np.clip(np.round(v.astype(np.float32) / s + zp), -128, 127)
            res[k] = (q - zp) * s
        return res


class RemoteTpuEngine(InferenceEngine):
    """Бэкенд крутится у нас, TPU — на сервере LinQ (tpu_worker/server.py).

    Тензор уходит как .npy, ответ приходит как .npz со всеми выходами.
    """

    name = "linq_tpu_remote"

    def __init__(self, url: str, timeout: float = 5.0, **kw) -> None:
        super().__init__(**kw)
        import requests

        self._session = requests.Session()
        self._url = url.rstrip("/") + "/infer"
        self._timeout = timeout

    def _infer(self, inputs: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        buf = io.BytesIO()
        np.save(buf, inputs[self.input_name], allow_pickle=False)
        r = self._session.post(self._url, data=buf.getvalue(), timeout=self._timeout,
                               headers={"Content-Type": "application/octet-stream",
                                        "X-Input-Name": self.input_name})
        r.raise_for_status()
        with np.load(io.BytesIO(r.content), allow_pickle=False) as z:
            return {k: z[k] for k in z.files}
