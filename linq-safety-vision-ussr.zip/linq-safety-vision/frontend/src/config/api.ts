const DEFAULT_API_URL = 'http://localhost:8000'

/**
 * Адрес Backend.
 *  - `same-origin` (по умолчанию в Docker и start-скриптах): запросы идут на тот же адрес,
 *    с которого открыт интерфейс, а nginx / Vite проксируют /api и /ws на Backend.
 *    Работает с любого компьютера в сети без перенастройки.
 *  - Полный URL (`http://192.168.1.20:8000`): прямое подключение к Backend.
 */
function resolveApiUrl() {
  const configured = (import.meta.env.VITE_API_URL ?? '').trim()
  if (configured === 'same-origin' || (configured === '' && typeof window !== 'undefined' && import.meta.env.PROD)) {
    return window.location.origin
  }
  return configured || DEFAULT_API_URL
}

export const API_URL = resolveApiUrl().replace(/\/+$/, '')

export function getCameraStreamUrl(camera_id: string) {
  return `${API_URL}/api/cameras/${encodeURIComponent(camera_id)}/stream.mjpg`
}

export function getCameraFrameUrl(camera_id: string, annotated = false) {
  const suffix = annotated ? '?annotated=true' : ''
  return `${API_URL}/api/cameras/${encodeURIComponent(camera_id)}/frame.jpg${suffix}`
}

export function getIncidentSnapshotUrl(incident: { snapshot_url: string }) {
  return new URL(incident.snapshot_url, `${API_URL}/`).toString()
}

export function getEventsWebSocketUrl() {
  const url = new URL(API_URL)
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:'
  url.pathname = '/ws/events'
  url.search = ''
  return url.toString()
}
