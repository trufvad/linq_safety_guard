#!/usr/bin/env bash
# macOS: двойной щелчок по этому файлу запускает LinQ Safety Vision в Терминале.
cd "$(dirname "$0")" && exec ./start.sh "$@"
