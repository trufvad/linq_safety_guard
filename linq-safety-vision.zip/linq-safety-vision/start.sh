#!/usr/bin/env bash
# LinQ Safety Vision — запуск одной командой (Linux / macOS / WSL).
#
#   ./start.sh           запустить (Python, если есть; иначе Docker) и открыть браузер
#   ./start.sh docker    запустить в Docker
#   ./start.sh stop      остановить Docker-контейнер
#   ./start.sh logs      логи Docker-контейнера
#   ./start.sh reset     очистить журнал, статистику, камеры и загруженные видео
#   ./start.sh linq      на сервере LinQ (Jupyter): инференс строго на TPU + ссылка через прокси Jupyter
#   ./start.sh worker    на сервере LinQ: только TPU-воркер (интерфейс работает на ноутбуке, ENGINE=remote)
#   PYTHON=python3.11 ./start.sh   — явно выбрать Python
#
# Всё работает на одном адресе: http://localhost:8000 (порт меняется в .env: PORT=…)
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
MODE="${1:-auto}"

c_ok=$'\033[32m'; c_warn=$'\033[33m'; c_err=$'\033[31m'; c_b=$'\033[1m'; c_0=$'\033[0m'
info() { echo "${c_b}▸${c_0} $*"; }
ok()   { echo "${c_ok}✔${c_0} $*"; }
warn() { echo "${c_warn}!${c_0} $*"; }
die()  { echo "${c_err}✖ $*${c_0}" >&2; exit 1; }

# ── подготовка: .env и рабочие папки ────────────────────────────────────────
[ -f .env ] || { cp .env.example .env; ok "создан файл настроек .env"; }
mkdir -p data uploads models .run
envval() { grep -E "^$1=" .env 2>/dev/null | tail -1 | cut -d= -f2- | sed 's/[[:space:]]*#.*//; s/^["'\'']//; s/["'\'']$//'; }
PORT="$(envval PORT)"; PORT="${PORT:-8000}"
URL="http://localhost:${PORT}"

open_target() {  # открыть адрес или файл в браузере по умолчанию
  local target="$1"
  if command -v wslview >/dev/null 2>&1; then wslview "$target" >/dev/null 2>&1 || true
  elif grep -qi microsoft /proc/version 2>/dev/null && command -v cmd.exe >/dev/null 2>&1; then
    [ -e "$target" ] && command -v wslpath >/dev/null 2>&1 && target="$(wslpath -w "$target")"
    cmd.exe /c start "" "$target" >/dev/null 2>&1 || true
  elif command -v open >/dev/null 2>&1 && [ "$(uname)" = "Darwin" ]; then open "$target" >/dev/null 2>&1 || true
  elif command -v xdg-open >/dev/null 2>&1 && { [ -n "${DISPLAY:-}" ] || [ -n "${WAYLAND_DISPLAY:-}" ]; }; then
    xdg-open "$target" >/dev/null 2>&1 || true
  fi
}

# Страница запуска открывается сразу и сама переходит в программу, когда сервер готов
open_loading_page() {
  echo "window.LINQ_PORT=${PORT};" > .run/port.js
  open_target "$ROOT/frontend/loading.html"
}

# Остановить процесс, слушающий наш порт (старую копию программы)
stop_running_copy() {
  local pids=""
  if command -v lsof >/dev/null 2>&1; then pids="$(lsof -t -iTCP:"$PORT" -sTCP:LISTEN 2>/dev/null || true)"
  elif command -v fuser >/dev/null 2>&1; then pids="$(fuser -n tcp "$PORT" 2>/dev/null || true)"
  elif command -v ss >/dev/null 2>&1; then pids="$(ss -ltnpH "sport = :$PORT" 2>/dev/null | grep -o 'pid=[0-9]*' | cut -d= -f2 | sort -u)"
  fi
  # трогаем только процессы Python (наш сервер), а не, например, проброс портов Docker
  local p mine=""
  for p in $pids; do
    ps -o args= -p "$p" 2>/dev/null | grep -qi -E "python|uvicorn" && mine="$mine $p"
  done
  pids="$mine"
  [ -z "${pids// /}" ] && return 0
  kill $pids 2>/dev/null || true
  for _ in $(seq 1 10); do port_busy || return 0; sleep 0.5; done
  kill -9 $pids 2>/dev/null || true; sleep 1
}

reset_data() {
  if port_busy; then info "останавливаю запущенную программу…"; stop_running_copy; fi
  echo "Будут удалены: журнал нарушений, статистика, снимки, подключённые камеры и загруженные видео."
  read -r -p "Очистить все данные? [y/N] " answer
  case "$answer" in
    [yYдД]*) rm -rf data uploads; mkdir -p data uploads; ok "данные очищены, запустите ./start.sh" ;;
    *) echo "отменено" ;;
  esac
}

wait_http() {  # wait_http URL секунд [pid]
  local url="$1" t="${2:-60}" pid="${3:-}"
  for _ in $(seq 1 "$t"); do
    if command -v curl >/dev/null 2>&1; then curl -fsS -o /dev/null "$url" 2>/dev/null && return 0
    else python3 -c "import urllib.request,sys; urllib.request.urlopen(sys.argv[1], timeout=2)" "$url" 2>/dev/null && return 0
    fi
    [ -n "$pid" ] && ! kill -0 "$pid" 2>/dev/null && return 1   # процесс упал — не ждём зря
    sleep 1
  done
  return 1
}

port_busy() {
  command -v curl >/dev/null 2>&1 && curl -s -o /dev/null --max-time 1 "http://127.0.0.1:${PORT}/"
}

find_python() {
  for py in ${PYTHON:-} python3.12 python3.11 python3.13 python3.10 python3 python; do
    if command -v "$py" >/dev/null 2>&1 && "$py" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' 2>/dev/null; then
      echo "$py"; return 0
    fi
  done
  return 1
}

have_docker() { command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1 && docker info >/dev/null 2>&1; }

# ── Docker ──────────────────────────────────────────────────────────────────
run_docker() {
  info "сборка и запуск контейнера (первый раз — несколько минут)…"
  docker compose up --build -d
  info "жду готовности…"
  wait_http "${URL}/api/health" 180 || { docker compose logs --tail 60 app; die "сервис не поднялся"; }
  ok "готово: ${c_b}${URL}${c_0}"
  echo "   остановить: ./start.sh stop     логи: ./start.sh logs"
}

# ── Python ─────────────────────────────────────────────────────────────────
run_python() {
  local PY="$1"
  ok "Python: $($PY --version 2>&1)"

  # venv с доступом к системным пакетам: на сервере LinQ так виден предустановленный pytpu
  if [ ! -x .venv/bin/python ]; then
    info "создаю виртуальное окружение (.venv)…"
    "$PY" -m venv --system-site-packages .venv \
      || die "не удалось создать окружение. Ubuntu/Debian: sudo apt install python3-venv"
  fi
  local VPY=".venv/bin/python" stamp=".venv/.requirements.sha" h
  h="$(cksum backend/requirements.txt | cut -d' ' -f1)"
  if [ "${SKIP_INSTALL:-0}" != "1" ] && [ "$(cat "$stamp" 2>/dev/null)" != "$h" ]; then
    info "первый запуск: устанавливаю компоненты (2–5 минут, нужен интернет)…"
    "$VPY" -m pip install --upgrade pip -q || true
    if [ -d wheels ] && ls wheels/*.whl >/dev/null 2>&1; then
      info "ставлю компоненты из папки wheels/ (без интернета)…"
      "$VPY" -m pip install --no-index --find-links wheels -r backend/requirements.txt -q \
        || die "в папке wheels/ не хватает пакетов для этой версии Python ($($VPY --version 2>&1))"
    else
      "$VPY" -m pip install -r backend/requirements.txt -q \
        || die "не удалось установить зависимости — проверьте интернет (или положите пакеты в wheels/, см. LINQ_DEPLOY.md)"
    fi
    echo "$h" > "$stamp"
  fi
  ok "компоненты установлены"

  if port_busy; then
    if curl -fsS -o /dev/null --max-time 2 "http://127.0.0.1:${PORT}/api/health" 2>/dev/null; then
      info "найдена ранее запущенная копия программы — перезапускаю…"
      stop_running_copy
    fi
    port_busy && die "порт ${PORT} занят другой программой. Укажите другой порт в .env: PORT=…"
  fi

  [ -f .run/app.log ] && mv -f .run/app.log .run/app.prev.log   # лог прошлого запуска сохраняем отдельно
  info "запускаю LinQ Safety Vision (лог: .run/app.log)…"
  ( cd backend && DATA_DIR=../data DB_PATH=../data/events.db UPLOADS_DIR=../uploads FRONTEND_DIST=../frontend/dist \
      exec ../.venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port "$PORT" ) > .run/app.log 2>&1 &
  local PID=$!
  trap 'echo; info "останавливаю…"; kill "$PID" 2>/dev/null; wait "$PID" 2>/dev/null; ok "остановлено"; exit 0' INT TERM HUP
  if ! wait_http "${URL}/api/health" 120 "$PID"; then
    tail -n 30 .run/app.log; kill "$PID" 2>/dev/null || true; die "не запустилось, подробности выше и в .run/app.log"
  fi
  ok "движок нейросети: $(grep -a -o 'engine: [a-z_]*' .run/app.log | tail -1 | cut -d' ' -f2)"
  echo
  ok "${c_b}готово: ${URL}${c_0}"
  echo "   (программа открыта в браузере; остановить — Ctrl+C или закрыть это окно)"
  wait "$PID" || { tail -n 20 .run/app.log; die "программа завершилась с ошибкой, см. .run/app.log"; }
}

case "$MODE" in
  auto|docker|local|python|linq)
    # старая копия программы (например, прошлая версия) — останавливаем ДО открытия браузера,
    # иначе страница запуска успеет переключиться на старый интерфейс
    if port_busy && curl -fsS -o /dev/null --max-time 2 "http://127.0.0.1:${PORT}/api/health" 2>/dev/null; then
      info "найдена ранее запущенная копия программы — перезапускаю…"
      stop_running_copy
    fi
    open_loading_page ;;
esac

# ── сервер LinQ (JupyterHub) ────────────────────────────────────────────────
jupyter_url() {  # адрес порта через прокси Jupyter, если мы внутри JupyterHub
  local port="$1"
  if [ -n "${JUPYTERHUB_SERVICE_PREFIX:-}" ]; then
    echo "${LINQ_HUB_URL:-https://hackathon.lin-q.ru}${JUPYTERHUB_SERVICE_PREFIX%/}/proxy/${port}/"
  else
    echo "http://<адрес-сервера>:${port}/"
  fi
}

run_linq() {
  PY="$(find_python)" || die "нужен Python 3.10+"
  "$PY" -c "import pytpu" 2>/dev/null || warn "модуль pytpu не найден в $PY — запускайте из терминала Jupyter LinQ"
  ls /dev/tpu* >/dev/null 2>&1 || warn "устройство /dev/tpu* не найдено — проверьте, что вы на сервере с ускорителем"
  export ENGINE=tpu                               # строго ускоритель: без тихого отката на CPU
  ok "режим LinQ: ENGINE=tpu, модель ${TPU_PROGRAM:-models/yolov5s_cut_b1_o1_h1m.tpu}"
  echo "   откройте в браузере (VPN должен быть подключён):"
  echo "   ${c_b}$(jupyter_url "$PORT")${c_0}"
  run_python "$PY"
}

run_worker() {
  PY="$(find_python)" || die "нужен Python 3.10+"
  "$PY" -c "import pytpu, numpy" 2>/dev/null || die "нужны pytpu и numpy — запускайте из терминала Jupyter LinQ"
  local wport="${WORKER_PORT:-8500}" prog="${TPU_PROGRAM:-models/yolov5s_cut_b1_o1_h1m.tpu}"
  ok "TPU-воркер: $prog, порт $wport"
  echo "   на ноутбуке в .env:"
  echo "     ENGINE=remote"
  echo "     REMOTE_URL=$(jupyter_url "$wport" | sed 's#/$##')"
  echo "     REMOTE_TOKEN=<API-токен из JupyterHub: File → Hub Control Panel → Token>"
  exec "$PY" tpu_worker/server.py --program "$prog" --host 0.0.0.0 --port "$wport"
}

case "$MODE" in
  linq) run_linq ;;
  worker) run_worker ;;
  reset) reset_data ;;
  stop) docker compose down; ok "остановлено" ;;
  logs) docker compose logs -f --tail 100 ;;
  docker) have_docker || die "Docker не найден или не запущен"; run_docker ;;
  local|python) PY="$(find_python)" || die "нужен Python 3.10+"; run_python "$PY" ;;
  auto)
    if PY="$(find_python)"; then run_python "$PY"
    elif have_docker; then ok "Python не найден, запускаю в Docker"; run_docker
    else
      die "нужен Python 3.10+ или Docker.
   macOS:          brew install python   (или https://www.python.org/downloads/)
   Ubuntu/Debian:  sudo apt install python3 python3-venv
   затем снова: ./start.sh"
    fi ;;
  *) die "неизвестная команда '$MODE'. Используйте: ./start.sh [linq|worker|docker|stop|logs|reset]" ;;
esac
