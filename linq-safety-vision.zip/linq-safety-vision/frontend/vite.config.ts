import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig, loadEnv } from 'vite'

// В режиме разработки Vite проксирует /api и /ws на Backend, поэтому интерфейс
// работает с VITE_API_URL=same-origin так же, как за nginx в Docker.
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '.', '')
  const backend = env.BACKEND_URL || 'http://localhost:8000'

  return {
    // относительные пути к assets: интерфейс работает и на localhost, и за прокси Jupyter (/user/.../proxy/PORT/)
    base: './',
    plugins: [react(), tailwindcss()],
    server: {
      host: true,
      port: Number(env.FRONTEND_PORT || 3000),
      proxy: {
        '/api': { target: backend, changeOrigin: true },
        '/ws': { target: backend.replace(/^http/, 'ws'), ws: true, changeOrigin: true },
      },
    },
    preview: { host: true, port: Number(env.FRONTEND_PORT || 3000) },
  }
})
