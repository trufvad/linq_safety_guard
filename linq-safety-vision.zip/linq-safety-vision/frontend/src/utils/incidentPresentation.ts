import type { IncidentStatus, Severity } from '../types/api'

export const incidentStatusLabels: Record<IncidentStatus, string> = {
  new: 'Новое',
  confirmed: 'Подтверждено',
  false: 'Ложное',
  escalated: 'Передано мастеру',
  resolved: 'Завершено',
}

export const severityLabels: Record<Severity, string> = {
  critical: 'Критический',
  warning: 'Предупреждение',
  info: 'Информация',
}

export function formatIncidentTime(started_at: string) {
  const date = new Date(started_at)
  if (Number.isNaN(date.getTime())) return '—'

  return new Intl.DateTimeFormat('ru-RU', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }).format(date)
}

export function formatIncidentDateTime(started_at: string) {
  const date = new Date(started_at)
  if (Number.isNaN(date.getTime())) return '—'

  return new Intl.DateTimeFormat('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date)
}
