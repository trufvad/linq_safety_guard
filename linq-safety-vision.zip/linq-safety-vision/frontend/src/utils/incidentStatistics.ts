import type { Incident, IncidentStatus, StatisticsSummary } from '../types/api'

export type StatisticsPeriod = 'today' | '7days' | '30days' | 'all'

export const STATISTICS_TIME_ZONE = 'Europe/Moscow'

const datePartsFormatter = new Intl.DateTimeFormat('en-CA', {
  timeZone: STATISTICS_TIME_ZONE,
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
  hourCycle: 'h23',
})

function getDateParts(date: Date) {
  const parts = Object.fromEntries(
    datePartsFormatter
      .formatToParts(date)
      .filter((part) => part.type !== 'literal')
      .map((part) => [part.type, Number(part.value)]),
  )

  return {
    year: parts.year,
    month: parts.month,
    day: parts.day,
    hour: parts.hour,
    minute: parts.minute,
    second: parts.second,
  }
}

function zonedStartOfDay(date: Date, daysAgo: number) {
  const current = getDateParts(date)
  const target = new Date(Date.UTC(current.year, current.month - 1, current.day - daysAgo))
  const targetUtc = Date.UTC(target.getUTCFullYear(), target.getUTCMonth(), target.getUTCDate())
  let result = targetUtc

  // Две итерации учитывают смещение выбранной зоны и возможный переход летнего времени.
  for (let index = 0; index < 2; index += 1) {
    const zoned = getDateParts(new Date(result))
    const offset =
      Date.UTC(zoned.year, zoned.month - 1, zoned.day, zoned.hour, zoned.minute, zoned.second) -
      result
    result = targetUtc - offset
  }

  return result
}

export function getStatisticsPeriodRange(period: StatisticsPeriod, now = new Date()) {
  if (period === 'all') return {}
  const daysAgo = period === 'today' ? 0 : period === '7days' ? 6 : 29

  const formatInTimeZone = (date: Date) => {
    const parts = getDateParts(date)
    const localAsUtc = Date.UTC(
      parts.year,
      parts.month - 1,
      parts.day,
      parts.hour,
      parts.minute,
      parts.second,
    )
    const offsetMinutes = Math.round((localAsUtc - date.getTime()) / 60000)
    const sign = offsetMinutes >= 0 ? '+' : '-'
    const absoluteOffset = Math.abs(offsetMinutes)
    const offsetHours = String(Math.floor(absoluteOffset / 60)).padStart(2, '0')
    const offsetRemainder = String(absoluteOffset % 60).padStart(2, '0')

    return `${parts.year}-${String(parts.month).padStart(2, '0')}-${String(parts.day).padStart(2, '0')}T${String(parts.hour).padStart(2, '0')}:${String(parts.minute).padStart(2, '0')}:${String(parts.second).padStart(2, '0')}${sign}${offsetHours}:${offsetRemainder}`
  }

  return {
    date_from: formatInTimeZone(new Date(zonedStartOfDay(now, daysAgo))),
    date_to: formatInTimeZone(now),
  }
}

export function filterIncidentsByPeriod(
  incidents: Incident[],
  period: StatisticsPeriod,
  now = new Date(),
) {
  if (period === 'all') return incidents

  const range = getStatisticsPeriodRange(period, now)
  const periodStart = new Date(range.date_from!).getTime()

  return incidents.filter((incident) => {
    const startedAt = new Date(incident.started_at).getTime()
    return Number.isFinite(startedAt) && startedAt >= periodStart && startedAt <= now.getTime()
  })
}

function increment(map: Map<string, number>, key: string) {
  map.set(key, (map.get(key) ?? 0) + 1)
}

export function calculateIncidentStatistics(incidents: Incident[]): StatisticsSummary {
  const byType = new Map<string, { title: string; n: number }>()
  const byCamera = new Map<string, { camera_name: string; n: number }>()
  const byArea = new Map<string, number>()
  const byStatus = new Map<IncidentStatus, number>()
  const byDay = new Map<string, number>()
  const heatmap = Array.from({ length: 7 }, () => Array<number>(24).fill(0))
  const shifts = [0, 0, 0]

  incidents.forEach((incident) => {
    const date = new Date(incident.started_at)
    if (Number.isNaN(date.getTime())) return

    const parts = getDateParts(date)
    const day = `${parts.year}-${String(parts.month).padStart(2, '0')}-${String(parts.day).padStart(2, '0')}`
    const weekday = (new Date(Date.UTC(parts.year, parts.month - 1, parts.day)).getUTCDay() + 6) % 7

    const type = byType.get(incident.violation_type)
    byType.set(incident.violation_type, {
      title: incident.title || incident.violation_type,
      n: (type?.n ?? 0) + 1,
    })

    const camera = byCamera.get(incident.camera_id)
    byCamera.set(incident.camera_id, {
      camera_name: incident.camera_name || incident.camera_id,
      n: (camera?.n ?? 0) + 1,
    })

    increment(byArea, incident.area || '—')
    byStatus.set(incident.status, (byStatus.get(incident.status) ?? 0) + 1)
    increment(byDay, day)
    heatmap[weekday][parts.hour] += 1
    shifts[Math.floor(parts.hour / 8)] += 1
  })

  return {
    total: incidents.length,
    by_type: Array.from(byType, ([violation_type, value]) => ({ violation_type, ...value })).sort(
      (first, second) => second.n - first.n,
    ),
    by_camera: Array.from(byCamera, ([camera_id, value]) => ({ camera_id, ...value })).sort(
      (first, second) => second.n - first.n,
    ),
    by_area: Array.from(byArea, ([area, n]) => ({ area, n })).sort(
      (first, second) => second.n - first.n,
    ),
    by_status: Array.from(byStatus, ([status, n]) => ({ status, n })),
    by_day: Array.from(byDay, ([day, n]) => ({ day, n })).sort((first, second) =>
      first.day.localeCompare(second.day),
    ),
    by_shift: [
      { shift: 'night (00-08)', n: shifts[0] },
      { shift: 'day (08-16)', n: shifts[1] },
      { shift: 'evening (16-24)', n: shifts[2] },
    ],
    heatmap,
  }
}

export function getStatusCount(summary: StatisticsSummary, status: IncidentStatus) {
  return summary.by_status.find((item) => item.status === status)?.n ?? 0
}
