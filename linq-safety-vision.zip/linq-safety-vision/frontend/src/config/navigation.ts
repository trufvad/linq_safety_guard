import { BarChart3, Cctv, MonitorDot, type LucideIcon } from 'lucide-react'

export interface NavigationItem {
  label: string
  path: string
  icon: LucideIcon
}

export const navigationItems: NavigationItem[] = [
  { label: 'Мониторинг', path: '/monitoring', icon: MonitorDot },
  { label: 'Настройка камер', path: '/cameras', icon: Cctv },
  { label: 'Журнал и аналитика', path: '/analytics', icon: BarChart3 },
]
