const DEFAULT_API_URL = 'http://localhost:8000'

/**
 * Адрес Backend.
 *  - `same-origin` (по умолчанию в Docker и start-скриптах): запросы идут на тот же адрес,
 *    с которого открыт интерфейс, а nginx / Vite проксируют /api и /ws на Backend.
 *    Работает с любого компьютера в сети без перенастройки.
 *  - Полный URL (`http://192.168.1.20:8000`): прямое подключение к Backend.
 */
/**
 * Префикс пути, если программа открыта через прокси Jupyter на сервере LinQ:
 * https://hackathon.lin-q.ru/user/<LOGIN>/proxy/8000/monitoring -> "/user/<LOGIN>/proxy/8000".
 * При обычном запуске (http://localhost:8000) префикса нет.
 */
export const BASE_PATH = (() => {
  if (typeof window === 'undefined') return ''
  const match = window.location.pathname.match(/^(.*?\/proxy\/(?:absolute\/)?\d+)(?=\/|$)/)
  return match ? match[1] : ''
})()

function resolveApiUrl() {
  const configured = (import.meta.env.VITE_API_URL ?? '').trim()
  if (configured === 'same-origin' || (configured === '' && typeof window !== 'undefined' && import.meta.env.PROD)) {
    return window.location.origin + BASE_PATH
  }
  return configured || DEFAULT_API_URL
}

export const API_URL = resolveApiUrl().replace(/\/+$/, '')

export function getCameraStreamUrl(camera_id: string) {
  return `${API_URL}/api/cameras/${encodeURIComponent(camera_id)}/stream.mjpg`
}

export function getCameraFrameUrl(camera_id: string, annotated = false) {
  const suffix = annotated ? '?annotated=true' : ''
  return `${API_URL}/api/cameras/${encodeURIComponent(camera_id)}/frame.jpg${suffix}`
}

export function getIncidentSnapshotUrl(incident: { snapshot_url: string }) {
  // snapshot_url приходит как "/api/..." — считаем его относительно API_URL, чтобы не потерять префикс прокси
  return new URL(incident.snapshot_url.replace(/^\/+/, ''), `${API_URL}/`).toString()
}

export function getEventsWebSocketUrl() {
  const url = new URL(`${API_URL}/ws/events`)
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:'
  url.search = ''
  return url.toString()
}
