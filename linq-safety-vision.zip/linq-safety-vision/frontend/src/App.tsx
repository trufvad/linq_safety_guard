import { Navigate, Route, Routes } from 'react-router-dom'

import { AppLayout } from './components/layout/AppLayout'
import { AnalyticsPage } from './pages/AnalyticsPage'
import { CamerasPage } from './pages/CamerasPage'
import { MonitoringPage } from './pages/MonitoringPage'

export default function App() {
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route index element={<Navigate to="/monitoring" replace />} />
        <Route path="monitoring" element={<MonitoringPage />} />
        <Route path="cameras" element={<CamerasPage />} />
        <Route path="analytics" element={<AnalyticsPage />} />
        <Route path="*" element={<Navigate to="/monitoring" replace />} />
      </Route>
    </Routes>
  )
}
