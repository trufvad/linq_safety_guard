export type CameraStatus = 'stopped' | 'starting' | 'running' | 'finished' | 'error'
export type IncidentStatus = 'new' | 'confirmed' | 'false' | 'escalated' | 'resolved'
export type Severity = 'critical' | 'warning' | 'info'

export interface Schedule {
  start: string
  end: string
  weekdays: number[]
}

export interface Zone {
  id: string
  name: string
  kind:
    | 'danger'
    | 'machine'
    | 'restricted'
    | 'fence'
    | 'conveyor'
    | 'suspended_load'
    | 'height'
    | 'smoking_area'
  polygon: Array<[number, number]>
  schedule: Schedule | null
  enabled: boolean
}

export interface RuleConfig {
  enabled: boolean
  params: Record<string, unknown>
  schedule: Schedule | null
}

export interface CameraStats {
  id: string
  status: CameraStatus
  error: string | null
  fps: number
  latency_ms: number
  preprocess_ms: number
  inference_ms: number
  postprocess_ms: number
  pipeline_ms: number
  tracks: number
  frames: number
  suppressed_duplicates: number
  engine: string
}

export interface Camera {
  id: string
  name: string
  source: string
  area: string
  enabled: boolean
  zones: Zone[]
  rules: Record<string, RuleConfig>
  status: CameraStatus
  error: string | null
  stats: Omit<CameraStats, 'id' | 'status' | 'error'>
}

export interface Incident {
  id: string
  camera_id: string
  camera_name: string
  area: string
  zone_id: string | null
  zone_name: string | null
  violation_type: string
  title: string
  severity: Severity
  track_id: number
  confidence: number
  bbox: [number, number, number, number]
  started_at: string
  ended_at: string | null
  status: IncidentStatus
  comment: string | null
  snapshot_url: string
  details: Record<string, unknown>
}

export interface StatisticsSummary {
  total: number
  by_type: Array<{ violation_type: string; title: string; n: number }>
  by_camera: Array<{ camera_id: string; camera_name: string; n: number }>
  by_area: Array<{ area: string; n: number }>
  by_status: Array<{ status: IncidentStatus; n: number }>
  by_day: Array<{ day: string; n: number }>
  by_shift: Array<{ shift: string; n: number }>
  heatmap: number[][]
}

export type WebSocketMessage =
  | {
      type: 'hello'
      data: {
        engine: string
        cameras: CameraStats[]
      }
    }
  | {
      type: 'event.created' | 'event.updated'
      data: Incident
    }
  | {
      type: 'camera.stats'
      data: CameraStats[]
    }
  | {
      type: 'events.cleared'
      data: { camera_id: string | null; count: number }
    }
