export interface MjpegStream {
  type: 'mjpeg'
  url: string
}

export type CameraStream = MjpegStream
