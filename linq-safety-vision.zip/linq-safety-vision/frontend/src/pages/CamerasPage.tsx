import { Check, PencilLine, Save, X } from 'lucide-react'
import { useEffect, useMemo, useRef, useState } from 'react'

import { api } from '../api/api'
import { CameraSelector } from '../components/cameras/CameraSelector'
import { ConfirmButton } from '../components/common/ConfirmButton'
import { RuleSettings } from '../components/cameras/RuleSettings'
import { ZoneEditor } from '../components/cameras/ZoneEditor'
import { ZoneSettings } from '../components/cameras/ZoneSettings'
import { getCameraFrameUrl } from '../config/api'
import { useBackend } from '../context/BackendContext'
import type { Camera, RuleConfig, Zone } from '../types/api'

const REAL_DRAFT_STORAGE_KEY = 'linq.realCameraDrafts'

function loadRealDrafts(): Record<string, Camera> {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(REAL_DRAFT_STORAGE_KEY) ?? '{}')
    return value && typeof value === 'object' && !Array.isArray(value)
      ? (value as Record<string, Camera>)
      : {}
  } catch {
    return {}
  }
}

export function CamerasPage() {
  const {
    cameras: backendCameras,
    camerasLoading,
    camerasError,
    rules: ruleCatalog,
    refreshCameras,
  } = useBackend()
  const [cameras, setCameras] = useState<Camera[]>([])
  const [selectedCameraId, setSelectedCameraId] = useState(cameras[0]?.id ?? '')
  const [draftPoints, setDraftPoints] = useState<Array<[number, number]>>([])
  const [isDrawing, setIsDrawing] = useState(false)
  const [zoneName, setZoneName] = useState('Новая опасная зона')
  const [zoneKind, setZoneKind] = useState<Zone['kind']>('danger')
  const [selectedZoneId, setSelectedZoneId] = useState<string | null>(null)
  const [saveMessage, setSaveMessage] = useState('')
  const [saveError, setSaveError] = useState('')
  const [isSaving, setIsSaving] = useState(false)
  const [frameVersion, setFrameVersion] = useState(0)
  const [frameUnavailable, setFrameUnavailable] = useState(false)
  const realDrafts = useRef(loadRealDrafts())
  const restoredDrafts = useRef(false)

  const prepareCamera = useMemo(
    () =>
      (camera: Camera): Camera => {
        if (!ruleCatalog.length) return camera
        const rules = Object.fromEntries(
          ruleCatalog.filter((rule) => rule.available).map((rule) => [
            rule.type,
            camera.rules[rule.type] ?? {
              enabled: true,
              params: rule.default_params,
              schedule: null,
            },
          ]),
        ) as Record<string, RuleConfig>
        return { ...camera, rules }
      },
    [ruleCatalog],
  )

  useEffect(() => {
    if (!backendCameras.length) {
      setCameras([])
      return
    }
    setCameras((current) => {
      const currentById = new Map(current.map((camera) => [camera.id, camera]))
      return backendCameras.map((camera) => {
        const persistedDraft = realDrafts.current[camera.id]
        const currentDraft = currentById.get(camera.id)
        const draft = currentDraft ?? persistedDraft
        if (!currentDraft && persistedDraft) restoredDrafts.current = true
        return draft
          ? prepareCamera({ ...draft, status: camera.status, error: camera.error, stats: camera.stats })
          : prepareCamera(camera)
      })
    })
  }, [backendCameras, prepareCamera])

  useEffect(() => {
    if (restoredDrafts.current && !saveMessage && !saveError) {
      setSaveMessage('Восстановлен локальный черновик после ошибки сохранения')
      restoredDrafts.current = false
    }
  }, [cameras, saveError, saveMessage])

  useEffect(() => {
    if (!cameras.length) return
    if (!cameras.some((camera) => camera.id === selectedCameraId)) {
      setSelectedCameraId(cameras[0].id)
    }
  }, [cameras, selectedCameraId])

  const selectedCamera = cameras.find((camera) => camera.id === selectedCameraId)

  const updateSelectedCamera = (update: (camera: Camera) => Camera) => {
    setCameras((currentCameras) =>
      currentCameras.map((camera) => (camera.id === selectedCameraId ? update(camera) : camera)),
    )
    setSaveMessage('')
    setSaveError('')
  }

  const handleSelectCamera = (camera_id: string) => {
    setSelectedCameraId(camera_id)
    setDraftPoints([])
    setIsDrawing(false)
    setSelectedZoneId(null)
    setSaveMessage('')
    setSaveError('')
    setFrameUnavailable(false)
    setFrameVersion((current) => current + 1)
  }

  // Зоны сохраняются на сервер сразу — нарисовал и она уже работает, отдельно жать «Сохранить» не нужно
  const saveZones = async (camera_id: string, zones: Zone[], message: string) => {
    setSaveMessage('')
    setSaveError('')
    try {
      await api.updateCameraZones(camera_id, zones)
      setSaveMessage(message)
      await refreshCameras()
    } catch (error) {
      setSaveError(error instanceof Error ? error.message : 'Не удалось сохранить зону')
    }
  }

  const handleFinishDrawing = () => {
    if (draftPoints.length < 3 || !selectedCamera) return
    const zone: Zone = {
      id: `zone-${crypto.randomUUID?.() ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`}`,
      name: zoneName.trim() || 'Новая зона',
      kind: zoneKind,
      polygon: draftPoints,
      schedule: null,
      enabled: true,
    }
    const zones = [...selectedCamera.zones, zone]
    updateSelectedCamera((camera) => ({ ...camera, zones }))
    setSelectedZoneId(zone.id)
    setDraftPoints([])
    setIsDrawing(false)
    void saveZones(selectedCamera.id, zones, `Зона «${zone.name}» сохранена и уже работает`)
  }

  const handleDeleteZone = (zone_id: string) => {
    if (!selectedCamera) return
    const zones = selectedCamera.zones.filter((zone) => zone.id !== zone_id)
    updateSelectedCamera((camera) => ({ ...camera, zones }))
    if (selectedZoneId === zone_id) setSelectedZoneId(null)
    void saveZones(selectedCamera.id, zones, 'Зона удалена')
  }

  const handleRuleToggle = (rule_type: string, enabled: boolean) => {
    updateSelectedCamera((camera) => ({
      ...camera,
      rules: {
        ...camera.rules,
        [rule_type]: {
          ...(camera.rules[rule_type] ?? { params: {}, schedule: null }),
          enabled,
        },
      },
    }))
  }

  const handleSave = async () => {
    if (!selectedCamera) return
    setIsSaving(true)
    setSaveMessage('')
    setSaveError('')
    try {
      const [zones, rules] = await Promise.all([
        api.updateCameraZones(selectedCamera.id, selectedCamera.zones),
        api.updateCameraRules(selectedCamera.id, selectedCamera.rules),
      ])
      setCameras((current) =>
        current.map((camera) =>
          camera.id === selectedCamera.id ? { ...camera, zones, rules } : camera,
        ),
      )
      delete realDrafts.current[selectedCamera.id]
      localStorage.setItem(REAL_DRAFT_STORAGE_KEY, JSON.stringify(realDrafts.current))
      setSaveMessage('Настройки сохранены и уже применяются')
      await refreshCameras()
    } catch (error) {
      realDrafts.current[selectedCamera.id] = selectedCamera
      localStorage.setItem(REAL_DRAFT_STORAGE_KEY, JSON.stringify(realDrafts.current))
      setSaveError(error instanceof Error ? error.message : 'Не удалось сохранить настройки')
    } finally {
      setIsSaving(false)
    }
  }

  const handleDeleteCamera = async () => {
    if (!selectedCamera) return
    setSaveMessage('')
    setSaveError('')
    try {
      await api.deleteCamera(selectedCamera.id)
      delete realDrafts.current[selectedCamera.id]
      localStorage.setItem(REAL_DRAFT_STORAGE_KEY, JSON.stringify(realDrafts.current))
      setCameras((current) => current.filter((camera) => camera.id !== selectedCamera.id))
      setDraftPoints([])
      setIsDrawing(false)
      setSelectedZoneId(null)
      await refreshCameras()
    } catch (error) {
      setSaveError(error instanceof Error ? error.message : 'Не удалось удалить камеру')
    }
  }

  if (camerasLoading && !cameras.length) {
    return <p className="rounded-xl border border-slate-800 bg-[#0c1422] p-8 text-sm text-slate-400">Загрузка камер…</p>
  }

  if (!selectedCamera) {
    return (
      <div className="rounded-xl border border-dashed border-slate-700 bg-[#0c1422] p-12 text-center text-sm text-slate-400">
        {camerasError || 'Камеры пока не подключены. Загрузите видеофайл на странице «Мониторинг».'}
      </div>
    )
  }

  const frameUrl = `${getCameraFrameUrl(selectedCamera.id)}?v=${frameVersion}`

  return (
    <div>
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-cyan-400">Источники видеонаблюдения</p>
          <h2 className="mt-2 text-2xl font-semibold tracking-tight text-white sm:text-3xl">Камеры и опасные зоны</h2>
          <p className="mt-2 text-sm text-slate-500">Настройка полигонов и правил безопасности для выбранной камеры.</p>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[220px_minmax(0,1fr)]">
        <CameraSelector cameras={cameras} selectedCameraId={selectedCameraId} onSelect={handleSelectCamera} />

        <div className="min-w-0 space-y-5">
          <section className="rounded-xl border border-slate-800 bg-[#0c1422] p-4 sm:p-5">
            <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h3 className="text-base font-semibold text-slate-100">{selectedCamera.name}</h3>
                <p className="mt-1 text-xs text-slate-500">{selectedCamera.id} · {selectedCamera.area} · {selectedCamera.source.split(/[\\/]/).pop()?.replace(/^[0-9a-f]{8}__/, '')}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <ConfirmButton
                  label="Удалить камеру"
                  confirmLabel="Точно удалить камеру?"
                  onConfirm={handleDeleteCamera}
                />
                <button type="button" onClick={() => void handleSave()} disabled={isSaving} className="inline-flex items-center justify-center gap-2 rounded-lg bg-cyan-400 px-4 py-2.5 text-xs font-semibold text-slate-950 hover:bg-cyan-300 disabled:cursor-not-allowed disabled:opacity-50">
                  <Save size={15} aria-hidden="true" />
                  {isSaving ? 'Сохранение…' : 'Сохранить настройки'}
                </button>
              </div>
            </div>

            <div className="mb-4 grid gap-3 sm:grid-cols-[minmax(0,1fr)_170px_auto]">
              <label>
                <span className="mb-1.5 block text-xs text-slate-500">Название зоны</span>
                <input value={zoneName} onChange={(event) => setZoneName(event.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950/50 px-3 py-2.5 text-sm text-slate-200 outline-none focus:border-cyan-400/60" />
              </label>
              <label>
                <span className="mb-1.5 block text-xs text-slate-500">Тип зоны</span>
                <select value={zoneKind} onChange={(event) => setZoneKind(event.target.value as Zone['kind'])} className="w-full rounded-lg border border-slate-700 bg-slate-950/50 px-3 py-2.5 text-sm text-slate-200 outline-none focus:border-cyan-400/60">
                  <option value="danger">Опасная зона</option><option value="restricted">Запретная зона</option><option value="machine">Зона работы техники</option><option value="fence">Ограждение (перелезание)</option><option value="conveyor">Под конвейером (пролезание)</option><option value="suspended_load">Под подвешенным грузом</option><option value="height">Работы на высоте</option><option value="smoking_area">Место для курения (разрешено)</option>
                </select>
              </label>
              <div className="flex items-end gap-2">
                {isDrawing ? (
                  <>
                    <button type="button" onClick={handleFinishDrawing} disabled={draftPoints.length < 3} className="grid size-10 place-items-center rounded-lg bg-cyan-400 text-slate-950 disabled:cursor-not-allowed disabled:opacity-40" aria-label="Завершить создание зоны"><Check size={17} /></button>
                    <button type="button" onClick={() => { setDraftPoints([]); setIsDrawing(false) }} className="grid size-10 place-items-center rounded-lg border border-slate-700 text-slate-400 hover:text-white" aria-label="Отменить создание зоны"><X size={17} /></button>
                  </>
                ) : (
                  <button type="button" onClick={() => { setDraftPoints([]); setIsDrawing(true); setSelectedZoneId(null) }} className="inline-flex h-10 items-center gap-2 whitespace-nowrap rounded-lg border border-cyan-400/30 bg-cyan-400/10 px-3 text-xs font-semibold text-cyan-300"><PencilLine size={15} />Новая зона</button>
                )}
              </div>
            </div>

            <ZoneEditor
              imageUrl={frameUrl}
              imageLabel="Стоп-кадр камеры" 
              frameUnavailable={frameUnavailable}
              zones={selectedCamera.zones}
              draftPoints={draftPoints}
              isDrawing={isDrawing}
              selectedZoneId={selectedZoneId}
              onAddPoint={(point) => setDraftPoints((current) => [...current, point])}
              onSelectZone={setSelectedZoneId}
              onFrameLoad={() => setFrameUnavailable(false)}
              onFrameError={() => setFrameUnavailable(true)}
              onRetryFrame={() => { setFrameUnavailable(false); setFrameVersion((current) => current + 1) }}
            />

            <div className="mt-3 flex min-h-5 items-center justify-between gap-3 text-xs">
              <span className="text-slate-600">Координаты вершин сохраняются в диапазоне 0..1.</span>
              {saveMessage && <span className="font-medium text-emerald-400">{saveMessage}</span>}
              {saveError && <span className="font-medium text-red-400">{saveError}</span>}
            </div>
          </section>

          <div className="grid gap-5 xl:grid-cols-2">
            <ZoneSettings zones={selectedCamera.zones} selectedZoneId={selectedZoneId} onDelete={handleDeleteZone} onSelect={setSelectedZoneId} />
            <RuleSettings rules={selectedCamera.rules} onToggle={handleRuleToggle} />
          </div>
        </div>
      </div>
    </div>
  )
}
