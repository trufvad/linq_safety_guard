import { UploadCloud } from 'lucide-react'
import { type ReactNode, useEffect, useMemo, useState } from 'react'

import { IncidentFeed } from '../components/incidents/IncidentFeed'
import { IncidentModal } from '../components/incidents/IncidentModal'
import { CameraCard } from '../components/monitoring/CameraCard'
import { MonitoringToolbar } from '../components/monitoring/MonitoringToolbar'
import { VideoUploadModal } from '../components/monitoring/VideoUploadModal'
import { getCameraStreamUrl } from '../config/api'
import { useBackend } from '../context/BackendContext'
import { useIncidents } from '../context/IncidentContext'
import type { IncidentStatus } from '../types/api'
import type { CameraStream } from '../types/monitoring'

const FEED_CLEARED_KEY = 'linq.feedClearedAt'

export function MonitoringPage() {
  const {
    cameras,
    camerasLoading,
    camerasError,
    soundEnabled,
    startCamera,
    stopCamera,
    refreshCameras,
    toggleSound,
  } = useBackend()
  const { incidents, incidentsLoading, updateIncidentStatus } = useIncidents()
  const [selectedCameraId, setSelectedCameraId] = useState(cameras[0]?.id ?? '')
  const [isExpanded, setIsExpanded] = useState(false)
  const [selectedIncidentId, setSelectedIncidentId] = useState<string | null>(null)
  const [cameraActionBusy, setCameraActionBusy] = useState(false)
  const [cameraActionError, setCameraActionError] = useState('')
  const [uploadOpen, setUploadOpen] = useState(false)
  // Очистка ленты тревог: прячем уже показанные тревоги только в ленте, журнал не трогаем
  const [feedClearedAt, setFeedClearedAt] = useState<number>(() => {
    try {
      return Number(localStorage.getItem(FEED_CLEARED_KEY)) || 0
    } catch {
      return 0
    }
  })
  const clearFeed = () => {
    const now = Date.now()
    setFeedClearedAt(now)
    try {
      localStorage.setItem(FEED_CLEARED_KEY, String(now))
    } catch {
      // браузер без localStorage — лента очистится до перезагрузки страницы
    }
  }

  useEffect(() => {
    if (!cameras.length) return
    if (!cameras.some((camera) => camera.id === selectedCameraId)) {
      setSelectedCameraId(cameras[0].id)
      setIsExpanded(false)
    }
  }, [cameras, selectedCameraId])

  const selectedCamera = useMemo(
    () => cameras.find((camera) => camera.id === selectedCameraId) ?? cameras[0],
    [cameras, selectedCameraId],
  )
  const selectedIncident = incidents.find((incident) => incident.id === selectedIncidentId)
  const feedIncidents = useMemo(
    () => incidents.filter((incident) => new Date(incident.started_at).getTime() > feedClearedAt),
    [incidents, feedClearedAt],
  )
  const activeIncidentCount = feedIncidents.filter((incident) => incident.status === 'new').length

  const handleCameraAction = async () => {
    if (!selectedCamera) return
    setCameraActionBusy(true)
    setCameraActionError('')
    try {
      if (selectedCamera.status === 'running' || selectedCamera.status === 'starting') {
        await stopCamera(selectedCamera.id)
      } else {
        await startCamera(selectedCamera.id)
      }
    } catch (error) {
      setCameraActionError(error instanceof Error ? error.message : 'Не удалось изменить статус камеры')
    } finally {
      setCameraActionBusy(false)
    }
  }

  const getStream = (cameraId: string): CameraStream | undefined => {
    const camera = cameras.find((item) => item.id === cameraId)
    return camera?.status === 'running' ? { type: 'mjpeg', url: getCameraStreamUrl(cameraId) } : undefined
  }

  const uploadModal = uploadOpen && (
    <VideoUploadModal
      cameras={cameras}
      selectedCameraId={selectedCameraId}
      onClose={() => setUploadOpen(false)}
      onUploaded={async (result) => {
        await refreshCameras().catch(() => undefined)
        setSelectedCameraId(result.camera_id)
        setIsExpanded(false)
      }}
    />
  )

  const header = (
    <div className="mb-6">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-cyan-400">Контроль в реальном времени</p>
      <h2 className="mt-2 text-2xl font-semibold tracking-tight text-white sm:text-3xl">Камеры наблюдения</h2>
      <p className="mt-2 text-sm text-slate-500">
        Детекция людей и техники, трекинг и правила охраны труда на каждом кадре.
      </p>
    </div>
  )

  // Окно загрузки всегда рендерится в одном и том же месте дерева: иначе при переходе
  // «нет камер -> есть камеры» React пересоздаёт его и сбрасывает прогресс и результат.
  const withModal = (content: ReactNode) => (
    <>
      {content}
      {uploadModal}
    </>
  )

  if (camerasLoading && !cameras.length && !uploadOpen) {
    return withModal(<p className="rounded-xl border border-slate-800 bg-[#0c1422] p-8 text-sm text-slate-400">Загрузка камер…</p>)
  }

  if (!selectedCamera) {
    return withModal(
      <div>
        {header}
        <div className="rounded-xl border border-dashed border-slate-700 bg-[#0c1422] px-6 py-16 text-center">
          <UploadCloud className="mx-auto text-cyan-300" size={34} strokeWidth={1.5} aria-hidden="true" />
          <p className="mt-4 text-base font-semibold text-slate-100">
            {camerasError ? 'Нет связи с сервером' : 'Камеры пока не подключены'}
          </p>
          <p className="mx-auto mt-2 max-w-md text-sm text-slate-500">
            {camerasError ||
              'Загрузите видеофайл с производства: система начнёт анализировать его как живую камеру. Затем нарисуйте опасные зоны в разделе «Настройка камер».'}
          </p>
          {!camerasError && (
            <button
              type="button"
              onClick={() => setUploadOpen(true)}
              className="mt-6 inline-flex items-center gap-2 rounded-lg bg-cyan-400 px-5 py-3 text-sm font-semibold text-slate-950 hover:bg-cyan-300"
            >
              <UploadCloud size={17} aria-hidden="true" />
              Загрузить видеофайл
            </button>
          )}
        </div>
      </div>,
    )
  }

  const visibleCameras = isExpanded ? [selectedCamera] : cameras
  const isRunning = selectedCamera.status === 'running' || selectedCamera.status === 'starting'

  return withModal(
    <div>
      {header}

      <MonitoringToolbar
        selectedCamera={selectedCamera}
        isExpanded={isExpanded}
        cameraActionLabel={isRunning ? 'Остановить камеру' : 'Запустить камеру'}
        cameraActionBusy={cameraActionBusy}
        onCameraAction={() => void handleCameraAction()}
        onToggleExpanded={() => setIsExpanded((current) => !current)}
        onUploadVideo={() => setUploadOpen(true)}
      />

      {(cameraActionError || camerasError) && (
        <p className="mb-4 rounded-lg border border-red-500/20 bg-red-500/[0.06] px-4 py-3 text-xs text-red-300">
          {cameraActionError || camerasError}
        </p>
      )}

      <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_320px]">
        <section className={`grid min-w-0 gap-4 ${isExpanded ? 'grid-cols-1' : 'grid-cols-1 lg:grid-cols-2'}`} aria-label="Камеры наблюдения">
          {visibleCameras.map((camera) => (
            <CameraCard
              key={camera.id}
              camera={camera}
              stream={getStream(camera.id)}
              aspectRatio={16 / 9}
              isSelected={camera.id === selectedCameraId}
              isExpanded={isExpanded}
              onSelect={(cameraId) => {
                setSelectedCameraId(cameraId)
                if (isExpanded && cameraId !== selectedCameraId) setIsExpanded(false)
              }}
              onToggleExpanded={() => setIsExpanded((current) => !current)}
            />
          ))}
        </section>

        <IncidentFeed
          incidents={feedIncidents.slice(0, 50)}
          activeCount={activeIncidentCount}
          soundEnabled={soundEnabled}
          onSelect={setSelectedIncidentId}
          onToggleSound={toggleSound}
          onClear={clearFeed}
        />
      </div>

      {incidentsLoading && <p className="mt-4 text-xs text-slate-500">Синхронизация истории событий…</p>}

      {selectedIncident && (
        <IncidentModal
          incident={selectedIncident}
          onClose={() => setSelectedIncidentId(null)}
          onStatusChange={(status: IncidentStatus) => updateIncidentStatus(selectedIncident.id, status)}
        />
      )}
    </div>,
  )
}
