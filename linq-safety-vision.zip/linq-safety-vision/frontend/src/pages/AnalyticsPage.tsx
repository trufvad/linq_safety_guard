import { lazy, Suspense, useEffect, useMemo, useState } from 'react'

import { AnalyticsTabs, type AnalyticsTab } from '../components/analytics/AnalyticsTabs'
import {
  IncidentFilters,
  type IncidentFilterValues,
} from '../components/analytics/IncidentFilters'
import { IncidentTable } from '../components/analytics/IncidentTable'
import { Pagination } from '../components/analytics/Pagination'
import { ConfirmButton } from '../components/common/ConfirmButton'
import { IncidentModal } from '../components/incidents/IncidentModal'
import { api } from '../api/api'
import { useIncidents } from '../context/IncidentContext'
import type { StatisticsPeriod } from '../utils/incidentStatistics'

const PAGE_SIZE = 10
const StatisticsPanel = lazy(() => import('../components/analytics/StatisticsPanel'))

const initialFilters: IncidentFilterValues = {
  search: '',
  date_from: '',
  date_to: '',
  camera_id: '',
  violation_type: '',
  status: '',
  severity: '',
  sort: 'newest',
}

export function AnalyticsPage() {
  const { incidents, incidentsLoading, incidentsError, updateIncidentStatus, replaceIncidents } = useIncidents()
  const [clearError, setClearError] = useState('')

  const handleClearJournal = async () => {
    setClearError('')
    try {
      await api.clearIncidents()
      replaceIncidents([])
      setSelectedIncidentId(null)
    } catch (error) {
      setClearError(error instanceof Error ? error.message : 'Не удалось очистить журнал')
    }
  }
  const [filters, setFilters] = useState<IncidentFilterValues>(initialFilters)
  const [currentPage, setCurrentPage] = useState(1)
  const [selectedIncidentId, setSelectedIncidentId] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<AnalyticsTab>('journal')
  const [statisticsPeriod, setStatisticsPeriod] = useState<StatisticsPeriod>('7days')

  const cameraOptions = useMemo(() => {
    const cameras = new Map<string, string>()
    incidents.forEach((incident) => {
      if (incident.camera_id) cameras.set(incident.camera_id, incident.camera_name || '—')
    })
    return Array.from(cameras, ([id, name]) => ({ id, name }))
  }, [incidents])

  const violationOptions = useMemo(() => {
    const violations = new Map<string, string>()
    incidents.forEach((incident) => {
      if (incident.violation_type) violations.set(incident.violation_type, incident.title || '—')
    })
    return Array.from(violations, ([type, title]) => ({ type, title }))
  }, [incidents])

  const filteredIncidents = useMemo(() => {
    const search = filters.search.trim().toLocaleLowerCase('ru-RU')
    const dateFrom = filters.date_from ? new Date(`${filters.date_from}T00:00:00`).getTime() : null
    const dateTo = filters.date_to ? new Date(`${filters.date_to}T23:59:59.999`).getTime() : null

    return incidents
      .filter((incident) => {
        const startedAt = new Date(incident.started_at).getTime()
        const matchesSearch =
          !search ||
          (incident.title ?? '').toLocaleLowerCase('ru-RU').includes(search) ||
          (incident.camera_name ?? '').toLocaleLowerCase('ru-RU').includes(search) ||
          (incident.area ?? '').toLocaleLowerCase('ru-RU').includes(search)

        return (
          matchesSearch &&
          (dateFrom === null || startedAt >= dateFrom) &&
          (dateTo === null || startedAt <= dateTo) &&
          (!filters.camera_id || incident.camera_id === filters.camera_id) &&
          (!filters.violation_type || incident.violation_type === filters.violation_type) &&
          (!filters.status || incident.status === filters.status) &&
          (!filters.severity || incident.severity === filters.severity)
        )
      })
      .sort((first, second) => {
        const firstTime = new Date(first.started_at).getTime()
        const secondTime = new Date(second.started_at).getTime()
        return filters.sort === 'newest' ? secondTime - firstTime : firstTime - secondTime
      })
  }, [filters, incidents])

  const totalPages = Math.max(1, Math.ceil(filteredIncidents.length / PAGE_SIZE))
  const paginatedIncidents = filteredIncidents.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE,
  )
  const selectedIncident = incidents.find((incident) => incident.id === selectedIncidentId)

  useEffect(() => {
    setCurrentPage(1)
  }, [filters])

  useEffect(() => {
    if (currentPage > totalPages) setCurrentPage(totalPages)
  }, [currentPage, totalPages])

  return (
    <div>
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-cyan-400">
            События и показатели
          </p>
          <h2 className="mt-2 text-2xl font-semibold tracking-tight text-white sm:text-3xl">
            Журнал и аналитика
          </h2>
          <p className="mt-2 text-sm text-slate-500">
            История событий, показатели и активность нарушений.
          </p>
        </div>
      </div>

      <div className="flex flex-wrap items-start justify-between gap-3">
        <AnalyticsTabs activeTab={activeTab} onChange={setActiveTab} />
        <ConfirmButton
          label="Очистить журнал"
          confirmLabel="Удалить все события? Нажмите ещё раз"
          busyLabel="Очистка…"
          disabled={!incidents.length}
          onConfirm={handleClearJournal}
        />
      </div>
      {clearError && (
        <p className="mb-4 rounded-lg border border-red-500/20 bg-red-500/[0.06] px-4 py-3 text-xs text-red-300">{clearError}</p>
      )}

      {activeTab === 'journal' ? (
        <>
          <IncidentFilters
            filters={filters}
            cameraOptions={cameraOptions}
            violationOptions={violationOptions}
            onChange={(update) => setFilters((current) => ({ ...current, ...update }))}
            onReset={() => setFilters(initialFilters)}
          />

          <div className="mt-5">
            {incidentsLoading && incidents.length === 0 ? (
              <div className="rounded-xl border border-slate-800 bg-[#0c1422] px-6 py-16 text-center text-sm text-slate-500">
                Загрузка истории событий…
              </div>
            ) : incidentsError && incidents.length === 0 ? (
              <div className="rounded-xl border border-red-500/20 bg-red-500/[0.06] px-6 py-12 text-center text-sm text-red-300">
                {incidentsError}
              </div>
            ) : incidents.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-700 bg-[#0c1422] px-6 py-16 text-center">
                <p className="text-sm font-medium text-slate-400">Событий пока нет</p>
                <p className="mt-2 text-xs text-slate-600">
                  Нарушения будут появляться здесь автоматически.
                </p>
              </div>
            ) : filteredIncidents.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-700 bg-[#0c1422] px-6 py-16 text-center">
                <p className="text-sm font-medium text-slate-400">
                  По заданным фильтрам ничего не найдено
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                <IncidentTable incidents={paginatedIncidents} onOpen={setSelectedIncidentId} />
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  totalItems={filteredIncidents.length}
                  onChange={setCurrentPage}
                />
              </div>
            )}
          </div>
        </>
      ) : (
        <Suspense
          fallback={
            <div className="rounded-xl border border-slate-800 bg-[#0c1422] px-6 py-16 text-center text-sm text-slate-500">
              Загрузка статистики…
            </div>
          }
        >
          <StatisticsPanel
            incidents={incidents}
            period={statisticsPeriod}
            onPeriodChange={setStatisticsPeriod}
          />
        </Suspense>
      )}

      {selectedIncident && (
        <IncidentModal
          incident={selectedIncident}
          onClose={() => setSelectedIncidentId(null)}
          onStatusChange={(status) => updateIncidentStatus(selectedIncident.id, status)}
        />
      )}
    </div>
  )
}
