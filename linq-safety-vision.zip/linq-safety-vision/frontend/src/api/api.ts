import { API_URL } from '../config/api'
import type {
  Camera,
  CameraStats,
  Incident,
  IncidentStatus,
  RuleConfig,
  Severity,
  StatisticsSummary,
  Zone,
} from '../types/api'

export type CameraConfig = Pick<Camera, 'id' | 'name' | 'source' | 'area' | 'enabled' | 'zones' | 'rules'>

export interface CameraPatch {
  name?: string
  source?: string
  area?: string
  enabled?: boolean
}

export interface IncidentPatch {
  status: IncidentStatus
  comment?: string | null
  operator?: string | null
}

export interface IncidentFilters {
  camera_id?: string
  violation_type?: string
  status?: string
  area?: string
  zone_id?: string
  date_from?: string
  date_to?: string
  limit?: number
  offset?: number
}

export interface RuleDefinition {
  type: string
  title: string
  severity: Severity
  default_params: Record<string, unknown>
  available: boolean
  requires_labels: string[]
}

export interface HealthResponse {
  status: 'ok' | 'degraded'
  engine: string
  cameras: number
  uptime_s: number
  labels: number
  /** Проблемы модели (например, int8 обрезает координаты в .tpu). Пусто — всё в порядке. */
  warnings?: string[]
}

export interface IncidentListResponse {
  total: number
  items: Incident[]
}

export interface PerformanceResponse {
  engine: string
  cameras: CameraStats[]
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_URL}${path}`, {
    ...init,
    headers: {
      ...(init?.body ? { 'Content-Type': 'application/json' } : {}),
      ...init?.headers,
    },
  })

  if (!response.ok) {
    const body = (await response.json().catch(() => null)) as { detail?: string } | null
    throw new Error(body?.detail || `Ошибка API: ${response.status} ${response.statusText}`)
  }

  if (response.status === 204) {
    return undefined as T
  }

  return response.json() as Promise<T>
}

export interface UploadedVideo {
  id: string
  name: string
  path: string
  size_mb: number
  uploaded_at: string
  cameras: string[]
  width?: number
  height?: number
  fps?: number
  frames?: number
  duration_s?: number | null
}

export interface VideoUploadOptions {
  mode: 'new' | 'replace'
  camera_id?: string
  name?: string
  area?: string
  onProgress?: (fraction: number) => void
  signal?: AbortSignal
}

export interface VideoUploadResponse {
  video: UploadedVideo
  camera_id: string
}

/** Загрузка видео с прогрессом (fetch не умеет отдавать прогресс отправки, поэтому XHR). */
function uploadVideo(file: File, options: VideoUploadOptions): Promise<VideoUploadResponse> {
  return new Promise((resolve, reject) => {
    const form = new FormData()
    form.append('file', file)
    form.append('mode', options.mode)
    if (options.camera_id) form.append('camera_id', options.camera_id)
    if (options.name) form.append('name', options.name)
    if (options.area) form.append('area', options.area)

    const xhr = new XMLHttpRequest()
    xhr.open('POST', `${API_URL}/api/videos`)
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) options.onProgress?.(event.loaded / event.total)
    }
    xhr.onload = () => {
      let body: unknown = null
      try {
        body = JSON.parse(xhr.responseText)
      } catch {
        body = null
      }
      if (xhr.status >= 200 && xhr.status < 300) {
        resolve(body as VideoUploadResponse)
      } else {
        const detail = (body as { detail?: unknown } | null)?.detail
        reject(new Error(typeof detail === 'string' ? detail : `Ошибка загрузки: ${xhr.status}`))
      }
    }
    xhr.onerror = () => reject(new Error('Сеть недоступна: Backend не ответил'))
    xhr.onabort = () => reject(new Error('Загрузка отменена'))
    options.signal?.addEventListener('abort', () => xhr.abort())
    xhr.send(form)
  })
}

export interface StatisticsFilters {
  date_from?: string
  date_to?: string
  camera_id?: string
  area?: string
}

function toQueryString(filters: IncidentFilters) {
  const params = new URLSearchParams()

  Object.entries(filters).forEach(([key, value]) => {
    if (value !== undefined && value !== '') {
      params.set(key, String(value))
    }
  })

  const query = params.toString()
  return query ? `?${query}` : ''
}

export const api = {
  getHealth: () => request<HealthResponse>('/api/health'),
  getRules: () => request<RuleDefinition[]>('/api/rules'),
  getCameras: () => request<Camera[]>('/api/cameras'),
  getCamera: (camera_id: string) =>
    request<Camera>(`/api/cameras/${encodeURIComponent(camera_id)}`),
  createCamera: (camera: CameraConfig) =>
    request<Camera>('/api/cameras', {
      method: 'POST',
      body: JSON.stringify(camera),
    }),
  updateCamera: (camera_id: string, patch: CameraPatch) =>
    request<Camera>(`/api/cameras/${encodeURIComponent(camera_id)}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    }),
  deleteCamera: (camera_id: string) =>
    request<void>(`/api/cameras/${encodeURIComponent(camera_id)}`, { method: 'DELETE' }),
  updateCameraZones: (camera_id: string, zones: Zone[]) =>
    request<Zone[]>(`/api/cameras/${encodeURIComponent(camera_id)}/zones`, {
      method: 'PUT',
      body: JSON.stringify(zones),
    }),
  updateCameraRules: (camera_id: string, rules: Record<string, RuleConfig>) =>
    request<Record<string, RuleConfig>>(`/api/cameras/${encodeURIComponent(camera_id)}/rules`, {
      method: 'PUT',
      body: JSON.stringify(rules),
    }),
  startCamera: (camera_id: string) =>
    request<Pick<Camera, 'status'>>(`/api/cameras/${encodeURIComponent(camera_id)}/start`, {
      method: 'POST',
    }),
  stopCamera: (camera_id: string) =>
    request<Pick<Camera, 'status'>>(`/api/cameras/${encodeURIComponent(camera_id)}/stop`, {
      method: 'POST',
    }),
  getIncidents: (filters: IncidentFilters = {}) =>
    request<IncidentListResponse>(`/api/events${toQueryString(filters)}`),
  getIncident: (incident_id: string) =>
    request<Incident>(`/api/events/${encodeURIComponent(incident_id)}`),
  clearIncidents: () => request<{ deleted: number }>('/api/events', { method: 'DELETE' }),
  updateIncident: (incident_id: string, patch: IncidentPatch) =>
    request<Incident>(`/api/events/${encodeURIComponent(incident_id)}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    }),
  listVideos: () => request<UploadedVideo[]>('/api/videos'),
  deleteVideo: (video_id: string) =>
    request<void>(`/api/videos/${encodeURIComponent(video_id)}`, { method: 'DELETE' }),
  uploadVideo,
  testTelegram: () => request<{ ok: boolean }>('/api/notify/test', { method: 'POST' }),
  getCameraStats: () => request<PerformanceResponse>('/api/stats/performance'),
  getStatisticsSummary: (filters: StatisticsFilters = {}) =>
    request<StatisticsSummary>(`/api/stats/summary${toQueryString(filters)}`),
}
