import { Trash2 } from 'lucide-react'

import type { Zone } from '../../types/api'

interface ZoneSettingsProps {
  zones: Zone[]
  selectedZoneId: string | null
  onDelete: (zone_id: string) => void
  onSelect: (zone_id: string) => void
}

const kindLabels: Record<Zone['kind'], string> = {
  danger: 'Опасная',
  restricted: 'Ограниченная',
  machine: 'Зона техники',
}

export function ZoneSettings({ zones, selectedZoneId, onDelete, onSelect }: ZoneSettingsProps) {
  return (
    <section className="rounded-xl border border-slate-800 bg-[#0c1422] p-4">
      <div className="flex items-center justify-between gap-3">
        <h3 className="text-sm font-semibold text-slate-100">Созданные зоны</h3>
        <span className="text-xs text-slate-500">{zones.length}</span>
      </div>

      {zones.length ? (
        <div className="mt-4 space-y-2">
          {zones.map((zone) => (
            <div
              key={zone.id}
              className={`flex items-center justify-between gap-3 rounded-lg border px-3 py-2.5 ${
                zone.id === selectedZoneId
                  ? 'border-cyan-400/30 bg-cyan-400/[0.06]'
                  : 'border-slate-800 bg-slate-950/20'
              }`}
            >
              <button type="button" onClick={() => onSelect(zone.id)} className="min-w-0 text-left">
                <span className="block truncate text-sm font-medium text-slate-200">{zone.name}</span>
                <span className="mt-1 block text-[11px] text-slate-500">
                  {kindLabels[zone.kind]} · {zone.polygon.length} вершин
                </span>
              </button>
              <button
                type="button"
                onClick={() => onDelete(zone.id)}
                className="grid size-8 shrink-0 place-items-center rounded-lg text-slate-600 hover:bg-red-500/10 hover:text-red-400"
                aria-label={`Удалить зону ${zone.name}`}
              >
                <Trash2 size={15} />
              </button>
            </div>
          ))}
        </div>
      ) : (
        <p className="mt-4 rounded-lg border border-dashed border-slate-700 px-4 py-8 text-center text-xs leading-5 text-slate-600">
          Для этой камеры зоны ещё не созданы.
        </p>
      )}
    </section>
  )
}
