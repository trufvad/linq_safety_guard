import { Cctv } from 'lucide-react'

import type { Camera } from '../../types/api'

interface CameraSelectorProps {
  cameras: Camera[]
  selectedCameraId: string
  onSelect: (camera_id: string) => void
}

export function CameraSelector({ cameras, selectedCameraId, onSelect }: CameraSelectorProps) {
  return (
    <aside className="rounded-xl border border-slate-800 bg-[#0c1422] p-3 lg:self-start">
      <p className="px-2 pb-3 text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
        Камеры
      </p>
      <div className="grid gap-1 sm:grid-cols-2 lg:grid-cols-1">
        {cameras.map((camera) => {
          const isSelected = camera.id === selectedCameraId

          return (
            <button
              key={camera.id}
              type="button"
              onClick={() => onSelect(camera.id)}
              className={`flex items-start gap-3 rounded-lg px-3 py-3 text-left transition-colors ${
                isSelected
                  ? 'bg-cyan-400/10 text-cyan-300 ring-1 ring-inset ring-cyan-400/20'
                  : 'text-slate-400 hover:bg-white/[0.04] hover:text-slate-200'
              }`}
              aria-pressed={isSelected}
            >
              <Cctv size={17} className="mt-0.5 shrink-0" aria-hidden="true" />
              <span className="min-w-0">
                <span className="block truncate text-sm font-semibold">{camera.name}</span>
                <span className="mt-1 block text-xs text-slate-600">
                  {camera.id} · {camera.area}
                </span>
              </span>
            </button>
          )
        })}
      </div>
    </aside>
  )
}
