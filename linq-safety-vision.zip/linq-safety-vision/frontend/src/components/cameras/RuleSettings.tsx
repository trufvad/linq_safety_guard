import type { RuleConfig } from '../../types/api'

interface RuleSettingsProps {
  rules: Record<string, RuleConfig>
  onToggle: (rule_type: string, enabled: boolean) => void
}

const ruleLabels: Record<string, string> = {
  danger_zone: 'Вход в нарисованные зоны',
  machine_proximity: 'Сближение с техникой',
  fall: 'Падение сотрудника',
  running: 'Бег в производственной зоне',
  no_helmet: 'Работа без каски',
  phone_use: 'Использование телефона',
  no_ppe: 'Отсутствие СИЗ (модель СИЗ)',
  sudden_move_machine: 'Резкие перемещения в зоне техники',
  open_fire: 'Курение / открытый огонь',
  climb_crawl: 'Перелезание через ограждение / пролезание под конвейером и грузом',
  height_no_harness: 'Работа на высоте без страховки (зона «Работы на высоте»)',
  motionless: 'Неподвижное лежание (потеря сознания)',
  cargo_violation: 'Переноска груза с нарушением правил',
}

export function RuleSettings({ rules, onToggle }: RuleSettingsProps) {
  return (
    <section className="rounded-xl border border-slate-800 bg-[#0c1422] p-4">
      <h3 className="text-sm font-semibold text-slate-100">Правила безопасности</h3>
      <div className="mt-4 space-y-2">
        {Object.entries(rules).map(([rule_type, config]) => (
          <label
            key={rule_type}
            className="flex cursor-pointer items-center justify-between gap-4 rounded-lg border border-slate-800 bg-slate-950/20 px-3 py-2.5"
          >
            <span className="min-w-0">
              <span className="block text-sm font-medium text-slate-200">
                {ruleLabels[rule_type] ?? rule_type}
              </span>
              <span className="mt-0.5 block font-mono text-[10px] text-slate-600">{rule_type}</span>
            </span>
            <input
              type="checkbox"
              checked={config.enabled}
              onChange={(event) => onToggle(rule_type, event.target.checked)}
              className="size-4 accent-cyan-400"
            />
          </label>
        ))}
      </div>
    </section>
  )
}
