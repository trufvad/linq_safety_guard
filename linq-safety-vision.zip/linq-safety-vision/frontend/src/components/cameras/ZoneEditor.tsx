import { useState, type MouseEvent } from 'react'

import type { Zone } from '../../types/api'

interface ZoneEditorProps {
  imageUrl: string
  imageLabel: string
  frameUnavailable?: boolean
  zones: Zone[]
  draftPoints: Array<[number, number]>
  isDrawing: boolean
  selectedZoneId: string | null
  onAddPoint: (point: [number, number]) => void
  onSelectZone: (zone_id: string) => void
  onFrameLoad?: () => void
  onFrameError?: () => void
  onRetryFrame?: () => void
}

const VIEWBOX_WIDTH = 1000

const zoneColors: Record<Zone['kind'], { fill: string; stroke: string }> = {
  danger: { fill: 'rgba(239, 68, 68, 0.18)', stroke: '#f87171' },
  restricted: { fill: 'rgba(245, 158, 11, 0.18)', stroke: '#fbbf24' },
  machine: { fill: 'rgba(34, 211, 238, 0.16)', stroke: '#22d3ee' },
  fence: { fill: 'rgba(249, 115, 22, 0.18)', stroke: '#fb923c' },
  conveyor: { fill: 'rgba(168, 85, 247, 0.18)', stroke: '#c084fc' },
  suspended_load: { fill: 'rgba(236, 72, 153, 0.18)', stroke: '#f472b6' },
  height: { fill: 'rgba(250, 204, 21, 0.16)', stroke: '#facc15' },
  smoking_area: { fill: 'rgba(34, 197, 94, 0.16)', stroke: '#4ade80' },
}

function toSvgPoints(points: Array<[number, number]>, viewBoxHeight: number) {
  return points.map(([x, y]) => `${x * VIEWBOX_WIDTH},${y * viewBoxHeight}`).join(' ')
}

export function ZoneEditor({
  imageUrl,
  imageLabel,
  frameUnavailable,
  zones,
  draftPoints,
  isDrawing,
  selectedZoneId,
  onAddPoint,
  onSelectZone,
  onFrameLoad,
  onFrameError,
  onRetryFrame,
}: ZoneEditorProps) {
  const [aspectRatio, setAspectRatio] = useState(16 / 9)
  const viewBoxHeight = VIEWBOX_WIDTH / aspectRatio

  const handleCanvasClick = (event: MouseEvent<SVGSVGElement>) => {
    if (!isDrawing) return

    const rect = event.currentTarget.getBoundingClientRect()
    const x = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width))
    const y = Math.min(1, Math.max(0, (event.clientY - rect.top) / rect.height))
    onAddPoint([Number(x.toFixed(4)), Number(y.toFixed(4))])
  }

  return (
    <div
      className="relative overflow-hidden rounded-xl border border-slate-700 bg-slate-950"
      style={{ aspectRatio }}
    >
      <img
        key={imageUrl}
        src={imageUrl}
        alt={imageLabel}
        className="absolute inset-0 size-full object-contain"
        onLoad={(event) => {
          const image = event.currentTarget
          if (image.naturalWidth && image.naturalHeight) {
            setAspectRatio(image.naturalWidth / image.naturalHeight)
          }
          onFrameLoad?.()
        }}
        onError={onFrameError}
      />
      <svg
        className={`absolute inset-0 size-full ${isDrawing ? 'cursor-crosshair' : 'cursor-default'}`}
        viewBox={`0 0 ${VIEWBOX_WIDTH} ${viewBoxHeight}`}
        onClick={handleCanvasClick}
        role="img"
        aria-label="Редактор опасных зон"
      >
        <g pointerEvents={isDrawing ? 'none' : 'auto'}>
          {zones.map((zone) => {
            const color = zoneColors[zone.kind] ?? zoneColors.danger
            const [labelX, labelY] = zone.polygon[0]

            return (
              <g key={zone.id} onClick={() => onSelectZone(zone.id)} className="cursor-pointer">
                <polygon
                  points={toSvgPoints(zone.polygon, viewBoxHeight)}
                  fill={color.fill}
                  stroke={color.stroke}
                  strokeWidth={zone.id === selectedZoneId ? 4 : 2.5}
                  vectorEffect="non-scaling-stroke"
                />
                <text
                  x={labelX * VIEWBOX_WIDTH + 10}
                  y={Math.max(22, labelY * viewBoxHeight - 10)}
                  fill={color.stroke}
                  fontSize="18"
                  fontWeight="700"
                  paintOrder="stroke"
                  stroke="rgba(8, 13, 23, 0.9)"
                  strokeWidth="5"
                >
                  {zone.name}
                </text>
              </g>
            )
          })}
        </g>

        {draftPoints.length > 1 && (
          <polyline
            points={toSvgPoints(draftPoints, viewBoxHeight)}
            fill={draftPoints.length >= 3 ? 'rgba(34, 211, 238, 0.12)' : 'none'}
            stroke="#67e8f9"
            strokeWidth="3"
            strokeDasharray="10 7"
            vectorEffect="non-scaling-stroke"
          />
        )}
        {draftPoints.map(([x, y], index) => (
          <circle
            key={`${x}-${y}-${index}`}
            cx={x * VIEWBOX_WIDTH}
            cy={y * viewBoxHeight}
            r="7"
            fill="#ecfeff"
            stroke="#0891b2"
            strokeWidth="3"
            vectorEffect="non-scaling-stroke"
          />
        ))}
      </svg>

      {frameUnavailable && (
        <div className="absolute inset-0 z-10 grid place-items-center bg-slate-950/90 px-6 text-center">
          <div>
            <p className="text-sm font-medium text-slate-300">Стоп-кадр пока недоступен</p>
            <p className="mt-2 text-xs text-slate-600">Запустите камеру или повторите запрос.</p>
            {onRetryFrame && (
              <button
                type="button"
                onClick={onRetryFrame}
                className="mt-4 rounded-lg border border-cyan-400/30 px-3 py-2 text-xs font-semibold text-cyan-300"
              >
                Повторить
              </button>
            )}
          </div>
        </div>
      )}

      <div className="pointer-events-none absolute bottom-3 left-3 rounded-md bg-slate-950/75 px-2.5 py-1.5 text-[10px] font-semibold uppercase tracking-[0.1em] text-slate-300 backdrop-blur-sm">
        {isDrawing ? `Точек: ${draftPoints.length} · Нажимайте на кадр` : imageLabel}
      </div>
    </div>
  )
}
