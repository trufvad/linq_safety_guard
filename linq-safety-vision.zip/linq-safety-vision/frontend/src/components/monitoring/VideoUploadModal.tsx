import { CheckCircle2, FileVideo, UploadCloud, X } from 'lucide-react'
import { useEffect, useRef, useState, type ChangeEvent, type DragEvent, type FormEvent } from 'react'

import { api, type VideoUploadResponse } from '../../api/api'
import type { Camera } from '../../types/api'

const ACCEPT = '.mp4,.avi,.mkv,.mov,.m4v,.webm,video/mp4,video/x-msvideo,video/x-matroska,video/quicktime,video/webm'
const ALLOWED = ['mp4', 'avi', 'mkv', 'mov', 'm4v', 'webm']

interface VideoUploadModalProps {
  cameras: Camera[]
  selectedCameraId?: string
  onClose: () => void
  onUploaded: (result: VideoUploadResponse) => void | Promise<void>
}

function formatSize(bytes: number) {
  return bytes > 1024 ** 3 ? `${(bytes / 1024 ** 3).toFixed(2)} ГБ` : `${(bytes / 1024 ** 2).toFixed(1)} МБ`
}

export function VideoUploadModal({ cameras, selectedCameraId, onClose, onUploaded }: VideoUploadModalProps) {
  const [file, setFile] = useState<File | null>(null)
  const [mode, setMode] = useState<'new' | 'replace'>('new')
  const [name, setName] = useState('')
  const [area, setArea] = useState('Цех 1')
  const [cameraId, setCameraId] = useState(selectedCameraId ?? cameras[0]?.id ?? '')
  const [progress, setProgress] = useState<number | null>(null)
  const [error, setError] = useState('')
  const [done, setDone] = useState<VideoUploadResponse | null>(null)
  const [dragOver, setDragOver] = useState(false)
  const abort = useRef<AbortController | null>(null)
  const uploading = progress !== null && !done

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !uploading) onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose, uploading])

  useEffect(() => () => abort.current?.abort(), [])

  const pickFile = (candidate: File | undefined) => {
    if (!candidate) return
    const ext = candidate.name.split('.').pop()?.toLowerCase() ?? ''
    if (!ALLOWED.includes(ext)) {
      setError(`Формат .${ext} не поддерживается. Подойдут: ${ALLOWED.join(', ')}`)
      return
    }
    setError('')
    setFile(candidate)
    if (!name) setName(candidate.name.replace(/\.[^.]+$/, ''))
  }

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault()
    if (!file) {
      setError('Выберите видеофайл')
      return
    }
    if (mode === 'replace' && !cameraId) {
      setError('Выберите камеру')
      return
    }
    setError('')
    setProgress(0)
    abort.current = new AbortController()
    try {
      const result = await api.uploadVideo(file, {
        mode,
        camera_id: mode === 'replace' ? cameraId : undefined,
        name: mode === 'new' ? name.trim() || undefined : undefined,
        area: mode === 'new' ? area.trim() || undefined : undefined,
        onProgress: setProgress,
        signal: abort.current.signal,
      })
      setProgress(1)
      setDone(result)
      await onUploaded(result)
    } catch (uploadError) {
      setProgress(null)
      setError(uploadError instanceof Error ? uploadError.message : 'Не удалось загрузить видео')
    }
  }

  const inputClass =
    'mt-1.5 w-full rounded-lg border border-slate-700 bg-slate-950/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-cyan-400/60'

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-slate-950/80 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="video-upload-title"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget && !uploading) onClose()
      }}
    >
      <form
        onSubmit={(event) => void handleSubmit(event)}
        className="max-h-[calc(100vh-2rem)] w-full max-w-lg overflow-y-auto rounded-2xl border border-slate-700 bg-[#0c1422] shadow-2xl shadow-black/50"
      >
        <div className="flex items-start justify-between gap-4 border-b border-slate-800 px-6 py-5">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.12em] text-cyan-400">Источник видео</p>
            <h2 id="video-upload-title" className="mt-1 text-lg font-semibold text-white">
              Загрузить видеофайл
            </h2>
            <p className="mt-1 text-xs text-slate-500">
              Видео проигрывается по кругу как камера: детекция, трекинг и правила ТБ работают в реальном времени.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={uploading}
            aria-label="Закрыть"
            className="rounded-lg border border-slate-700 p-2 text-slate-400 hover:text-white disabled:opacity-40"
          >
            <X size={16} />
          </button>
        </div>

        <div className="space-y-5 px-6 py-5">
          <label
            onDragOver={(event: DragEvent) => {
              event.preventDefault()
              setDragOver(true)
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(event: DragEvent) => {
              event.preventDefault()
              setDragOver(false)
              pickFile(event.dataTransfer.files?.[0])
            }}
            className={`flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border border-dashed px-4 py-8 text-center transition-colors ${
              dragOver ? 'border-cyan-400 bg-cyan-400/[0.06]' : 'border-slate-700 hover:border-cyan-400/50'
            }`}
            style={dragOver ? { borderColor: '#22d3ee' } : undefined}
          >
            {file ? <FileVideo size={28} className="text-cyan-300" /> : <UploadCloud size={28} className="text-slate-400" />}
            <span className="text-sm font-medium text-slate-200">
              {file ? file.name : 'Перетащите файл сюда или нажмите, чтобы выбрать'}
            </span>
            <span className="text-xs text-slate-500">
              {file ? formatSize(file.size) : 'MP4, AVI, MKV, MOV, WEBM'}
            </span>
            <input
              className="sr-only"
              type="file"
              accept={ACCEPT}
              data-testid="video-file-input"
              disabled={uploading}
              onChange={(event: ChangeEvent<HTMLInputElement>) => {
                pickFile(event.target.files?.[0])
                event.target.value = ''
              }}
            />
          </label>

          <fieldset disabled={uploading}>
            <legend className="text-xs font-medium uppercase tracking-[0.12em] text-slate-500">Куда подключить</legend>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {(
                [
                  ['new', 'Новая камера'],
                  ['replace', 'Заменить источник камеры'],
                ] as const
              ).map(([value, label]) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setMode(value)}
                  disabled={value === 'replace' && !cameras.length}
                  aria-pressed={mode === value}
                  className={`rounded-lg border px-3 py-2.5 text-xs font-semibold transition-colors disabled:opacity-40 ${
                    mode === value
                      ? 'border-cyan-400/60 bg-cyan-400/10 text-cyan-200'
                      : 'border-slate-700 text-slate-300 hover:border-slate-500'
                  }`}
                  style={mode === value ? { borderColor: 'rgba(34,211,238,0.6)', color: '#a5f3fc' } : undefined}
                >
                  {label}
                </button>
              ))}
            </div>

            {mode === 'new' ? (
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <label className="block text-xs text-slate-400">
                  Название камеры
                  <input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} placeholder="Ворота склада" />
                </label>
                <label className="block text-xs text-slate-400">
                  Участок / цех
                  <input className={inputClass} value={area} onChange={(e) => setArea(e.target.value)} placeholder="Цех 1" />
                </label>
              </div>
            ) : (
              <label className="mt-4 block text-xs text-slate-400">
                Камера
                <select className={inputClass} value={cameraId} onChange={(e) => setCameraId(e.target.value)}>
                  {cameras.map((camera) => (
                    <option key={camera.id} value={camera.id}>
                      {camera.name} · {camera.id}
                    </option>
                  ))}
                </select>
                <span className="mt-1 block text-[11px] text-slate-500">Зоны и правила камеры сохранятся.</span>
              </label>
            )}
          </fieldset>

          {progress !== null && (
            <div aria-live="polite">
              <div className="flex justify-between text-xs text-slate-400">
                <span>{done ? 'Готово' : progress >= 1 ? 'Проверка видео на сервере…' : 'Загрузка…'}</span>
                <span>{Math.round(progress * 100)}%</span>
              </div>
              <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full rounded-full bg-cyan-400 transition-all"
                  style={{ width: `${Math.round(progress * 100)}%`, background: '#22d3ee' }}
                />
              </div>
            </div>
          )}

          {done && (
            <p className="flex items-start gap-2 rounded-lg border border-emerald-500/20 bg-emerald-500/[0.06] px-3 py-2.5 text-xs text-emerald-300">
              <CheckCircle2 size={16} className="mt-0.5 shrink-0" />
              <span>
                Видео подключено к камере <b>{done.camera_id}</b>
                {done.video.duration_s ? ` · ${done.video.width}×${done.video.height}, ${done.video.duration_s} с` : ''}.
                Опасные зоны можно нарисовать в разделе «Настройка камер».
              </span>
            </p>
          )}

          {error && (
            <p role="alert" className="rounded-lg border border-red-500/20 bg-red-500/[0.06] px-3 py-2.5 text-xs text-red-300">
              {error}
            </p>
          )}
        </div>

        <div className="flex justify-end gap-2 border-t border-slate-800 px-6 py-4">
          {uploading ? (
            <button
              type="button"
              onClick={() => abort.current?.abort()}
              className="rounded-lg border border-slate-700 px-4 py-2.5 text-xs font-semibold text-slate-300 hover:border-red-400/50 hover:text-red-300"
            >
              Отменить
            </button>
          ) : (
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-700 px-4 py-2.5 text-xs font-semibold text-slate-300 hover:border-slate-500"
            >
              {done ? 'Закрыть' : 'Отмена'}
            </button>
          )}
          {!done && (
            <button
              type="submit"
              disabled={uploading || !file}
              className="inline-flex items-center gap-2 rounded-lg bg-cyan-400 px-4 py-2.5 text-xs font-semibold text-slate-950 hover:bg-cyan-300 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <UploadCloud size={15} />
              {uploading ? 'Загрузка…' : 'Загрузить и запустить'}
            </button>
          )}
        </div>
      </form>
    </div>
  )
}
