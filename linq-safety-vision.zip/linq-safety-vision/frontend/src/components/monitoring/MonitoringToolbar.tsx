import { Grid2X2, Maximize2, UploadCloud } from 'lucide-react'

import type { Camera } from '../../types/api'

interface MonitoringToolbarProps {
  selectedCamera: Camera
  isExpanded: boolean
  cameraActionLabel?: string
  cameraActionBusy?: boolean
  onToggleExpanded: () => void
  onCameraAction?: () => void
  onUploadVideo?: () => void
}

export function MonitoringToolbar({
  selectedCamera,
  isExpanded,
  cameraActionLabel,
  cameraActionBusy,
  onToggleExpanded,
  onCameraAction,
  onUploadVideo,
}: MonitoringToolbarProps) {
  return (
    <section className="mb-5 flex flex-col gap-4 rounded-xl border border-slate-800 bg-[#0c1422] p-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0">
        <p className="text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
          Выбрана камера {selectedCamera.id}
        </p>
        <p className="mt-1 truncate text-sm font-semibold text-slate-100">
          {selectedCamera.name} · {selectedCamera.area}
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {onUploadVideo && (
          <button
            type="button"
            onClick={onUploadVideo}
            className="inline-flex items-center gap-2 rounded-lg border border-cyan-400/40 px-3.5 py-2.5 text-xs font-semibold text-cyan-200 transition-colors hover:bg-cyan-400/10"
          >
            <UploadCloud size={16} aria-hidden="true" />
            Загрузить видео
          </button>
        )}
        {cameraActionLabel && onCameraAction && (
          <button
            type="button"
            onClick={onCameraAction}
            disabled={cameraActionBusy}
            className="rounded-lg bg-cyan-400 px-3.5 py-2.5 text-xs font-semibold text-slate-950 hover:bg-cyan-300 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {cameraActionBusy ? 'Выполнение…' : cameraActionLabel}
          </button>
        )}
        <button
          type="button"
          onClick={onToggleExpanded}
          className="inline-flex items-center gap-2 rounded-lg border border-slate-700 px-3.5 py-2.5 text-xs font-semibold text-slate-300 transition-colors hover:border-cyan-400/40 hover:text-cyan-300"
        >
          {isExpanded ? <Grid2X2 size={16} /> : <Maximize2 size={16} />}
          {isExpanded ? 'Показать сетку' : 'Увеличить камеру'}
        </button>
      </div>
    </section>
  )
}
