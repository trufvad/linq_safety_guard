import { Expand, Minimize2, VideoOff } from 'lucide-react'
import { useEffect, useState } from 'react'

import type { Camera } from '../../types/api'
import type { CameraStream } from '../../types/monitoring'

interface CameraCardProps {
  camera: Camera
  stream?: CameraStream
  aspectRatio: number
  isSelected: boolean
  isExpanded: boolean
  onSelect: (cameraId: string) => void
  onToggleExpanded: () => void
}

export function CameraCard({
  camera,
  stream,
  aspectRatio,
  isSelected,
  isExpanded,
  onSelect,
  onToggleExpanded,
}: CameraCardProps) {
  const [streamError, setStreamError] = useState(false)

  useEffect(() => setStreamError(false), [stream?.url])

  const streamStatus =
    stream
      ? 'Видеопоток с разметкой'
      : camera.status === 'error'
        ? 'Ошибка камеры'
        : camera.status === 'stopped'
          ? 'Камера остановлена'
          : 'Ожидает видео'

  return (
    <article
      className={`overflow-hidden rounded-xl border bg-[#0c1422] transition-colors ${
        isSelected
          ? 'border-cyan-400/60 ring-1 ring-cyan-400/20'
          : 'border-slate-800 hover:border-slate-700'
      }`}
    >
      <div className="flex items-center justify-between gap-3 border-b border-slate-800 px-4 py-3">
        <button
          type="button"
          className="min-w-0 text-left"
          onClick={() => onSelect(camera.id)}
          aria-pressed={isSelected}
        >
          <span className="block truncate text-sm font-semibold text-slate-100">
            {camera.name} · {camera.id}
          </span>
          <span className="mt-1 flex items-center gap-2 text-xs text-slate-500">
            <span
              className={`size-1.5 rounded-full ${
                camera.status === 'running'
                  ? 'bg-emerald-400'
                  : camera.status === 'error'
                    ? 'bg-red-400'
                    : 'bg-slate-500'
              }`}
            />
            {streamStatus}
          </span>
        </button>

        {isSelected && (
          <button
            type="button"
            onClick={onToggleExpanded}
            className="grid size-9 shrink-0 place-items-center rounded-lg border border-slate-700 text-slate-400 transition-colors hover:border-cyan-400/40 hover:text-cyan-300"
            aria-label={isExpanded ? 'Вернуться к сетке камер' : 'Увеличить выбранную камеру'}
            title={isExpanded ? 'Вернуться к сетке' : 'Увеличить камеру'}
          >
            {isExpanded ? <Minimize2 size={17} /> : <Expand size={17} />}
          </button>
        )}
      </div>

      <div
        className="relative overflow-hidden bg-[#05080e]"
        style={{ aspectRatio }}
        onClick={() => onSelect(camera.id)}
      >
        {stream ? (
          <img
            key={stream.url}
            className="size-full bg-black object-contain"
            src={stream.url}
            alt={`Видеопоток камеры ${camera.id}`}
            onClick={(event) => event.stopPropagation()}
            onLoad={() => setStreamError(false)}
            onError={() => setStreamError(true)}
          />
        ) : (
          <div className="grid size-full place-items-center">
            <div className="text-center text-slate-600">
              <VideoOff className="mx-auto" size={28} strokeWidth={1.5} />
              <p className="mt-2 text-xs">
                {camera.status === 'stopped'
                  ? 'Камера остановлена'
                  : camera.status === 'error'
                    ? camera.error || 'Ошибка источника видео'
                    : 'Видео недоступно'}
              </p>
            </div>
          </div>
        )}

        {streamError && (
          <div className="absolute inset-0 grid place-items-center bg-slate-950/85 px-6 text-center text-xs text-red-300">
            Видеопоток временно недоступен
          </div>
        )}
      </div>

      <dl className="grid grid-cols-2 divide-x divide-slate-800 border-t border-slate-800">
        <div className="px-4 py-3">
          <dt className="text-[10px] font-medium uppercase tracking-wider text-slate-600">FPS</dt>
          <dd className="mt-1 text-xs font-medium text-slate-300">
            {camera.stats.fps.toFixed(1)}
          </dd>
        </div>
        <div className="px-4 py-3">
          <dt className="text-[10px] font-medium uppercase tracking-wider text-slate-600">
            Задержка инференса
          </dt>
          <dd className="mt-1 text-xs font-medium text-slate-300">
            {`${camera.stats.latency_ms.toFixed(1)} мс`}
          </dd>
        </div>
      </dl>
    </article>
  )
}
