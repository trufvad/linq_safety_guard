import { RotateCcw, Search } from 'lucide-react'

import type { IncidentStatus, Severity } from '../../types/api'
import { incidentStatusLabels, severityLabels } from '../../utils/incidentPresentation'

export interface IncidentFilterValues {
  search: string
  date_from: string
  date_to: string
  camera_id: string
  violation_type: string
  status: IncidentStatus | ''
  severity: Severity | ''
  sort: 'newest' | 'oldest'
}

interface IncidentFiltersProps {
  filters: IncidentFilterValues
  cameraOptions: Array<{ id: string; name: string }>
  violationOptions: Array<{ type: string; title: string }>
  onChange: (update: Partial<IncidentFilterValues>) => void
  onReset: () => void
}

const inputClasses =
  'w-full rounded-lg border border-slate-700 bg-slate-950/40 px-3 py-2.5 text-sm text-slate-200 outline-none focus:border-cyan-400/50'

export function IncidentFilters({
  filters,
  cameraOptions,
  violationOptions,
  onChange,
  onReset,
}: IncidentFiltersProps) {
  return (
    <section className="rounded-xl border border-slate-800 bg-[#0c1422] p-4">
      <div className="relative">
        <Search
          size={16}
          className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-600"
          aria-hidden="true"
        />
        <input
          type="search"
          value={filters.search}
          onChange={(event) => onChange({ search: event.target.value })}
          placeholder="Поиск по событию, камере или участку"
          className={`${inputClasses} pl-10`}
        />
      </div>

      <div className="mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <label>
          <span className="mb-1.5 block text-xs text-slate-500">Дата от</span>
          <input
            type="date"
            value={filters.date_from}
            onChange={(event) => onChange({ date_from: event.target.value })}
            className={inputClasses}
          />
        </label>
        <label>
          <span className="mb-1.5 block text-xs text-slate-500">Дата до</span>
          <input
            type="date"
            value={filters.date_to}
            onChange={(event) => onChange({ date_to: event.target.value })}
            className={inputClasses}
          />
        </label>
        <label>
          <span className="mb-1.5 block text-xs text-slate-500">Камера</span>
          <select
            value={filters.camera_id}
            onChange={(event) => onChange({ camera_id: event.target.value })}
            className={inputClasses}
          >
            <option value="">Все камеры</option>
            {cameraOptions.map((camera) => (
              <option key={camera.id} value={camera.id}>
                {camera.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          <span className="mb-1.5 block text-xs text-slate-500">Тип нарушения</span>
          <select
            value={filters.violation_type}
            onChange={(event) => onChange({ violation_type: event.target.value })}
            className={inputClasses}
          >
            <option value="">Все типы</option>
            {violationOptions.map((violation) => (
              <option key={violation.type} value={violation.type}>
                {violation.title}
              </option>
            ))}
          </select>
        </label>
        <label>
          <span className="mb-1.5 block text-xs text-slate-500">Статус</span>
          <select
            value={filters.status}
            onChange={(event) => onChange({ status: event.target.value as IncidentStatus | '' })}
            className={inputClasses}
          >
            <option value="">Все статусы</option>
            {Object.entries(incidentStatusLabels).map(([status, label]) => (
              <option key={status} value={status}>
                {label}
              </option>
            ))}
          </select>
        </label>
        <label>
          <span className="mb-1.5 block text-xs text-slate-500">Уровень опасности</span>
          <select
            value={filters.severity}
            onChange={(event) => onChange({ severity: event.target.value as Severity | '' })}
            className={inputClasses}
          >
            <option value="">Все уровни</option>
            {Object.entries(severityLabels).map(([severity, label]) => (
              <option key={severity} value={severity}>
                {label}
              </option>
            ))}
          </select>
        </label>
        <label>
          <span className="mb-1.5 block text-xs text-slate-500">Сортировка по времени</span>
          <select
            value={filters.sort}
            onChange={(event) =>
              onChange({ sort: event.target.value as IncidentFilterValues['sort'] })
            }
            className={inputClasses}
          >
            <option value="newest">Сначала новые</option>
            <option value="oldest">Сначала старые</option>
          </select>
        </label>
        <div className="flex items-end">
          <button
            type="button"
            onClick={onReset}
            className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-slate-700 px-3 py-2.5 text-sm font-medium text-slate-400 hover:border-slate-600 hover:text-slate-200"
          >
            <RotateCcw size={15} aria-hidden="true" />
            Сбросить фильтры
          </button>
        </div>
      </div>
    </section>
  )
}
