interface MetricCardProps {
  label: string
  value: number
  tone?: 'default' | 'cyan' | 'red'
}

export function MetricCard({ label, value, tone = 'default' }: MetricCardProps) {
  const valueColor = tone === 'red' ? 'text-red-300' : tone === 'cyan' ? 'text-cyan-300' : 'text-white'

  return (
    <div className="rounded-xl border border-slate-800 bg-[#0c1422] p-5">
      <p className="text-xs font-medium text-slate-500">{label}</p>
      <p className={`mt-3 text-3xl font-semibold tabular-nums ${valueColor}`}>{value}</p>
    </div>
  )
}
