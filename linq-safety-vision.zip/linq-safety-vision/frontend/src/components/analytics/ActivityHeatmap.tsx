interface ActivityHeatmapProps {
  heatmap: number[][]
  timeZone: string
}

const weekdays = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']
const hours = Array.from({ length: 24 }, (_, hour) => hour)

export function ActivityHeatmap({ heatmap, timeZone }: ActivityHeatmapProps) {
  const maxValue = Math.max(0, ...heatmap.flat())

  return (
    <section className="rounded-xl border border-slate-800 bg-[#0c1422] p-5">
      <div className="mb-5 flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h3 className="text-sm font-semibold text-slate-200">Активность по дням и часам</h3>
          <p className="mt-1 text-xs text-slate-600">Первая строка — понедельник</p>
        </div>
        <p className="text-xs text-slate-500">Часовой пояс: {timeZone}</p>
      </div>

      {maxValue === 0 ? (
        <p className="py-16 text-center text-sm text-slate-500">Недостаточно данных</p>
      ) : (
        <div className="overflow-x-auto pb-2">
          <div
            className="grid min-w-[780px] gap-1"
            style={{ gridTemplateColumns: '44px repeat(24, minmax(24px, 1fr))' }}
          >
            <div />
            {hours.map((hour) => (
              <div key={hour} className="pb-1 text-center text-[9px] text-slate-600">
                {String(hour).padStart(2, '0')}
              </div>
            ))}

            {weekdays.map((weekday, dayIndex) => (
              <div key={weekday} className="contents">
                <div className="flex items-center text-xs text-slate-500">{weekday}</div>
                {hours.map((hour) => {
                  const value = heatmap[dayIndex]?.[hour] ?? 0
                  const opacity = value === 0 ? 0.04 : 0.18 + (value / maxValue) * 0.72

                  return (
                    <div
                      key={hour}
                      className="aspect-square min-h-6 rounded-sm border border-slate-800/70"
                      style={{ backgroundColor: `rgba(34, 211, 238, ${opacity})` }}
                      title={`${weekday}, ${String(hour).padStart(2, '0')}:00 — ${value}`}
                      aria-label={`${weekday}, ${hour}:00, нарушений: ${value}`}
                    />
                  )
                })}
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  )
}
