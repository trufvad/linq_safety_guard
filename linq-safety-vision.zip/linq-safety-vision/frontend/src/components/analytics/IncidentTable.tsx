import { Eye } from 'lucide-react'

import type { Incident } from '../../types/api'
import {
  formatIncidentDateTime,
  incidentStatusLabels,
  severityLabels,
} from '../../utils/incidentPresentation'

interface IncidentTableProps {
  incidents: Incident[]
  onOpen: (incident_id: string) => void
}

export function IncidentTable({ incidents, onOpen }: IncidentTableProps) {
  return (
    <div className="overflow-x-auto rounded-xl border border-slate-800 bg-[#0c1422]">
      <table className="w-full min-w-[1080px] border-collapse text-left">
        <thead>
          <tr className="border-b border-slate-800 text-[10px] font-semibold uppercase tracking-[0.1em] text-slate-600">
            <th className="px-4 py-3">Дата и время</th>
            <th className="px-4 py-3">Камера</th>
            <th className="px-4 py-3">Участок</th>
            <th className="px-4 py-3">Опасная зона</th>
            <th className="px-4 py-3">Тип нарушения</th>
            <th className="px-4 py-3">Опасность</th>
            <th className="px-4 py-3">Статус</th>
            <th className="px-4 py-3 text-right">Действие</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-800/80">
          {incidents.map((incident) => {
            const isCritical = incident.severity === 'critical'

            return (
              <tr key={incident.id} className={isCritical ? 'bg-red-500/[0.035]' : ''}>
                <td className="whitespace-nowrap px-4 py-3 text-xs text-slate-400">
                  {formatIncidentDateTime(incident.started_at)}
                </td>
                <td className="max-w-48 px-4 py-3 text-sm font-medium text-slate-200">
                  <span className="block truncate">{incident.camera_name || '—'}</span>
                </td>
                <td className="px-4 py-3 text-xs text-slate-400">{incident.area || '—'}</td>
                <td className="px-4 py-3 text-xs text-slate-400">{incident.zone_name || '—'}</td>
                <td className="max-w-60 px-4 py-3">
                  <span className="block truncate text-sm text-slate-200">{incident.title || '—'}</span>
                  <span className="mt-0.5 block font-mono text-[10px] text-slate-600">
                    {incident.violation_type || '—'}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`rounded-full px-2 py-1 text-[10px] font-bold uppercase tracking-[0.08em] ${
                      isCritical
                        ? 'bg-red-500/10 text-red-300'
                        : incident.severity === 'warning'
                          ? 'bg-amber-400/10 text-amber-300'
                          : 'bg-slate-700/60 text-slate-300'
                    }`}
                  >
                    {severityLabels[incident.severity]}
                  </span>
                </td>
                <td className="px-4 py-3 text-xs font-medium text-slate-300">
                  {incidentStatusLabels[incident.status]}
                </td>
                <td className="px-4 py-3 text-right">
                  <button
                    type="button"
                    onClick={() => onOpen(incident.id)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 px-2.5 py-2 text-xs font-medium text-slate-400 hover:border-cyan-400/30 hover:text-cyan-300"
                  >
                    <Eye size={14} aria-hidden="true" />
                    Подробнее
                  </button>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
