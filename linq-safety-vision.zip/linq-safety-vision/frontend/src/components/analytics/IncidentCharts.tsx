import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'

import type { StatisticsSummary } from '../../types/api'

interface IncidentChartsProps {
  summary: StatisticsSummary
}

const tooltipStyle = {
  backgroundColor: '#0f172a',
  border: '1px solid #334155',
  borderRadius: 8,
  color: '#e2e8f0',
  fontSize: 12,
}

function ChartCard({ title, hasData, children }: { title: string; hasData: boolean; children: React.ReactNode }) {
  return (
    <section className="rounded-xl border border-slate-800 bg-[#0c1422] p-5">
      <h3 className="mb-5 text-sm font-semibold text-slate-200">{title}</h3>
      {hasData ? <div className="h-72">{children}</div> : <p className="py-28 text-center text-sm text-slate-500">Недостаточно данных</p>}
    </section>
  )
}

export function IncidentCharts({ summary }: IncidentChartsProps) {
  const typeData = summary.by_type.map((item) => ({ name: item.title || item.violation_type, n: item.n }))
  const cameraData = summary.by_camera.map((item) => ({ name: item.camera_name || item.camera_id, n: item.n }))
  const dayData = summary.by_day.map((item) => {
    const [, month, day] = item.day.split('-')
    return { name: `${day}.${month}`, n: item.n }
  })

  return (
    <div className="grid gap-4 xl:grid-cols-2">
      <ChartCard title="Нарушения по типам" hasData={typeData.length > 0}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={typeData} margin={{ top: 8, right: 8, left: -20, bottom: 36 }}>
            <CartesianGrid stroke="#1e293b" vertical={false} />
            <XAxis dataKey="name" stroke="#64748b" fontSize={10} angle={-18} textAnchor="end" interval={0} />
            <YAxis stroke="#64748b" fontSize={10} allowDecimals={false} />
            <Tooltip contentStyle={tooltipStyle} cursor={{ fill: '#172033' }} />
            <Bar dataKey="n" name="Нарушения" fill="#22d3ee" radius={[4, 4, 0, 0]} isAnimationActive={false} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Нарушения по камерам" hasData={cameraData.length > 0}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={cameraData} margin={{ top: 8, right: 8, left: -20, bottom: 36 }}>
            <CartesianGrid stroke="#1e293b" vertical={false} />
            <XAxis dataKey="name" stroke="#64748b" fontSize={10} angle={-18} textAnchor="end" interval={0} />
            <YAxis stroke="#64748b" fontSize={10} allowDecimals={false} />
            <Tooltip contentStyle={tooltipStyle} cursor={{ fill: '#172033' }} />
            <Bar dataKey="n" name="Нарушения" fill="#38bdf8" radius={[4, 4, 0, 0]} isAnimationActive={false} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <div className="xl:col-span-2">
        <ChartCard title="Динамика нарушений по датам" hasData={dayData.length > 0}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={dayData} margin={{ top: 8, right: 16, left: -20, bottom: 8 }}>
              <CartesianGrid stroke="#1e293b" vertical={false} />
              <XAxis dataKey="name" stroke="#64748b" fontSize={10} />
              <YAxis stroke="#64748b" fontSize={10} allowDecimals={false} />
              <Tooltip contentStyle={tooltipStyle} />
              <Line type="monotone" dataKey="n" name="Нарушения" stroke="#22d3ee" strokeWidth={2} dot={{ r: 3 }} isAnimationActive={false} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  )
}
