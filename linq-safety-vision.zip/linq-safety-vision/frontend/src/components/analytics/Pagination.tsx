import { ChevronLeft, ChevronRight } from 'lucide-react'

interface PaginationProps {
  currentPage: number
  totalPages: number
  totalItems: number
  onChange: (page: number) => void
}

export function Pagination({ currentPage, totalPages, totalItems, onChange }: PaginationProps) {
  return (
    <div className="flex flex-col gap-3 rounded-xl border border-slate-800 bg-[#0c1422] px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
      <p className="text-xs text-slate-500">
        Найдено событий: <span className="font-semibold text-slate-300">{totalItems}</span>
      </p>
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={() => onChange(currentPage - 1)}
          disabled={currentPage <= 1}
          className="grid size-8 place-items-center rounded-lg border border-slate-700 text-slate-400 disabled:cursor-not-allowed disabled:opacity-35"
          aria-label="Предыдущая страница"
        >
          <ChevronLeft size={16} />
        </button>
        <span className="min-w-20 text-center text-xs text-slate-400">
          {currentPage} из {totalPages}
        </span>
        <button
          type="button"
          onClick={() => onChange(currentPage + 1)}
          disabled={currentPage >= totalPages}
          className="grid size-8 place-items-center rounded-lg border border-slate-700 text-slate-400 disabled:cursor-not-allowed disabled:opacity-35"
          aria-label="Следующая страница"
        >
          <ChevronRight size={16} />
        </button>
      </div>
    </div>
  )
}
