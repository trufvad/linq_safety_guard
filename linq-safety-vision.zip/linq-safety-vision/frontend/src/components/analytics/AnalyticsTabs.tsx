export type AnalyticsTab = 'journal' | 'statistics'

interface AnalyticsTabsProps {
  activeTab: AnalyticsTab
  onChange: (tab: AnalyticsTab) => void
}

const tabs: Array<{ id: AnalyticsTab; label: string }> = [
  { id: 'journal', label: 'Журнал нарушений' },
  { id: 'statistics', label: 'Статистика' },
]

export function AnalyticsTabs({ activeTab, onChange }: AnalyticsTabsProps) {
  return (
    <div className="mb-5 flex w-fit rounded-lg border border-slate-800 bg-[#0c1422] p-1">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          type="button"
          onClick={() => onChange(tab.id)}
          className={`rounded-md px-4 py-2 text-sm font-medium transition-colors ${
            activeTab === tab.id
              ? 'bg-cyan-400/10 text-cyan-300'
              : 'text-slate-500 hover:text-slate-300'
          }`}
          aria-pressed={activeTab === tab.id}
        >
          {tab.label}
        </button>
      ))}
    </div>
  )
}
