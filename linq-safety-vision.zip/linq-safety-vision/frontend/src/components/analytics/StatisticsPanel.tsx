import { useEffect, useMemo, useRef, useState } from 'react'

import { api } from '../../api/api'
import type { Incident, StatisticsSummary } from '../../types/api'
import {
  getStatisticsPeriodRange,
  getStatusCount,
  STATISTICS_TIME_ZONE,
  type StatisticsPeriod,
} from '../../utils/incidentStatistics'
import { ActivityHeatmap } from './ActivityHeatmap'
import { IncidentCharts } from './IncidentCharts'
import { MetricCard } from './MetricCard'

interface StatisticsPanelProps {
  incidents: Incident[]
  period: StatisticsPeriod
  onPeriodChange: (period: StatisticsPeriod) => void
}

const periods: Array<{ value: StatisticsPeriod; label: string }> = [
  { value: 'today', label: 'Сегодня' },
  { value: '7days', label: 'Последние 7 дней' },
  { value: '30days', label: 'Последние 30 дней' },
  { value: 'all', label: 'Всё время' },
]

export default function StatisticsPanel({ incidents, period, onPeriodChange }: StatisticsPanelProps) {
  // Пересчитываем при каждом новом событии или смене статуса — статистика обновляется вживую
  const incidentsVersion = useMemo(
    () => incidents.map((incident) => `${incident.id}:${incident.status}`).join('|'),
    [incidents],
  )
  const [serverSummary, setServerSummary] = useState<StatisticsSummary | null>(null)
  const serverSummaryRef = useRef<StatisticsSummary | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    let active = true
    setIsLoading((current) => current || serverSummaryRef.current === null)
    setError('')
    void api
      .getStatisticsSummary(getStatisticsPeriodRange(period))
      .then((response) => {
        if (!active) return
        serverSummaryRef.current = response
        setServerSummary(response)
      })
      .catch((requestError) => {
        if (active) {
          setServerSummary(null)
          setError(requestError instanceof Error ? requestError.message : 'Не удалось загрузить статистику')
        }
      })
      .finally(() => active && setIsLoading(false))
    return () => {
      active = false
    }
  }, [period, incidentsVersion])

  const summary = serverSummary

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 rounded-xl border border-slate-800 bg-[#0c1422] p-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm font-medium text-slate-300">Период статистики</p>
          <p className="mt-1 text-xs text-slate-600">
            Обновляется автоматически · {STATISTICS_TIME_ZONE}
          </p>
        </div>
        <select
          value={period}
          onChange={(event) => onPeriodChange(event.target.value as StatisticsPeriod)}
          className="rounded-lg border border-slate-700 bg-slate-950/40 px-3 py-2.5 text-sm text-slate-200 outline-none focus:border-cyan-400/50"
          aria-label="Период статистики"
        >
          {periods.map((item) => (
            <option key={item.value} value={item.value}>
              {item.label}
            </option>
          ))}
        </select>
      </div>

      {isLoading && (
        <p className="rounded-xl border border-slate-800 bg-[#0c1422] px-5 py-8 text-center text-sm text-slate-500">
          Загрузка статистики…
        </p>
      )}
      {error && (
        <p className="rounded-xl border border-red-500/20 bg-red-500/[0.06] px-5 py-4 text-sm text-red-300">
          {error}
        </p>
      )}

      {summary && (
        <>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <MetricCard label="Всего нарушений" value={summary.total} />
            <MetricCard label="Новых нарушений" value={getStatusCount(summary, 'new')} tone="red" />
            <MetricCard label="Подтверждённых нарушений" value={getStatusCount(summary, 'confirmed')} tone="cyan" />
            <MetricCard label="Ложных срабатываний" value={getStatusCount(summary, 'false')} />
          </div>

          <IncidentCharts summary={summary} />
          <ActivityHeatmap heatmap={summary.heatmap} timeZone={STATISTICS_TIME_ZONE} />
        </>
      )}

    </div>
  )
}
