import { AlertTriangle, CheckCircle2, ShieldAlert, X, XCircle } from 'lucide-react'
import { useEffect, useState } from 'react'

import { getIncidentSnapshotUrl } from '../../config/api'
import type { Incident, IncidentStatus } from '../../types/api'
import {
  formatIncidentTime,
  incidentStatusLabels,
  severityLabels,
} from '../../utils/incidentPresentation'

interface IncidentModalProps {
  incident: Incident
  onClose: () => void
  onStatusChange: (status: IncidentStatus) => void | Promise<void>
  sourceLabel?: string
}

const actions = [
  { status: 'confirmed', label: 'Подтверждено', icon: CheckCircle2 },
  { status: 'false', label: 'Ложное срабатывание', icon: XCircle },
  { status: 'escalated', label: 'Передано мастеру', icon: ShieldAlert },
] as const

export function IncidentModal({
  incident,
  onClose,
  onStatusChange,
  sourceLabel = 'Инцидент',
}: IncidentModalProps) {
  const [isSaving, setIsSaving] = useState(false)
  const [actionError, setActionError] = useState('')
  const [snapshotUnavailable, setSnapshotUnavailable] = useState(false)

  useEffect(() => setSnapshotUnavailable(false), [incident.id])

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [onClose])

  const handleStatusChange = async (status: IncidentStatus) => {
    setIsSaving(true)
    setActionError('')
    try {
      await onStatusChange(status)
    } catch (error) {
      setActionError(error instanceof Error ? error.message : 'Не удалось сохранить статус')
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-slate-950/80 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="incident-title"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose()
      }}
    >
      <div className="max-h-[calc(100vh-2rem)] w-full max-w-xl overflow-y-auto rounded-2xl border border-slate-700 bg-[#0c1422] shadow-2xl shadow-black/50">
        <div
          className={`flex items-start justify-between gap-4 border-b px-6 py-5 ${
            incident.severity === 'critical'
              ? 'border-red-500/20 bg-red-500/[0.06]'
              : 'border-slate-800'
          }`}
        >
          <div>
            <div
              className={`flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.12em] ${
                incident.severity === 'critical' ? 'text-red-300' : 'text-amber-300'
              }`}
            >
              <AlertTriangle size={15} aria-hidden="true" />
              {severityLabels[incident.severity]}
            </div>
            <h2 id="incident-title" className="mt-2 text-xl font-semibold text-white">
              {incident.title}
            </h2>
            <p className="mt-1 text-xs text-slate-500">{sourceLabel}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="grid size-9 shrink-0 place-items-center rounded-lg border border-slate-700 text-slate-400 hover:text-white"
            aria-label="Закрыть"
          >
            <X size={17} />
          </button>
        </div>

        <div className="p-6">
          <div className="mb-6 overflow-hidden rounded-xl border border-slate-800 bg-slate-950">
            {!incident.snapshot_url || snapshotUnavailable ? (
              <div className="grid aspect-video place-items-center px-6 text-center text-xs text-slate-500">
                {incident.snapshot_url ? 'Снимок события недоступен' : 'Снимок для этого события не предоставлен'}
              </div>
            ) : (
              <img
                src={getIncidentSnapshotUrl(incident)}
                alt={`Снимок события: ${incident.title}`}
                className="aspect-video w-full object-contain"
                onError={() => setSnapshotUnavailable(true)}
              />
            )}
          </div>
          <dl className="grid gap-4 text-sm sm:grid-cols-2">
            <div>
              <dt className="text-xs text-slate-500">Камера</dt>
              <dd className="mt-1 font-medium text-slate-200">{incident.camera_name}</dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Время</dt>
              <dd className="mt-1 font-medium text-slate-200">
                {formatIncidentTime(incident.started_at)}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Тип нарушения</dt>
              <dd className="mt-1 font-mono text-xs text-cyan-300">{incident.violation_type}</dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Статус</dt>
              <dd className="mt-1 font-medium text-slate-200">
                {incidentStatusLabels[incident.status]}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Уверенность</dt>
              <dd className="mt-1 font-medium text-slate-200">
                {Math.round(incident.confidence * 100)}%
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">BBox, координаты 0..1</dt>
              <dd className="mt-1 font-mono text-xs text-slate-400">
                [{incident.bbox.join(', ')}]
              </dd>
            </div>
          </dl>

          <div className="mt-6 border-t border-slate-800 pt-5">
            <p className="mb-3 text-xs font-medium uppercase tracking-[0.12em] text-slate-500">
              Решение оператора
            </p>
            <div className="grid gap-2 sm:grid-cols-3">
              {actions.map(({ status, label, icon: Icon }) => (
                <button
                  key={status}
                  type="button"
                  onClick={() => void handleStatusChange(status)}
                  disabled={isSaving}
                  className={`flex min-h-16 items-center justify-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold transition-colors ${
                    incident.status === status
                      ? 'border-cyan-400/40 bg-cyan-400/10 text-cyan-300'
                      : 'border-slate-700 text-slate-400 hover:border-slate-600 hover:text-slate-200'
                  }`}
                  aria-pressed={incident.status === status}
                >
                  <Icon size={15} aria-hidden="true" />
                  {label}
                </button>
              ))}
            </div>
            {actionError && <p className="mt-3 text-xs text-red-400">{actionError}</p>}
          </div>
        </div>
      </div>
    </div>
  )
}
