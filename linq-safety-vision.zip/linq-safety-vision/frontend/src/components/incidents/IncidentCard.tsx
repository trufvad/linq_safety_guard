import { AlertTriangle, Clock3 } from 'lucide-react'

import type { Incident } from '../../types/api'
import {
  formatIncidentTime,
  incidentStatusLabels,
  severityLabels,
} from '../../utils/incidentPresentation'

interface IncidentCardProps {
  incident: Incident
  onClick: () => void
}

export function IncidentCard({ incident, onClick }: IncidentCardProps) {
  const isCritical = incident.severity === 'critical'

  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-full rounded-lg border p-3 text-left transition-colors ${
        isCritical
          ? 'border-red-500/35 bg-red-500/[0.08] hover:border-red-400/60'
          : 'border-slate-800 bg-slate-950/30 hover:border-slate-700'
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <AlertTriangle
              size={14}
              className={isCritical ? 'text-red-400' : 'text-amber-400'}
              aria-hidden="true"
            />
            <span
              className={`text-[10px] font-bold uppercase tracking-[0.1em] ${
                isCritical ? 'text-red-300' : 'text-amber-300'
              }`}
            >
              {severityLabels[incident.severity]}
            </span>
          </div>
          <p className="mt-2 text-sm font-semibold leading-5 text-slate-100">{incident.title}</p>
          <p className="mt-1 truncate text-xs text-slate-500">{incident.camera_name}</p>
        </div>
        {incident.status === 'new' && <span className="mt-1 size-2 shrink-0 rounded-full bg-cyan-400" />}
      </div>

      <div className="mt-3 flex items-center justify-between gap-2 border-t border-white/[0.06] pt-2.5 text-[11px]">
        <span className="flex items-center gap-1.5 text-slate-500">
          <Clock3 size={12} aria-hidden="true" />
          {formatIncidentTime(incident.started_at)}
        </span>
        <span className="font-medium text-slate-400">{incidentStatusLabels[incident.status]}</span>
      </div>
    </button>
  )
}
