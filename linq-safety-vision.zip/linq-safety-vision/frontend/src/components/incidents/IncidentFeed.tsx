import { BellRing, ListX, Volume2, VolumeX } from 'lucide-react'

import type { Incident } from '../../types/api'
import { IncidentCard } from './IncidentCard'

interface IncidentFeedProps {
  incidents: Incident[]
  activeCount: number
  soundEnabled: boolean
  onSelect: (incident_id: string) => void
  onToggleSound: () => void
  onClear?: () => void
}

export function IncidentFeed({
  incidents,
  activeCount,
  soundEnabled,
  onSelect,
  onToggleSound,
  onClear,
}: IncidentFeedProps) {
  return (
    <aside className="rounded-xl border border-slate-800 bg-[#0c1422] p-4 xl:sticky xl:top-28 xl:self-start">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
            Оперативные события
          </p>
          <div className="mt-1 flex items-center gap-2">
            <h2 className="text-base font-semibold text-slate-100">Лента тревог</h2>
            <span className="rounded-full bg-cyan-400/10 px-2 py-0.5 text-[10px] font-bold text-cyan-300">
              {activeCount}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2">
        {onClear && (
          <button
            type="button"
            onClick={onClear}
            disabled={!incidents.length}
            className="grid size-9 place-items-center rounded-lg border border-slate-700 text-slate-500 transition-colors hover:text-slate-300 disabled:cursor-not-allowed disabled:opacity-40"
            aria-label="Очистить ленту тревог"
            title="Очистить ленту (журнал сохранится)"
          >
            <ListX size={17} />
          </button>
        )}
        <button
          type="button"
          onClick={onToggleSound}
          className={`grid size-9 place-items-center rounded-lg border transition-colors ${
            soundEnabled
              ? 'border-cyan-400/30 bg-cyan-400/10 text-cyan-300'
              : 'border-slate-700 text-slate-500 hover:text-slate-300'
          }`}
          aria-label={soundEnabled ? 'Выключить звуковые уведомления' : 'Включить звуковые уведомления'}
          aria-pressed={soundEnabled}
          title={soundEnabled ? 'Звук включён' : 'Звук выключен'}
        >
          {soundEnabled ? <Volume2 size={17} /> : <VolumeX size={17} />}
        </button>
        </div>
      </div>

      {incidents.length ? (
        <div className="mt-4 max-h-[620px] space-y-2.5 overflow-y-auto pr-1" aria-live="polite">
          {incidents.map((incident) => (
            <IncidentCard
              key={incident.id}
              incident={incident}
              onClick={() => onSelect(incident.id)}
            />
          ))}
        </div>
      ) : (
        <div className="mt-4 grid min-h-52 place-items-center rounded-lg border border-dashed border-slate-700/80 bg-slate-950/30 px-5 text-center">
          <div>
            <BellRing className="mx-auto text-slate-700" size={22} aria-hidden="true" />
            <p className="mt-3 text-sm font-medium text-slate-400">Тревог пока нет</p>
            <p className="mt-2 text-xs leading-5 text-slate-600">
              Нарушения появятся здесь сразу, как только система их обнаружит.
            </p>
          </div>
        </div>
      )}
    </aside>
  )
}
