import { AlertTriangle, X } from 'lucide-react'

import type { Incident } from '../../types/api'

interface IncidentToastProps {
  incident: Incident
  sourceLabel?: string
  onClose: () => void
}

export function IncidentToast({ incident, sourceLabel = 'Новое нарушение', onClose }: IncidentToastProps) {
  const isCritical = incident.severity === 'critical'

  return (
    <div
      className={`fixed right-5 top-5 z-[60] w-[calc(100%-2.5rem)] max-w-sm rounded-xl border p-4 shadow-2xl sm:right-8 sm:top-8 ${
        isCritical
          ? 'border-red-500/40 bg-[#251017] shadow-red-950/30'
          : 'border-amber-400/30 bg-[#1d1a10] shadow-black/30'
      }`}
      role="status"
      aria-live="assertive"
    >
      <div className="flex items-start gap-3">
        <AlertTriangle
          className={isCritical ? 'text-red-400' : 'text-amber-400'}
          size={19}
          aria-hidden="true"
        />
        <div className="min-w-0 flex-1">
          <p className="text-xs font-bold uppercase tracking-[0.12em] text-slate-400">
            {sourceLabel}
          </p>
          <p className="mt-1 text-sm font-semibold text-white">{incident.title}</p>
          <p className="mt-1 truncate text-xs text-slate-400">{incident.camera_name}</p>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="text-slate-500 hover:text-white"
          aria-label="Закрыть уведомление"
        >
          <X size={16} />
        </button>
      </div>
    </div>
  )
}
