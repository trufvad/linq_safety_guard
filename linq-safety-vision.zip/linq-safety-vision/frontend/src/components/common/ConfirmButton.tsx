import { Trash2 } from 'lucide-react'
import { useEffect, useState } from 'react'

interface ConfirmButtonProps {
  label: string
  confirmLabel: string
  busyLabel?: string
  onConfirm: () => Promise<void> | void
  disabled?: boolean
}

/** Опасное действие в два нажатия: «Удалить» -> «Точно удалить?» (сбрасывается через 4 с). */
export function ConfirmButton({ label, confirmLabel, busyLabel = 'Удаление…', onConfirm, disabled }: ConfirmButtonProps) {
  const [armed, setArmed] = useState(false)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!armed) return
    const timer = window.setTimeout(() => setArmed(false), 4000)
    return () => window.clearTimeout(timer)
  }, [armed])

  const handleClick = async () => {
    if (!armed) {
      setArmed(true)
      return
    }
    setBusy(true)
    try {
      await onConfirm()
    } finally {
      setBusy(false)
      setArmed(false)
    }
  }

  return (
    <button
      type="button"
      onClick={() => void handleClick()}
      disabled={disabled || busy}
      className={`inline-flex items-center justify-center gap-2 rounded-lg border px-3.5 py-2.5 text-xs font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${
        armed
          ? 'border-red-500/60 bg-red-500/[0.06] text-red-300'
          : 'border-slate-700 text-slate-300 hover:border-red-400/50 hover:text-red-300'
      }`}
      style={armed ? { borderColor: '#ef4444', color: '#fca5a5' } : undefined}
    >
      <Trash2 size={15} aria-hidden="true" />
      {busy ? busyLabel : armed ? confirmLabel : label}
    </button>
  )
}
