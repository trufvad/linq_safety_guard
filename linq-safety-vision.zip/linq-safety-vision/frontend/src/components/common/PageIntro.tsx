import type { LucideIcon } from 'lucide-react'

interface PageIntroProps {
  eyebrow: string
  title: string
  description: string
  icon: LucideIcon
}

export function PageIntro({ eyebrow, title, description, icon: Icon }: PageIntroProps) {
  return (
    <section className="relative overflow-hidden rounded-2xl border border-slate-800 bg-[#0c1422] p-6 shadow-2xl shadow-black/10 sm:p-8 lg:p-10">
      <div className="absolute -right-16 -top-20 size-64 rounded-full bg-cyan-400/[0.04] blur-3xl" />
      <div className="relative max-w-2xl">
        <div className="mb-8 grid size-12 place-items-center rounded-xl border border-cyan-400/15 bg-cyan-400/10 text-cyan-300">
          <Icon size={23} strokeWidth={1.8} aria-hidden="true" />
        </div>
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-cyan-400">
          {eyebrow}
        </p>
        <h2 className="mt-3 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
          {title}
        </h2>
        <p className="mt-4 max-w-xl text-sm leading-7 text-slate-400 sm:text-base">
          {description}
        </p>
      </div>
    </section>
  )
}
