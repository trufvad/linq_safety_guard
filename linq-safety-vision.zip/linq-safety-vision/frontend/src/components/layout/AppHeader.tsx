import { useLocation } from 'react-router-dom'

import { navigationItems } from '../../config/navigation'
import { Brand } from './Brand'
import { ConnectionStatus } from './ConnectionStatus'

export function AppHeader() {
  const { pathname } = useLocation()
  const currentPage = navigationItems.find((item) => item.path === pathname)

  return (
    <header className="sticky top-0 z-10 border-b border-slate-800/80 bg-[#080d17]/85 px-5 py-4 backdrop-blur-xl sm:px-8 lg:px-10">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
        <div className="lg:hidden">
          <Brand />
        </div>
        <div className="hidden lg:block">
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
            Рабочая область
          </p>
          <h1 className="mt-1 text-xl font-semibold tracking-tight text-slate-100">
            {currentPage?.label ?? 'LinQ Safety Vision'}
          </h1>
        </div>
        <ConnectionStatus />
      </div>
    </header>
  )
}
