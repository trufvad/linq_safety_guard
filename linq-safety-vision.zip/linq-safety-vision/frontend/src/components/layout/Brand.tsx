import { ScanEye } from 'lucide-react'

export function Brand() {
  return (
    <div className="flex items-center gap-3">
      <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-cyan-400 text-slate-950 shadow-[0_0_24px_rgba(34,211,238,0.18)]">
        <ScanEye size={22} strokeWidth={2.2} aria-hidden="true" />
      </div>
      <div className="min-w-0">
        <p className="truncate text-[15px] font-semibold tracking-tight text-white">
          LinQ Safety Vision
        </p>
        <p className="mt-0.5 truncate text-[10px] font-medium uppercase tracking-[0.12em] text-slate-500">
          ООО &quot;МЕГАЛЮЛЬ&quot;
        </p>
      </div>
    </div>
  )
}
