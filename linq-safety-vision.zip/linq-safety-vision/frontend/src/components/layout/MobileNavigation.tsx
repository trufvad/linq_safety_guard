import { NavLink } from 'react-router-dom'

import { navigationItems } from '../../config/navigation'

export function MobileNavigation() {
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-3 border-t border-slate-800 bg-[#0a101c]/95 px-2 py-2 backdrop-blur lg:hidden"
      aria-label="Основная навигация"
    >
      {navigationItems.map(({ label, path, icon: Icon }) => (
        <NavLink
          key={path}
          to={path}
          className={({ isActive }) =>
            `flex min-w-0 flex-col items-center gap-1 rounded-lg px-1 py-2 text-[10px] font-medium transition-colors sm:text-xs ${
              isActive ? 'bg-cyan-400/10 text-cyan-300' : 'text-slate-500'
            }`
          }
        >
          <Icon size={18} strokeWidth={1.8} aria-hidden="true" />
          <span className="truncate">{label}</span>
        </NavLink>
      ))}
    </nav>
  )
}
