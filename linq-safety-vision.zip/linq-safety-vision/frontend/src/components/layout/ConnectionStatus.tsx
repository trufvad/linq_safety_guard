import { Wifi, WifiOff } from 'lucide-react'

import { useBackend } from '../../context/BackendContext'

const ENGINE_LABELS: Record<string, string> = {
  linq_tpu: 'LinQ TPU',
  linq_tpu_remote: 'LinQ TPU (удалённо)',
  linq_tpu_sim: 'эмуляция LinQ TPU',
  onnxruntime: 'CPU · ONNX',
}

export function ConnectionStatus() {
  const { connectionState, health, webSocketState } = useBackend()
  const state = connectionState
  const labels = {
    connected: 'Подключено',
    connecting: 'Подключение',
    error: 'Ошибка',
    disconnected: 'Отключено',
  }
  const colors = {
    connected: 'bg-emerald-400',
    connecting: 'bg-amber-400',
    error: 'bg-red-400',
    disconnected: 'bg-slate-500',
  }
  const modelWarnings = state === 'connected' ? health?.warnings ?? [] : []
  const details =
    state === 'connected' && health
      ? `${ENGINE_LABELS[health.engine] ?? health.engine} · ${health.cameras} кам.${
          webSocketState === 'connected' ? '' : ' · WebSocket отключён'
        }${modelWarnings.length ? ' · проблема модели' : ''}`
      : webSocketState === 'disconnected'
          ? 'WebSocket отключён'
          : ''

  return (
    <div
      className="flex items-center gap-2 rounded-full border border-slate-700/80 bg-slate-900/70 px-3 py-2"
      style={modelWarnings.length ? { borderColor: '#ef4444', background: 'rgba(69, 10, 10, 0.7)' } : undefined}
      title={modelWarnings.join('\n') || undefined}
      aria-label={`Статус подключения: ${labels[state]}${details ? `, ${details}` : ''}`}
    >
      <span className="relative flex size-2">
        <span className={`relative inline-flex size-2 rounded-full ${colors[state]}`} />
      </span>
      {state === 'connected' ? (
        <Wifi size={14} className="text-slate-400" aria-hidden="true" />
      ) : (
        <WifiOff size={14} className="text-slate-500" aria-hidden="true" />
      )}
      <span className="hidden sm:block">
        <span className="block text-xs font-medium text-slate-300">{labels[state]}</span>
        {details && <span className="block text-[10px] text-slate-500">{details}</span>}
      </span>
    </div>
  )
}
