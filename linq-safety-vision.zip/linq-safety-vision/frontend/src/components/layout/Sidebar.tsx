import { NavLink } from 'react-router-dom'

import { navigationItems } from '../../config/navigation'
import { Brand } from './Brand'

const linkClasses = ({ isActive }: { isActive: boolean }) =>
  [
    'group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors',
    isActive
      ? 'bg-cyan-400/10 text-cyan-300 ring-1 ring-inset ring-cyan-400/15'
      : 'text-slate-400 hover:bg-white/[0.04] hover:text-slate-100',
  ].join(' ')

export function Sidebar() {
  return (
    <aside className="fixed inset-y-0 left-0 z-20 hidden w-64 flex-col border-r border-slate-800/80 bg-[#0a101c] px-4 py-5 lg:flex">
      <div className="px-2">
        <Brand />
      </div>

      <nav className="mt-10 space-y-1" aria-label="Основная навигация">
        {navigationItems.map(({ label, path, icon: Icon }) => (
          <NavLink key={path} to={path} className={linkClasses}>
            <Icon size={18} strokeWidth={1.8} aria-hidden="true" />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}
