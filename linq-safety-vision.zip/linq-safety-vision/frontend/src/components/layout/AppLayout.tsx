import { Outlet } from 'react-router-dom'

import { useBackend } from '../../context/BackendContext'
import { IncidentToast } from '../incidents/IncidentToast'
import { AppHeader } from './AppHeader'
import { MobileNavigation } from './MobileNavigation'
import { Sidebar } from './Sidebar'

export function AppLayout() {
  const { notification, dismissNotification } = useBackend()

  return (
    <div className="min-h-screen bg-[#080d17] text-slate-100">
      <Sidebar />
      <div className="min-h-screen lg:pl-64">
        <AppHeader />
        <main className="px-5 py-8 pb-28 sm:px-8 lg:px-10 lg:pb-10">
          <div className="mx-auto max-w-7xl">
            <Outlet />
          </div>
        </main>
      </div>
      <MobileNavigation />
      {notification && (
        <IncidentToast
          incident={notification}
          sourceLabel="Новое нарушение"
          onClose={dismissNotification}
        />
      )}
    </div>
  )
}
