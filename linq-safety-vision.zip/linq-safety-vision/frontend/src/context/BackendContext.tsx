import {
  createContext,
  type ReactNode,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react'

import { api, type HealthResponse, type RuleDefinition } from '../api/api'
import { getEventsWebSocketUrl } from '../config/api'
import type { Camera, CameraStats, Incident, WebSocketMessage } from '../types/api'
import { playNotificationSound } from '../utils/notificationSound'
import { useIncidents } from './IncidentContext'

export type ConnectionState = 'connected' | 'connecting' | 'error' | 'disconnected'

interface BackendContextValue {
  connectionState: ConnectionState
  connectionError: string
  webSocketState: ConnectionState
  health: HealthResponse | null
  cameras: Camera[]
  camerasLoading: boolean
  camerasError: string
  rules: RuleDefinition[]
  notification: Incident | null
  soundEnabled: boolean
  refreshCameras: () => Promise<void>
  startCamera: (camera_id: string) => Promise<void>
  stopCamera: (camera_id: string) => Promise<void>
  notifyIncident: (incident: Incident) => void
  dismissNotification: () => void
  toggleSound: () => void
}

const SOUND_STORAGE_KEY = 'linq.soundEnabled'
const RECONNECT_DELAY_MS = 5000
const BackendContext = createContext<BackendContextValue | null>(null)

function applyCameraStats(cameras: Camera[], stats: CameraStats[]) {
  const statsById = new Map(stats.map((item) => [item.id, item]))
  return cameras.map((camera) => {
    const update = statsById.get(camera.id)
    if (!update) return camera
    const { id: _id, status, error, ...performance } = update
    return { ...camera, status, error, stats: performance }
  })
}

export function BackendProvider({ children }: { children: ReactNode }) {
  const { refreshIncidents, updateIncident, upsertIncident } = useIncidents()
  const [connectionState, setConnectionState] = useState<ConnectionState>('connecting')
  const [connectionError, setConnectionError] = useState('')
  const [webSocketState, setWebSocketState] = useState<ConnectionState>('disconnected')
  const [health, setHealth] = useState<HealthResponse | null>(null)
  const [cameras, setCameras] = useState<Camera[]>([])
  const [camerasLoading, setCamerasLoading] = useState(false)
  const [camerasError, setCamerasError] = useState('')
  const [rules, setRules] = useState<RuleDefinition[]>([])
  const [notification, setNotification] = useState<Incident | null>(null)
  const [soundEnabled, setSoundEnabled] = useState(
    () => localStorage.getItem(SOUND_STORAGE_KEY) === 'true',
  )
  const canPlaySound = useRef(false)
  const soundEnabledRef = useRef(soundEnabled)
  const mountedRef = useRef(true)
  const notificationTimer = useRef<number | null>(null)

  useEffect(() => {
    mountedRef.current = true
    return () => {
      mountedRef.current = false
      if (notificationTimer.current) window.clearTimeout(notificationTimer.current)
    }
  }, [])

  useEffect(() => {
    const allowSound = () => {
      canPlaySound.current = true
      window.removeEventListener('pointerdown', allowSound)
      window.removeEventListener('keydown', allowSound)
    }
    window.addEventListener('pointerdown', allowSound)
    window.addEventListener('keydown', allowSound)
    return () => {
      window.removeEventListener('pointerdown', allowSound)
      window.removeEventListener('keydown', allowSound)
    }
  }, [])

  useEffect(() => {
    soundEnabledRef.current = soundEnabled
    localStorage.setItem(SOUND_STORAGE_KEY, String(soundEnabled))
  }, [soundEnabled])

  const notifyIncident = useCallback((incident: Incident) => {
    setNotification(incident)
    if (notificationTimer.current) window.clearTimeout(notificationTimer.current)
    notificationTimer.current = window.setTimeout(() => setNotification(null), 4500)
    if (soundEnabledRef.current && canPlaySound.current) playNotificationSound()
  }, [])

  const dismissNotification = useCallback(() => setNotification(null), [])

  const toggleSound = useCallback(() => {
    canPlaySound.current = true
    setSoundEnabled((currentValue) => {
      const nextValue = !currentValue
      if (nextValue) playNotificationSound()
      return nextValue
    })
  }, [])

  const refreshHealth = useCallback(async () => {
    setConnectionState((current) => (current === 'connected' ? current : 'connecting'))
    try {
      const response = await api.getHealth()
      if (!mountedRef.current) return
      setHealth(response)
      setConnectionState('connected')
      setConnectionError('')
    } catch (error) {
      if (!mountedRef.current) return
      setHealth(null)
      setConnectionState('error')
      setConnectionError(error instanceof Error ? error.message : 'Backend недоступен')
    }
  }, [])

  const refreshCameras = useCallback(async () => {
    setCamerasLoading(true)
    setCamerasError('')
    try {
      const response = await api.getCameras()
      if (!mountedRef.current) return
      setCameras(response)
    } catch (error) {
      if (mountedRef.current) {
        setCamerasError(error instanceof Error ? error.message : 'Не удалось загрузить камеры')
      }
      throw error
    } finally {
      if (mountedRef.current) setCamerasLoading(false)
    }
  }, [])

  useEffect(() => {
    void refreshHealth()
    void refreshCameras().catch(() => undefined)
    void refreshIncidents().catch(() => undefined)
    let active = true
    void api.getRules().then((response) => {
      if (active) setRules(response)
    }).catch(() => {
      if (active) setRules([])
    })
    void api.getCameraStats().then((response) => {
      if (active) setCameras((current) => applyCameraStats(current, response.cameras))
    }).catch(() => undefined)

    const intervalId = window.setInterval(() => void refreshHealth(), 15000)
    return () => {
      active = false
      window.clearInterval(intervalId)
    }
  }, [refreshCameras, refreshHealth, refreshIncidents])

  useEffect(() => {
    let active = true
    let socket: WebSocket | null = null
    let reconnectTimer: number | null = null

    const connect = () => {
      if (!active) return
      setWebSocketState('connecting')
      socket = new WebSocket(getEventsWebSocketUrl())

      socket.onopen = () => {
        if (!active) return
        setWebSocketState('connected')
        void refreshIncidents().catch(() => undefined)
        void refreshCameras().catch(() => undefined)
      }

      socket.onmessage = (event) => {
        if (!active) return
        try {
          const message = JSON.parse(String(event.data)) as WebSocketMessage
          if (message.type === 'event.created') {
            upsertIncident(message.data)
            notifyIncident(message.data)
          } else if (message.type === 'event.updated') {
            updateIncident(message.data)
          } else if (message.type === 'events.cleared') {
            void refreshIncidents().catch(() => undefined)
          } else if (message.type === 'camera.stats') {
            setCameras((current) => applyCameraStats(current, message.data))
          } else if (message.type === 'hello') {
            setHealth((current) =>
              current
                ? { ...current, engine: message.data.engine, cameras: message.data.cameras.length }
                : current,
            )
            setCameras((current) => applyCameraStats(current, message.data.cameras))
          }
        } catch {
          // Некорректное сообщение не должно останавливать остальные обновления WebSocket.
        }
      }

      socket.onerror = () => {
        if (active) setWebSocketState('error')
      }

      socket.onclose = () => {
        if (!active) return
        setWebSocketState('disconnected')
        reconnectTimer = window.setTimeout(connect, RECONNECT_DELAY_MS)
      }
    }

    connect()
    return () => {
      active = false
      if (reconnectTimer) window.clearTimeout(reconnectTimer)
      socket?.close(1000, 'Frontend unmounted')
    }
  }, [notifyIncident, refreshCameras, refreshIncidents, updateIncident, upsertIncident])

  const setCameraStatus = useCallback((camera_id: string, status: Camera['status']) => {
    setCameras((current) =>
      current.map((camera) => (camera.id === camera_id ? { ...camera, status } : camera)),
    )
  }, [])

  const startCamera = useCallback(async (camera_id: string) => {
    const response = await api.startCamera(camera_id)
    setCameraStatus(camera_id, response.status)
  }, [setCameraStatus])

  const stopCamera = useCallback(async (camera_id: string) => {
    const response = await api.stopCamera(camera_id)
    setCameraStatus(camera_id, response.status)
  }, [setCameraStatus])

  return (
    <BackendContext.Provider
      value={{
        connectionState,
        connectionError,
        webSocketState,
        health,
        cameras,
        camerasLoading,
        camerasError,
        rules,
        notification,
        soundEnabled,
        refreshCameras,
        startCamera,
        stopCamera,
        notifyIncident,
        dismissNotification,
        toggleSound,
      }}
    >
      {children}
    </BackendContext.Provider>
  )
}

export function useBackend() {
  const context = useContext(BackendContext)
  if (!context) throw new Error('useBackend must be used inside BackendProvider')
  return context
}
