import {
  createContext,
  type ReactNode,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react'

import { api } from '../api/api'
import type { Incident, IncidentStatus } from '../types/api'

interface IncidentContextValue {
  incidents: Incident[]
  incidentsLoading: boolean
  incidentsError: string
  replaceIncidents: (incidents: Incident[]) => void
  upsertIncident: (incident: Incident) => void
  updateIncident: (incident: Incident) => void
  updateIncidentStatus: (incident_id: string, status: IncidentStatus) => Promise<void>
  refreshIncidents: () => Promise<void>
}

const IncidentContext = createContext<IncidentContextValue | null>(null)

function sortIncidents(incidents: Incident[]) {
  return [...incidents].sort(
    (first, second) =>
      new Date(second.started_at).getTime() - new Date(first.started_at).getTime(),
  )
}

export function IncidentProvider({ children }: { children: ReactNode }) {
  const [incidents, setIncidents] = useState<Incident[]>([])
  const [incidentsLoading, setIncidentsLoading] = useState(false)
  const [incidentsError, setIncidentsError] = useState('')
  const mountedRef = useRef(true)
  const mutationVersion = useRef(0)
  const recentMutations = useRef(new Map<string, { version: number; incident: Incident }>())
  const refreshRequestId = useRef(0)

  useEffect(() => {
    mountedRef.current = true
    return () => {
      mountedRef.current = false
    }
  }, [])

  const replaceIncidents = useCallback((nextIncidents: Incident[]) => {
    const uniqueIncidents = Array.from(
      new Map(nextIncidents.map((incident) => [incident.id, incident])).values(),
    )
    setIncidents(sortIncidents(uniqueIncidents))
  }, [])

  const upsertIncident = useCallback((incident: Incident) => {
    mutationVersion.current += 1
    recentMutations.current.set(incident.id, { version: mutationVersion.current, incident })
    setIncidents((currentIncidents) =>
      sortIncidents([
        incident,
        ...currentIncidents.filter((item) => item.id !== incident.id),
      ]),
    )
  }, [])

  const updateIncident = useCallback((incident: Incident) => {
    mutationVersion.current += 1
    recentMutations.current.set(incident.id, { version: mutationVersion.current, incident })
    setIncidents((currentIncidents) => {
      const exists = currentIncidents.some((item) => item.id === incident.id)
      return sortIncidents(exists
        ? currentIncidents.map((item) => (item.id === incident.id ? incident : item))
        : [incident, ...currentIncidents])
    })
  }, [])

  const updateIncidentStatus = useCallback(async (incident_id: string, status: IncidentStatus) => {
    const updatedIncident = await api.updateIncident(incident_id, { status })
    updateIncident(updatedIncident)
  }, [updateIncident])

  const refreshIncidents = useCallback(async () => {
    setIncidentsLoading(true)
    setIncidentsError('')
    const startingMutationVersion = mutationVersion.current
    const requestId = ++refreshRequestId.current
    try {
      const allIncidents: Incident[] = []
      const limit = 1000
      let offset = 0
      let total = 0

      do {
        const response = await api.getIncidents({ limit, offset })
        total = response.total
        allIncidents.push(...response.items)
        offset += response.items.length
        if (response.items.length === 0) break
      } while (offset < total)

      if (!mountedRef.current || requestId !== refreshRequestId.current) return
      const merged = new Map(allIncidents.map((incident) => [incident.id, incident]))
      recentMutations.current.forEach(({ version, incident }, incidentId) => {
        if (version > startingMutationVersion) merged.set(incidentId, incident)
      })
      replaceIncidents(Array.from(merged.values()))
      const appliedMutationVersion = mutationVersion.current
      recentMutations.current.forEach(({ version }, incidentId) => {
        if (version <= appliedMutationVersion) recentMutations.current.delete(incidentId)
      })
    } catch (error) {
      if (mountedRef.current && requestId === refreshRequestId.current) {
        setIncidentsError(error instanceof Error ? error.message : 'Не удалось загрузить события')
      }
      throw error
    } finally {
      if (mountedRef.current && requestId === refreshRequestId.current) {
        setIncidentsLoading(false)
      }
    }
  }, [replaceIncidents])

  return (
    <IncidentContext.Provider
      value={{
        incidents,
        incidentsLoading,
        incidentsError,
        replaceIncidents,
        upsertIncident,
        updateIncident,
        updateIncidentStatus,
        refreshIncidents,
      }}
    >
      {children}
    </IncidentContext.Provider>
  )
}

export function useIncidents() {
  const context = useContext(IncidentContext)
  if (!context) {
    throw new Error('useIncidents must be used inside IncidentProvider')
  }
  return context
}
