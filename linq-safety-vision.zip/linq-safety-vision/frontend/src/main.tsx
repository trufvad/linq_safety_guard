import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'

import App from './App'
import { BASE_PATH } from './config/api'
import { BackendProvider } from './context/BackendContext'
import { IncidentProvider } from './context/IncidentContext'
import './index.css'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <IncidentProvider>
      <BackendProvider>
        <BrowserRouter basename={BASE_PATH || undefined}>
          <App />
        </BrowserRouter>
      </BackendProvider>
    </IncidentProvider>
  </StrictMode>,
)
