# JSON-контракт бэкенда (для Участника 3 — фронтенд)

База: `http://<host>:8000` — тот же адрес, что у интерфейса (backend раздаёт `frontend/dist`; в `npm run dev` Vite проксирует `/api` и `/ws`). Swagger со всеми схемами: `/docs`.
Все времена — ISO 8601 с часовым поясом (`2026-10-24T10:15:03+03:00`).
**Все координаты (полигоны, bbox) — в долях кадра 0..1**, не в пикселях: фронт умножает на размер `<img>`/Canvas.


## 1. Событие нарушения

```json
{
  "id": "a1b2c3d4e5f6",
  "camera_id": "cam1",
  "camera_name": "Склад, ворота 2",
  "area": "Цех 1",
  "zone_id": "z1",
  "zone_name": "Зона погрузчика",
  "violation_type": "danger_zone",
  "title": "Нахождение в опасной зоне",
  "severity": "critical",
  "track_id": 17,
  "confidence": 0.87,
  "bbox": [0.41, 0.52, 0.47, 0.81],
  "started_at": "2026-10-24T10:15:03+03:00",
  "ended_at": null,
  "status": "new",
  "comment": null,
  "snapshot_url": "/api/events/a1b2c3d4e5f6/snapshot.jpg",
  "details": {"point": [530.0, 560.0]}
}
```

| Поле | Значения |
|---|---|
| `violation_type` | `danger_zone`, `machine_proximity`, `fall`, `running`, `no_ppe` (каталог — `GET /api/rules`) |
| `severity` | `critical` (красный + звук: падение, зона, сближение), `warning`, `info` |
| `status` | `new` → `confirmed` / `false` / `escalated`; `ended_at` ставится, когда нарушитель ушёл |
| `snapshot_url` | стоп-кадр с выделенным нарушителем; `?raw=true` — чистый кадр |
| `details` | зависит от типа: `lying_seconds`, `speed_heights_per_s`, `gap_heights`, `missing` |

Одно нарушение = одно событие: пока тот же человек (`track_id`) в той же ситуации, повторов нет.

## 2. Конфиг камеры и полигона

```json
{
  "id": "cam1",
  "name": "Склад, ворота 2",
  "source": "rtsp://10.0.0.5/stream1",
  "area": "Цех 1",
  "enabled": true,
  "zones": [
    {
      "id": "z1",
      "name": "Зона работы погрузчика",
      "kind": "danger",
      "polygon": [[0.35, 0.50], [0.50, 0.50], [0.50, 0.90], [0.35, 0.90]],
      "schedule": {"start": "08:00", "end": "12:00", "weekdays": [0, 1, 2, 3, 4]},
      "enabled": true
    }
  ],
  "rules": {
    "danger_zone": {"enabled": true},
    "running": {"enabled": false},
    "fall": {"enabled": true, "params": {"immobile_s": 3}, "schedule": null}
  }
}
```

* `source`: путь к видео, `rtsp://…`, папка со стоп-кадрами, `"0"` (веб-камера).
* `kind`: `danger`/`restricted` — правило «опасная зона»; `machine` — зона работы техники (правило сближения).
* `schedule` (у зоны и у правила): `null` = всегда; окно через полночь (`22:00`–`06:00`) поддерживается; `weekdays` 0 = Пн.
* Правило, которого нет в `rules`, включено с параметрами по умолчанию. Чекбокс = `enabled`.

## 3. REST

| Метод | Путь | Назначение |
|---|---|---|
| GET | `/api/health` | `status` (`ok` / `degraded`), движок (`onnxruntime` / `linq_tpu` / `linq_tpu_sim` / `linq_tpu_remote`), `version`, аптайм, `warnings` — проблемы модели (пусто = ок), `model` — паспорт .tpu |
| GET | `/api/rules` | каталог правил: `type, title, severity, default_params, available` |
| GET / POST | `/api/cameras` | список (с `status` и `stats`) / создать камеру |
| GET / PATCH / DELETE | `/api/cameras/{id}` | PATCH: `name, source, area, enabled` |
| PUT | `/api/cameras/{id}/zones` | массив зон из Canvas-редактора, применяется на лету |
| PUT | `/api/cameras/{id}/rules` | `{type: {enabled, params, schedule}}` |
| POST | `/api/cameras/{id}/start` · `/stop` | управление потоком |
| GET | `/api/cameras/{id}/frame.jpg` | стоп-кадр для рисования полигонов (`?annotated=true` — с разметкой) |
| GET | `/api/cameras/{id}/stream.mjpg` | живое видео с разметкой: просто `<img src=…>` |
| GET | `/api/events` | журнал: `camera_id, violation_type, status, area, zone_id, date_from, date_to, limit, offset`; несколько значений через запятую. Ответ `{total, items}` |
| DELETE | `/api/events` | очистить журнал (и статистику); `?camera_id=` — только одной камеры. Ответ `{deleted}`, в WebSocket приходит `events.cleared` |
| GET / PATCH | `/api/events/{id}` | PATCH `{"status": "confirmed" \| "false" \| "escalated", "comment": "…", "operator": "…"}` |
| GET | `/api/events/{id}/snapshot.jpg` | стоп-кадр инцидента |
| GET | `/api/stats/summary` | `by_type, by_camera, by_area, by_status, by_day, by_shift, heatmap[7][24]` (Пн..Вс × часы) |
| GET | `/api/stats/performance` | FPS и задержка по камерам |
| GET | `/api/reports?period=shift\|day\|week\|month` | авто-отчёт по ТБ: `markdown` + цифры |
| POST | `/api/videos` | multipart: `file` (mp4/avi/mkv/mov/m4v/webm), `mode` = `new` (+ `name`, `area`) или `replace` (+ `camera_id`). Ответ `201 {video: {id, name, width, height, fps, duration_s, ...}, camera_id}`; ошибки: 415 формат, 422 нечитаемое видео, 413 размер, 404 нет камеры |
| GET | `/api/videos` | загруженные файлы: `[{id, name, size_mb, uploaded_at, cameras: [...]}]` |
| DELETE | `/api/videos/{id}` | 204; 409, если файл — источник камеры |
| POST | `/api/notify/test` | тестовое сообщение в Telegram; 400 — не настроен, 502 — Telegram ответил ошибкой |

«Ложное» (`status=false`) кладёт кадр и разметку в `data/false_positives/` — датасет для дообучения.

## 4. WebSocket `ws://<host>:8000/ws/events`

```json
{"type": "hello",          "data": {"engine": "linq_tpu", "cameras": [ ... ]}}
{"type": "event.created",  "data": { ...событие... }}
{"type": "event.updated",  "data": { ...событие... }}
{"type": "events.cleared", "data": {"camera_id": null, "count": 42}}
{"type": "camera.stats",   "data": [{"id": "cam1", "status": "running", "fps": 5.0, "latency_ms": 23.4,
                                     "preprocess_ms": 3.1, "inference_ms": 15.2, "postprocess_ms": 5.1,
                                     "pipeline_ms": 26.0, "tracks": 3, "frames": 1200,
                                     "suppressed_duplicates": 431, "engine": "linq_tpu"}]}
```

`camera.stats` приходит раз в секунду — это FPS и задержка инференса на узле LinQ для плиток видеосетки.
`event.updated` — смена статуса оператором или закрытие инцидента (`ended_at`).
