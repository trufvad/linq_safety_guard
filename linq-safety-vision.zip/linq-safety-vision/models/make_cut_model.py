"""Для Участника 1: обрезать YOLOv5s до трёх свёрток головы перед компиляцией в .tpu.

Почему: текущий yolov5s_b1_o1_h1m.tpu включает хвост Detect, его выход
output0 (1, 25200, 85) квантуется в int8 с диапазоном ±25, а координаты рамок
доходят до 640 — все рамки обрезаются. Документация (глава 6, сноска 5) для
yolo5s режет граф до трёх свёрток головы; хвост (sigmoid, сетка, якоря, NMS)
уже реализован в бэкенде: backend/app/inference/postprocess.py.

Запуск на сервере LinQ (где установлен tpu_framework):

    python make_cut_model.py --onnx yolov5s.onnx --out yolov5s_cut.onnx \
        --calib-dir /путь/к/кадрам_цеха --calib-out calib.npy

Дальше — тот же пайплайн калибровки/квантования/компиляции, что вы уже
использовали, но на yolov5s_cut.onnx и с calib.npy. Ожидаемые выходы .tpu:
три тензора (1, 255, 80, 80), (1, 255, 40, 40), (1, 255, 20, 20)
(или те же в NHWC — бэкенд понимает обе раскладки и любой порядок).
"""
from __future__ import annotations

import argparse
import glob
import os
import sys

import numpy as np

# Имена выходов свёрток головы.
# ONNX от `export.py` Ultralytics v7 (вход images, выход output0):
V7_HEADS = ["/model.24/m.0/Conv_output_0", "/model.24/m.1/Conv_output_0", "/model.24/m.2/Conv_output_0"]
# Тот же слой в ONNX из документации LinQ (глава 6, сноска 5):
DOC_HEADS = ["onnx::Shape_327", "onnx::Shape_663", "onnx::Shape_999"]


def find_heads(model) -> list[str]:
    names = {o for n in model.graph.node for o in n.output}
    for cand in (V7_HEADS, DOC_HEADS):
        if all(c in names for c in cand):
            return cand
    convs = [n.output[0] for n in model.graph.node if n.op_type == "Conv"]
    sys.exit(f"Не нашёл выходы головы. Последние Conv в графе: {convs[-3:]} — передайте их через --heads")


def calibration_set(folder: str, limit: int) -> np.ndarray:
    """Кадры -> тензоры РОВНО тем же препроцессингом, что в бэкенде (letterbox 640, RGB, /255)."""
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))
    import cv2
    from app.inference.preprocess import preprocess

    paths = sorted(p for e in ("jpg", "jpeg", "png", "bmp") for p in glob.glob(os.path.join(folder, f"*.{e}")))[:limit]
    if not paths:
        sys.exit(f"нет картинок в {folder}")
    return np.concatenate([preprocess(cv2.imread(p))[0] for p in paths], 0)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--onnx", default="yolov5s.onnx")
    ap.add_argument("--out", default="yolov5s_cut.onnx")
    ap.add_argument("--heads", nargs=3, help="имена трёх выходов вручную")
    ap.add_argument("--calib-dir", help="папка с кадрами цеха для калибровки")
    ap.add_argument("--calib-out", default="calib.npy")
    ap.add_argument("--calib-limit", type=int, default=200)
    a = ap.parse_args()

    import onnx
    from tpu_framework import get_sub_model

    model = onnx.load(a.onnx)
    heads = a.heads or find_heads(model)
    inp = [i.name for i in model.graph.input][0]
    print("вход:", inp, "| режем до:", heads)
    cut = get_sub_model(model=model, ordered_input_names=[inp], ordered_output_names=heads)
    onnx.save(cut, a.out)
    print("сохранено:", a.out)

    try:
        import onnxruntime as ort

        s = ort.InferenceSession(a.out, providers=["CPUExecutionProvider"])
        x = np.random.rand(1, 3, 640, 640).astype(np.float16 if "float16" in s.get_inputs()[0].type else np.float32)
        for o, v in zip(s.get_outputs(), s.run(None, {s.get_inputs()[0].name: x})):
            print(f"  {o.name}: {v.shape}  (ожидается (1, 255, 80|40|20, ...))")
    except Exception as e:  # noqa: BLE001
        print("проверка onnxruntime пропущена:", e)

    if a.calib_dir:
        data = calibration_set(a.calib_dir, a.calib_limit)
        np.save(a.calib_out, data)
        print(f"калибровка: {data.shape} -> {a.calib_out}  (calibration_data={{'{inp}': data}})")
