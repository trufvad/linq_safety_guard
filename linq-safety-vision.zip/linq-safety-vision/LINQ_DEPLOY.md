# Запуск на ускорителе LinQ (сервер хакатона)

## Как устроен ускоритель на хакатоне

В Jupyter на `hackathon.lin-q.ru` **нет** ни `/dev/tpu`, ни модуля `pytpu`: ускорители стоят в облаке хакатона. Ими пользуются так же, как в примере организаторов `example.ipynb`:

1. Программа `.tpu` кладётся в общую папку `/auto/cache/<ЛОГИН>/`.
2. Кадр отправляется в брокер RabbitMQ `10.0.114.30:5672` (обменник `tpu.direct`, очередь `input`). Формат сообщения задаёт пакет `tpu_pycloud_format`.
3. Воркер облака запускает программу на LinQ TPU и присылает выходы обратно.

В программе это движок **`ENGINE=cloud`**. Модель `models/yolov5s_cut_b1_o1_h1m.tpu` он сам копирует в `/auto/cache/<ЛОГИН>/`, а соединение держит открытым (у каждой камеры своё). В правом верхнем углу интерфейса пишется **«LinQ TPU (облако)»**: это подтверждение для жюри, что инференс идёт на ускорителе.

Брокер доступен только изнутри сервера хакатона, поэтому программа запускается **в терминале Jupyter**, а интерфейс открывается в браузере ноутбука через прокси Jupyter.

---

## 1. Подготовка (один раз)

1. Подключите **OpenVPN** с конфигом хакатона и войдите в Jupyter на `hackathon.lin-q.ru`.
2. **File → New → Terminal**. Проверьте, что всё нужное есть:
   ```bash
   python3 -c "import pika, tpu_pycloud_format, cv2, numpy; print('ok', numpy.__version__)"
   ls /auto/cache/$USER
   ```
   - нет `tpu_pycloud_format`: `pip install --no-deps ~/work/packages/tpu_pycloud_format-*.whl`
   - нет `pika`: `pip install pika`
   - ошибка при `import cv2` (OpenCV 5 несовместим с numpy 1.x): `pip install "numpy>=2"`

## 2. Загрузить программу

В Jupyter слева кнопка **Upload** → `linq-safety-vision.zip`, затем:
```bash
cd ~/work
unzip -o linq-safety-vision.zip
cd linq-safety-vision
chmod +x start.sh
```

## 3. Запустить

**Способ 1: скрипт.** Сам выберет облако, поставит недостающее в `.venv`, скопирует модель и напечатает ссылку:
```bash
nohup ./start.sh linq > linq.log 2>&1 &
tail -f linq.log
```

**Способ 2: вручную** (если скрипт не подошёл; пакеты из шага 1 уже стоят):
```bash
cd ~/work/linq-safety-vision/backend
ENGINE=cloud nohup python3 -m uvicorn app.main:app --host 0.0.0.0 --port 8000 > ../server.log 2>&1 &
tail -f ../server.log
```

В логе должны быть строки:
```
LinQ cloud: ответ за … мс, выходы […]
engine: linq_tpu_cloud
```
Если облако не ответило, программа **не уходит тихо на процессор**, а останавливается с понятной ошибкой: не тот брокер, нет `.tpu` или ошибка воркера.

Остановить: `pkill -f "uvicorn app.main:app"`.

## 4. Открыть интерфейс

В браузере на ноутбуке (VPN включён):
```
https://hackathon.lin-q.ru/user/<ЛОГИН>/proxy/8000/
```
Слеш в конце обязателен. Проверка, что прокси работает: `…/proxy/8000/api/health` показывает текст с `"engine": "linq_tpu_cloud"`.

**Если вместо этого Jupyter показывает 404**, значит, в Jupyter нет модуля `jupyter-server-proxy`:
- поставьте его: `pip install --user jupyter-server-proxy`, затем **File → Hub Control Panel → Stop My Server → Start My Server**, снова запустите программу (шаг 3);
- или спросите экспертов LinQ, как открыть веб-сервис, запущенный в Jupyter на порту 8000.

## 5. Цифры для защиты

```bash
cd ~/work/linq-safety-vision/backend
ENGINE=cloud python3 -m scripts.benchmark --image ../samples/bus.jpg --iters 100 --streams 1 2 4
```
Время инференса здесь включает дорогу кадра до облака и обратно. Для сравнения тот же замер на процессоре: `ENGINE=onnx`.

## 6. Настройки облака (`.env`, обычно менять не нужно)

| переменная | по умолчанию | что это |
|---|---|---|
| `CLOUD_HOST` | `10.0.114.30` | брокер RabbitMQ облака |
| `CLOUD_PORT` | `5672` | порт брокера |
| `CLOUD_USER` / `CLOUD_PASSWORD` | `guest` / `guest` | вход в брокер |
| `CLOUD_TIMEOUT` | `15` | сколько секунд ждать ответа на кадр |
| `CLOUD_CACHE_DIR` | `/auto/cache` | общая папка программ |
| `CLOUD_PROGRAM` | пусто | готовый путь к `.tpu` в общей папке (иначе копируется из `models/`) |

## Проверка перед защитой

- [ ] в статусе интерфейса написано «LinQ TPU (облако)»;
- [ ] `curl -s localhost:8000/api/health` показывает `"engine": "linq_tpu_cloud"` и пустой `"warnings"`;
- [ ] загруженное видео показывает рамки людей, а тревоги приходят;
- [ ] сохранены цифры бенчмарка.
