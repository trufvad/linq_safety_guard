"""Сквозной тест запущенного сервера.

    uvicorn app.main:app --port 8000      # в другом терминале (любой ENGINE)

Тест сам создаёт служебную камеру из samples/test_people.mp4 (реальная детекция) и удаляет её в конце,
События, созданные во время теста, остаются в журнале — запускайте на тестовой копии данных.
    python tests/test_api_e2e.py [http://127.0.0.1:8000]

Проверяет все маршруты, которые использует фронтенд (FRONTEND.md), и WebSocket.
Займёт около 40 секунд: ждём, пока демо-сцена выдаст нарушения.
"""
from __future__ import annotations

import asyncio
import json
import sys
import time

import requests
from pathlib import Path

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8000"
WS = BASE.replace("http", "ws", 1) + "/ws/events"
ok = 0


def check(cond, msg):
    global ok
    if not cond:
        raise AssertionError(msg)
    ok += 1
    print("ok  ", msg)


async def ws_collect(seconds: float):
    import websockets

    msgs = []
    async with websockets.connect(WS) as ws:
        t0 = time.time()
        while time.time() - t0 < seconds:
            try:
                msgs.append(json.loads(await asyncio.wait_for(ws.recv(), timeout=1)))
            except asyncio.TimeoutError:
                pass
            if sum(m["type"] == "event.created" for m in msgs) >= 3:
                break
    return msgs


def main():
    h = requests.get(f"{BASE}/api/health").json()
    check(h["status"] in ("ok", "degraded") and "engine" in h, f"health: engine={h['engine']} warnings={len(h['warnings'])}")

    rules = requests.get(f"{BASE}/api/rules").json()
    types = {r["type"] for r in rules}
    check({"danger_zone", "machine_proximity", "fall", "running", "no_ppe"} <= types, f"rules: {sorted(types)}")
    check(not next(r for r in rules if r["type"] == "no_ppe")["available"], "no_ppe недоступно на COCO-модели")

    cam = "e2e-test"
    requests.delete(f"{BASE}/api/cameras/{cam}")
    sample_video = Path(__file__).resolve().parents[2] / "samples" / "test_people.mp4"
    r = requests.post(f"{BASE}/api/cameras", json={
        "id": cam, "name": "E2E тестовое видео", "source": str(sample_video), "area": "Тест",
        "zones": [{"id": "z1", "name": "Проход", "kind": "danger",
                   "polygon": [[0.0, 0.85], [1.0, 0.85], [1.0, 1.0], [0.0, 1.0]]}]})
    check(r.status_code == 201, "POST /api/cameras (служебная камера)")
    time.sleep(1.5)
    cams = requests.get(f"{BASE}/api/cameras").json()
    check(any(c["id"] == cam and c["status"] == "running" for c in cams), f"cameras: {[(c['id'], c['status']) for c in cams]}")

    r = requests.get(f"{BASE}/api/cameras/{cam}/frame.jpg")
    check(r.status_code == 200 and r.content[:2] == b"\xff\xd8", f"frame.jpg {len(r.content)} байт")

    with requests.get(f"{BASE}/api/cameras/{cam}/stream.mjpg", stream=True, timeout=5) as r:
        chunk = next(r.iter_content(4096))
        check(r.headers["content-type"].startswith("multipart/x-mixed-replace") and b"--frame" in chunk, "stream.mjpg отдаёт кадры")

    print("     жду нарушения через WebSocket (до 40 c)...")
    msgs = asyncio.run(ws_collect(40))
    kinds = [m["type"] for m in msgs]
    check(kinds and kinds[0] == "hello", "ws: первое сообщение hello")
    check("camera.stats" in kinds, "ws: camera.stats раз в секунду")
    created = [m["data"] for m in msgs if m["type"] == "event.created"]
    check(len(created) >= 1, f"ws: event.created x{len(created)}: {[e['violation_type'] for e in created]}")
    ev = created[0]
    for field in ("id", "camera_id", "violation_type", "severity", "track_id", "bbox", "started_at", "status", "snapshot_url"):
        assert field in ev, field
    check(all(0 <= v <= 1 for v in ev["bbox"]), f"bbox нормализован: {ev['bbox']}")
    check(len({(e["camera_id"], e["track_id"], e["violation_type"]) for e in created}) == len(created),
          "без дублей по (камера, трек, тип)")

    r = requests.get(BASE + ev["snapshot_url"])
    check(r.status_code == 200 and r.content[:2] == b"\xff\xd8", "snapshot.jpg инцидента")

    lst = requests.get(f"{BASE}/api/events", params={"limit": 2, "offset": 0}).json()
    check(lst["total"] >= len(created) and len(lst["items"]) <= 2, f"events: total={lst['total']}, пагинация")
    f = requests.get(f"{BASE}/api/events", params={"violation_type": ev["violation_type"]}).json()
    check(all(i["violation_type"] == ev["violation_type"] for i in f["items"]), "events: фильтр по типу")

    p = requests.patch(f"{BASE}/api/events/{ev['id']}", json={"status": "false", "comment": "тест"}).json()
    check(p["status"] == "false" and p["comment"] == "тест", "PATCH статус false")
    bad = requests.patch(f"{BASE}/api/events/{ev['id']}", json={"status": "wrong"})
    check(bad.status_code == 422, "PATCH с неверным статусом -> 422")
    check(requests.patch(f"{BASE}/api/events/nope", json={"status": "confirmed"}).status_code == 404, "PATCH несуществующего -> 404")

    zones = [{"id": "zt", "name": "Тестовая", "kind": "machine",
              "polygon": [[0.1, 0.1], [0.3, 0.1], [0.3, 0.3]], "schedule": {"start": "08:00", "end": "20:00"}}]
    r = requests.put(f"{BASE}/api/cameras/{cam}/zones", json=zones)
    check(r.status_code == 200 and r.json()[0]["kind"] == "machine", "PUT zones")
    r = requests.put(f"{BASE}/api/cameras/{cam}/zones", json=[{"id": "x", "name": "x", "polygon": [[0, 0], [2, 2], [1, 0]]}])
    check(r.status_code == 422, "PUT zones вне 0..1 -> 422")
    r = requests.put(f"{BASE}/api/cameras/{cam}/rules", json={"running": {"enabled": False}})
    check(r.status_code == 200, "PUT rules")
    check(requests.put(f"{BASE}/api/cameras/{cam}/rules", json={"bogus": {"enabled": True}}).status_code == 422,
          "PUT rules с неизвестным правилом -> 422")
    got = requests.get(f"{BASE}/api/cameras/{cam}").json()
    check(got["zones"][0]["id"] == "zt" and got["rules"]["running"]["enabled"] is False, "конфиг камеры сохранился")

    check(requests.post(f"{BASE}/api/cameras/{cam}/stop").json()["status"] == "stopped", "stop камеры")
    time.sleep(0.5)
    check(requests.post(f"{BASE}/api/cameras/{cam}/start").json()["status"] in ("starting", "running"), "start камеры")

    s = requests.get(f"{BASE}/api/stats/summary").json()
    check(s["total"] >= 1 and len(s["heatmap"]) == 7 and len(s["heatmap"][0]) == 24, "stats/summary + heatmap 7x24")
    perf = requests.get(f"{BASE}/api/stats/performance").json()
    check(perf["cameras"] and "fps" in perf["cameras"][0], f"stats/performance fps={perf['cameras'][0]['fps']}")
    rep = requests.get(f"{BASE}/api/reports", params={"period": "day"}).json()
    check(rep["markdown"].startswith("# Отчёт"), "reports?period=day")

    # --- загрузка видео ---------------------------------------------------
    sample = Path(__file__).resolve().parents[2] / "samples" / "test_people.mp4"
    if sample.exists():
        with sample.open("rb") as f:
            r = requests.post(f"{BASE}/api/videos", files={"file": ("test_people.mp4", f, "video/mp4")},
                              data={"mode": "new", "name": "E2E видео", "area": "Тест"})
        check(r.status_code == 201 and r.json()["camera_id"].startswith("video-"), f"POST /api/videos -> {r.json().get('camera_id')}")
        vid, vcam = r.json()["video"], r.json()["camera_id"]
        check(vid["width"] > 0 and vid["fps"] > 0, f"видео распознано: {vid['width']}x{vid['height']}, {vid['duration_s']} с")
        check(any(c["id"] == vcam for c in requests.get(f"{BASE}/api/cameras").json()), "камера из видео появилась")
        check(any(v["id"] == vid["id"] for v in requests.get(f"{BASE}/api/videos").json()), "GET /api/videos")
        check(requests.delete(f"{BASE}/api/videos/{vid['id']}").status_code == 409, "удалить используемое видео -> 409")
        bad = requests.post(f"{BASE}/api/videos", files={"file": ("x.txt", b"hello", "text/plain")})
        check(bad.status_code == 415, "неверное расширение -> 415")
        broken = requests.post(f"{BASE}/api/videos", files={"file": ("x.mp4", b"not a video", "video/mp4")})
        check(broken.status_code == 422, "битый файл -> 422")
        nocam = requests.post(f"{BASE}/api/videos", files={"file": ("y.mp4", b"0", "video/mp4")}, data={"mode": "replace", "camera_id": "nope"})
        check(nocam.status_code == 404, "замена источника у несуществующей камеры -> 404")
        requests.delete(f"{BASE}/api/cameras/{vcam}")
        check(requests.delete(f"{BASE}/api/videos/{vid['id']}").status_code == 204, "удалить видео после удаления камеры")

    t = requests.post(f"{BASE}/api/notify/test")
    check(t.status_code in (200, 400, 502), f"POST /api/notify/test -> {t.status_code} (telegram={h.get('telegram')})")

    r = requests.options(f"{BASE}/api/events", headers={"Origin": "http://localhost:5173", "Access-Control-Request-Method": "PATCH"})
    check(r.headers.get("access-control-allow-origin") in ("*", "http://localhost:5173"), "CORS для фронтенда")
    check(requests.delete(f"{BASE}/api/cameras/{cam}").status_code == 204, "служебная камера удалена")
    cleared = requests.delete(f"{BASE}/api/events").json()
    check(cleared["deleted"] >= 1 and requests.get(f"{BASE}/api/events").json()["total"] == 0, f"DELETE /api/events: удалено {cleared['deleted']}")
    check(requests.get(f"{BASE}/api/stats/summary").json()["total"] == 0, "статистика после очистки = 0")
    check(requests.get(BASE + ev["snapshot_url"]).status_code == 404, "снимки очищены вместе с журналом")
    print(f"\nВСЁ ОК: {ok} проверок")


if __name__ == "__main__":
    main()
