"""Тесты дополнительных паттернов (п. 1 задания): pytest -q tests/test_extended.py"""
from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.inference.base import Detection  # noqa: E402
from app.rules import RULES, FrameContext  # noqa: E402
from app.schemas import CameraConfig, Zone  # noqa: E402
from app.tracking.bytetrack import ByteTracker  # noqa: E402

W, H = 1280, 720


def _det(x1, y1, x2, y2, cls=0, conf=0.9):
    return Detection(x1, y1, x2, y2, conf, cls, "person" if cls == 0 else "truck")


def _zone(kind, poly):
    return Zone(id=kind, name=kind, kind=kind, polygon=poly)


def _ctx(persons, zones=(), machines=(), others=(), t=0.0, image=None):
    cam = CameraConfig(id="c", name="c", source="v.mp4", zones=list(zones))
    return FrameContext(cam, t, datetime(2026, 10, 24, 10, 0), W, H, persons, list(machines), list(others), image)


class _Obj:
    def __init__(self, label, box, conf=0.6):
        self.label, self.box, self.conf, self.track_id = label, np.array(box, np.float32), conf, -1

    @property
    def center(self):
        return float((self.box[0] + self.box[2]) / 2), float((self.box[1] + self.box[3]) / 2)


def _run(rule, boxes, dt=0.2, **ctx_kw):
    """Прогнать последовательность рамок человека через трекер и правило; вернуть время первого срабатывания."""
    tr, first = ByteTracker(min_hits=1), None
    for k, box in enumerate(boxes):
        t = k * dt
        persons = [x for x in tr.update([_det(*box)], t) if x.cls == 0]
        if rule.evaluate(_ctx(persons, t=t, **ctx_kw)) and first is None:
            first = t
    return first


def test_sudden_move_in_machine_zone_vs_outside_and_walking():
    z = _zone("machine", [[0.0, 0.3], [0.6, 0.3], [0.6, 1.0], [0.0, 1.0]])
    fast = [(100 + 50 * k, 300, 145 + 50 * k, 480) for k in range(12)]  # ~1.4 роста/с
    walk = [(100 + 12 * k, 300, 145 + 12 * k, 480) for k in range(12)]  # ~0.3 роста/с
    assert _run(RULES["sudden_move_machine"](), fast, zones=[z]) is not None
    assert _run(RULES["sudden_move_machine"](), walk, zones=[z]) is None
    assert _run(RULES["sudden_move_machine"](), fast) is None  # ни зоны, ни техники рядом


def _flame_frame(k, flicker=True, moving=False):
    img = np.full((H, W, 3), 70, np.uint8)
    r = (14 + (9 if k % 2 else 0)) if flicker else 18
    x = 900 + (40 * k if moving else 0)
    cv2.ellipse(img, (x, 200), (r // 2 + 4, r), 0, 0, 360, (40, 170, 255), -1)  # оранжевое пламя (BGR)
    cv2.ellipse(img, (x, 205), (4, r // 2), 0, 0, 360, (190, 240, 255), -1)      # яркое ядро
    return img


def test_open_fire_flicker_vs_static_helmet():
    for flicker, expect in ((True, True), (False, False)):
        rule, fired = RULES["open_fire"](), False
        for k in range(15):
            fired |= bool(rule.evaluate(_ctx([], t=k * 0.2, image=_flame_frame(k, flicker))))
        assert fired == expect, flicker


def test_open_fire_allowed_in_smoking_area_and_by_model_label():
    smoke = _zone("smoking_area", [[0.6, 0.1], [0.8, 0.1], [0.8, 0.5], [0.6, 0.5]])
    rule, fired = RULES["open_fire"](), False
    for k in range(15):
        fired |= bool(rule.evaluate(_ctx([], zones=[smoke], t=k * 0.2, image=_flame_frame(k))))
    assert not fired
    tr = ByteTracker(min_hits=1)
    p = tr.update([_det(500, 300, 580, 540)], 0.0)
    rule = RULES["open_fire"]({"heuristic": False})
    hits = rule.evaluate(_ctx(p, others=[_Obj("cigarette", [545, 330, 555, 336])]))
    assert len(hits) == 1 and hits[0].track is p[0] and hits[0].details["title"] == "Курение вне отведённого места"


def test_climb_fence_crawl_conveyor_and_suspended_load():
    fence = _zone("fence", [[0.45, 0.6], [0.55, 0.6], [0.55, 0.75], [0.45, 0.75]])
    stand_near = [(500, 300, 560, 480)] * 10               # стоит перед ограждением
    climb = stand_near + [(600, 300 - 15 * k, 660, 480 - 15 * k) for k in range(1, 8)]  # поднимается на ограждение
    assert _run(RULES["climb_crawl"](), stand_near, zones=[fence]) is None
    assert _run(RULES["climb_crawl"](), climb, zones=[fence]) is not None

    conv = _zone("conveyor", [[0.3, 0.4], [0.7, 0.4], [0.7, 0.8], [0.3, 0.8]])
    walk_by = [(500 + 10 * k, 300, 560 + 10 * k, 480) for k in range(15)]
    crawl = walk_by[:8] + [(580 + 10 * k, 420, 680 + 10 * k, 480) for k in range(8)]
    assert _run(RULES["climb_crawl"](), walk_by, zones=[conv]) is None
    assert _run(RULES["climb_crawl"](), crawl, zones=[conv]) is not None

    load = _zone("suspended_load", [[0.3, 0.4], [0.7, 0.4], [0.7, 0.8], [0.3, 0.8]])
    assert _run(RULES["climb_crawl"](), walk_by, zones=[load]) is not None


def test_height_zone_harness():
    z = _zone("height", [[0.3, 0.2], [0.7, 0.2], [0.7, 0.6], [0.3, 0.6]])
    tr = ByteTracker(min_hits=1)
    p = tr.update([_det(600, 100, 660, 300)], 0.0)
    rule = RULES["height_no_harness"]()
    rule.model_labels = {"person"}
    hits = rule.evaluate(_ctx(p, zones=[z]))
    assert len(hits) == 1 and hits[0].details["harness_check"] == "not_available"
    rule.model_labels = {"person", "harness"}
    assert len(rule.evaluate(_ctx(p, zones=[z]))) == 1
    assert rule.evaluate(_ctx(p, zones=[z], others=[_Obj("harness", [615, 140, 645, 200])])) == []
    assert rule.evaluate(_ctx(p)) == []  # вне зоны высоты


def test_motionless_lying_vs_moving_and_standing():
    lying = [(960, 520, 1140, 580)] * 50                                   # лежит 10 с
    crawling = [(960 + 15 * k, 520, 1140 + 15 * k, 580) for k in range(50)]
    standing = [(600, 300, 660, 480)] * 50
    t = _run(RULES["motionless"](), lying)
    assert t is not None and 8.0 <= t <= 9.5, t
    assert _run(RULES["motionless"](), crawling) is None
    assert _run(RULES["motionless"](), standing) is None


def test_cargo_violations():
    tr = ByteTracker(min_hits=1)
    p = tr.update([_det(500, 200, 580, 520)], 0.0)
    rule = RULES["cargo_violation"]()

    def reasons(box):
        hits = rule.evaluate(_ctx(p, others=[_Obj("suitcase", box)]))
        return hits[0].details["reasons"] if hits else []

    assert reasons([505, 120, 575, 195]) == ["over_head"]               # над головой
    assert "blocks_view" in reasons([505, 205, 575, 290])               # закрывает лицо
    assert "oversize" in reasons([470, 260, 610, 470])                  # крупногабаритный
    assert reasons([510, 330, 570, 400]) == []                          # нормально в руках у пояса
    assert reasons([590, 470, 650, 520]) == []                          # стоит на полу рядом
