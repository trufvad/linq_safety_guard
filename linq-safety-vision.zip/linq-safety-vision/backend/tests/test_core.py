"""pytest -q  (или python tests/test_core.py)"""
from __future__ import annotations

import os
import sys
import tempfile
from datetime import datetime
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.events.dedup import IncidentDeduplicator  # noqa: E402
from app.inference.base import Detection  # noqa: E402
from app.inference.postprocess import ANCHORS, STRIDES, decode_outputs  # noqa: E402
from app.inference.preprocess import preprocess  # noqa: E402
from app.rules import RULES, FrameContext  # noqa: E402
from app.schemas import CameraConfig, Schedule, Zone  # noqa: E402
from app.tracking.bytetrack import ByteTracker  # noqa: E402


def _logit(p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p))


def _encode_box(cx, cy, w, h, cls, layout="nchw", nc=80):
    """Обратная операция к декоду YOLOv5: кладёт один бокс в сырые логиты голов."""
    heads = []
    for i, s in enumerate(STRIDES):
        g = 640 // s
        raw = np.full((3, g, g, 5 + nc), -10.0, np.float32)
        if i == 1:                                   # кладём в P4, якорь 1 (62x45)
            gx, gy = int(cx // s), int(cy // s)
            a = ANCHORS[i][1]
            raw[1, gy, gx, 0] = _logit(((cx / s - gx) + 0.5) / 2)
            raw[1, gy, gx, 1] = _logit(((cy / s - gy) + 0.5) / 2)
            raw[1, gy, gx, 2] = _logit(np.sqrt(w / a[0]) / 2)
            raw[1, gy, gx, 3] = _logit(np.sqrt(h / a[1]) / 2)
            raw[1, gy, gx, 4] = _logit(0.95)
            raw[1, gy, gx, 5 + cls] = _logit(0.9)
        t = raw.transpose(0, 3, 1, 2).reshape(1, 3 * (5 + nc), g, g)       # NCHW (1,255,g,g)
        heads.append(t if layout == "nchw" else t.transpose(0, 2, 3, 1))   # NHWC
    return heads


def test_decode_raw_heads_nchw_and_nhwc():
    for layout in ("nchw", "nhwc"):
        heads = _encode_box(300, 200, 80, 60, cls=0, layout=layout)
        # порядок выходов TPU не гарантирован — перемешиваем
        out = decode_outputs({"onnx::Shape_999": heads[2], "onnx::Shape_327": heads[0], "onnx::Shape_663": heads[1]})
        assert len(out) == 1, out
        x1, y1, x2, y2, conf, cls = out[0]
        assert np.allclose([x1, y1, x2, y2], [260, 170, 340, 230], atol=0.5), out
        assert int(cls) == 0 and abs(conf - 0.855) < 0.01


def test_decode_already_decoded_output():
    pred = np.zeros((1, 10, 85), np.float32)
    pred[0, 3, :5] = [100, 100, 50, 100, 0.9]
    pred[0, 3, 5 + 7] = 0.8
    out = decode_outputs({"output0": pred})
    assert len(out) == 1 and int(out[0, 5]) == 7


def test_preprocess_contract():
    img = np.random.randint(0, 255, (720, 1280, 3), np.uint8)
    t, meta = preprocess(img)
    assert t.shape == (1, 3, 640, 640) and t.dtype == np.float32
    assert 0.0 <= t.min() and t.max() <= 1.0
    assert meta.ratio == 0.5 and meta.pad_y == 140


def _det(x1, y1, x2, y2, cls=0, conf=0.9):
    return Detection(x1, y1, x2, y2, conf, cls, "person" if cls == 0 else "truck")


def test_tracker_keeps_id_for_fast_runner():
    tr = ByteTracker()
    ids = set()
    for k in range(15):
        x = 100 + 60 * k                       # 60 px за кадр при ширине 45 -> IoU = 0
        out = tr.update([_det(x, 150, x + 45, 300)], k * 0.2)
        ids |= {t.track_id for t in out}
    assert ids == {1}, ids


def _ctx(persons, zones=(), machines=(), t=0.0):
    cam = CameraConfig(id="c", name="c", source="video.mp4", zones=list(zones))
    return FrameContext(cam, t, datetime(2026, 10, 23, 10, 0), 1280, 720, persons, list(machines), [])


def test_danger_zone_and_schedule():
    tr = ByteTracker(min_hits=1)
    p = tr.update([_det(500, 300, 560, 500)], 0.0)
    z = Zone(id="z", name="z", polygon=[[0.35, 0.5], [0.5, 0.5], [0.5, 0.9], [0.35, 0.9]])
    assert len(RULES["danger_zone"]().evaluate(_ctx(p, [z]))) == 1
    z_off = z.model_copy(update={"schedule": Schedule(start="12:00", end="18:00")})
    assert RULES["danger_zone"]().evaluate(_ctx(p, [z_off])) == []
    night = Schedule(start="22:00", end="06:00")
    assert night.is_active(datetime(2026, 10, 23, 23, 0)) and not night.is_active(datetime(2026, 10, 23, 12, 0))


def test_fall_rule():
    tr = ByteTracker(min_hits=1)
    rule = RULES["fall"]()
    fired_at = None
    for k in range(40):
        t = k * 0.2
        box = (1000, 400, 1060, 580) if t < 2 else (960, 520, 1140, 580)
        p = tr.update([_det(*box)], t)
        if rule.evaluate(_ctx(p, t=t)) and fired_at is None:
            fired_at = t
    assert fired_at is not None and 2.8 <= fired_at <= 3.6, fired_at   # упал в 2 c, тревога через ~1 c


def test_person_lying_detected_after_lying_s():
    tr = ByteTracker(min_hits=1)
    rule = RULES["fall"]()
    first = None
    for k in range(40):
        p = tr.update([_det(960, 520, 1140, 580)], k * 0.2)
        if rule.evaluate(_ctx(p, t=k * 0.2)) and first is None:
            first = k * 0.2
    assert first is not None and 2.8 <= first <= 3.4, first


def test_crouch_and_slow_bend_are_not_falls():
    lerp = lambda a, b, f: [a[i] + (b[i] - a[i]) * f for i in range(4)]
    stand = [600, 300, 660, 480]
    for target, dur in (([595, 370, 665, 480], 0.6), ([580, 390, 680, 480], 1.5)):
        tr, rule, hits = ByteTracker(min_hits=1), RULES["fall"](), []
        for k in range(40):
            t = k * 0.2
            box = stand if t < 2 or t > 2 + dur + 1.2 else lerp(stand, target, min(1, (t - 2) / dur))
            hits += rule.evaluate(_ctx(tr.update([_det(*box)], t), t=t))
        assert hits == [], (target, hits)


def test_tracker_keeps_id_through_fall():
    tr = ByteTracker()
    ids = set()
    for k in range(20):
        t = k * 0.2
        box = (600, 300, 660, 480) if t < 2 else (560, 420, 740, 480)
        ids |= {x.track_id for x in tr.update([_det(*box)], t)}
    assert ids == {1}, ids


def test_zone_of_any_kind_alerts_with_kind_title():
    tr = ByteTracker(min_hits=1)
    p = tr.update([_det(500, 300, 560, 500)], 0.0)
    for kind, title in (("machine", "Нахождение в зоне работы техники"), ("restricted", "Проход в запретную зону")):
        z = Zone(id="z", name="z", kind=kind, polygon=[[0.35, 0.5], [0.5, 0.5], [0.5, 0.9], [0.35, 0.9]])
        hits = RULES["danger_zone"]().evaluate(_ctx(p, [z]))
        assert len(hits) == 1 and hits[0].details["title"] == title


def test_helmet_color_rule():
    import cv2
    from app.rules.builtin import helmet_color_share

    img = np.full((720, 1280, 3), 90, np.uint8)
    box = np.array([600, 200, 680, 520], np.float32)
    cv2.rectangle(img, (600, 200), (680, 520), (60, 60, 60), -1)           # тёмная фигура, тёмные волосы
    assert helmet_color_share(img, box) < 0.18
    cv2.ellipse(img, (640, 222), (24, 22), 0, 180, 360, (0, 215, 255), -1)   # жёлтая каска
    cv2.rectangle(img, (614, 222), (666, 232), (0, 215, 255), -1)
    assert helmet_color_share(img, box) >= 0.18
    img2 = np.full((720, 1280, 3), 250, np.uint8)                             # белая стена за головой
    cv2.rectangle(img2, (600, 240), (680, 520), (60, 60, 60), -1)
    assert helmet_color_share(img2, box) < 0.18                               # фон не считается каской


def test_running_vs_walking():
    for speed, expect in ((300, True), (80, False)):
        tr = ByteTracker(min_hits=1)
        rule, hit = RULES["running"](), False
        for k in range(15):
            x = 100 + speed * k * 0.2
            p = tr.update([_det(x, 150, x + 45, 300)], k * 0.2)
            hit |= bool(rule.evaluate(_ctx(p, t=k * 0.2)))
        assert hit == expect, speed


def test_machine_proximity():
    tr = ByteTracker(min_hits=1)
    tracks = tr.update([_det(500, 300, 560, 500), _det(570, 320, 800, 520, cls=7)], 0.0)
    persons = [t for t in tracks if t.cls == 0]
    machines = [t for t in tracks if t.cls == 7]
    assert len(RULES["machine_proximity"]().evaluate(_ctx(persons, machines=machines))) == 1


def test_dedup_single_alert_and_flicker():
    d = IncidentDeduplicator(gap_tolerance_s=0.6, clear_s=4.0)
    key = ("c", 1, "danger_zone")
    opened = 0
    for k in range(50):                         # 10 c нарушения, с одиночными пропусками
        t = k * 0.2
        hits = [] if k % 7 == 3 else [(key, "hit", 2.0)]
        r = d.update(t, hits, {1})
        for kk, _ in r.opened:
            d.register(kk, "ev1", t)
            opened += 1
    assert opened == 1 and d.suppressed > 30
    r = d.update(15.0, [], {1})                 # 5 с без нарушения -> закрыто
    assert len(r.closed) == 1


def test_dedup_single_frame_glitch_ignored():
    d = IncidentDeduplicator()
    r = d.update(0.0, [(("c", 1, "fall"), "hit", 2.0)], {1})
    r2 = d.update(1.0, [], {1})
    r3 = d.update(3.0, [(("c", 1, "fall"), "hit", 2.0)], {1})
    assert not (r.opened or r2.opened or r3.opened)


def test_db_roundtrip_and_stats():
    from app.db import Database

    with tempfile.TemporaryDirectory() as tmp:
        db = Database(Path(tmp) / "e.db")
        for i, (vt, hour) in enumerate([("fall", 9), ("danger_zone", 9), ("danger_zone", 23)]):
            db.insert_event({"id": f"e{i}", "camera_id": "c1", "camera_name": "К1", "area": "Цех 1",
                             "zone_id": None, "zone_name": None, "violation_type": vt, "title": vt,
                             "severity": "critical", "track_id": i, "confidence": 0.9, "bbox": [0, 0, 1, 1],
                             "started_at": f"2026-10-23T{hour:02d}:00:00+03:00", "ended_at": None,
                             "status": "new", "comment": None, "details": {"a": 1}})
        assert db.list_events(violation_type="danger_zone")["total"] == 2
        assert db.list_events(violation_type="fall,danger_zone", limit=1)["total"] == 3
        db.update_event("e0", status="false", comment="тень")
        s = db.stats()
        assert s["total"] == 3 and s["heatmap"][4][9] == 2   # 23.10.2026 — пятница
        assert {r["status"]: r["n"] for r in s["by_status"]} == {"false": 1, "new": 2}


def test_tpu_metadata_check():
    """Паспорт .tpu: full-граф с int8 ±25 на выходе должен давать предупреждение."""
    import json, zipfile
    from app.inference.tpu_meta import read_tpu_info

    real = Path(__file__).resolve().parents[2] / "models" / "yolov5s_b1_o1_h1m.tpu"
    if real.exists():
        info = read_tpu_info(str(real))
        assert info.kind == "decoded" and info.warnings and info.inputs[0].name == "images"

    def fake(outputs):
        meta = {"inputs": {"1": {"images": {"user_shape": [1, 3, 640, 640], "user_dtype": "float32",
                                            "tpu_dtype": "int8", "scales": [127.0]}}},
                "outputs": {"2": outputs}}
        f = tempfile.NamedTemporaryFile(suffix=".tpu", delete=False)
        with zipfile.ZipFile(f.name, "w") as z:
            z.writestr("metadata.json", json.dumps(meta))
        return f.name

    heads = {f"h{g}": {"user_shape": [1, 255, g, g], "user_dtype": "float32", "tpu_dtype": "int8", "scales": [0.128]}
             for g in (80, 40, 20)}
    good = read_tpu_info(fake(heads))
    assert good.kind == "raw_heads" and good.warnings == [], good.warnings
    for h in heads.values():
        h["scales"] = [0.03]                     # x = q * scale -> ±3.8: логиты обрежутся
    bad = read_tpu_info(fake(heads))
    assert len(bad.warnings) == 3 and "калибровку" in bad.warnings[0]

    cut = Path(__file__).resolve().parents[2] / "models" / "yolov5s_cut_b1_o1_h1m.tpu"
    if cut.exists():
        info = read_tpu_info(str(cut))
        assert info.kind == "raw_heads" and info.warnings == [], info.warnings


def test_telegram_caption_and_video_probe():
    from app.events.notify import TelegramNotifier, format_caption
    from app.videos import _safe_name, probe_video

    cap = format_caption({"id": "e1", "title": "Нахождение в опасной зоне", "severity": "critical",
                          "camera_name": "Ворота <склада>", "area": "Склад", "zone_name": "Станки",
                          "started_at": "2026-10-24T13:00:00+03:00", "track_id": 7, "confidence": 0.9,
                          "details": {"lying_seconds": 3.5}})
    assert "КРИТИЧНО" in cap and "&lt;склада&gt;" in cap and "Станки" in cap and "90%" in cap and len(cap) <= 1024
    assert not TelegramNotifier("", "").enabled
    assert _safe_name("../../etc/пароль?.MP4") == "пароль.mp4"  # путь отброшен

    import cv2
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "v.mp4"
        w = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), 10, (64, 48))
        for _ in range(20):
            w.write(np.zeros((48, 64, 3), np.uint8))
        w.release()
        meta = probe_video(path)
        assert meta["width"] == 64 and meta["height"] == 48 and meta["duration_s"] == 2.0
        bad = Path(tmp) / "bad.mp4"
        bad.write_bytes(b"nope")
        try:
            probe_video(bad)
            raise AssertionError("битый файл принят")
        except ValueError:
            pass


class _Obj:
    def __init__(self, label, box, conf=0.5):
        self.label, self.box, self.conf, self.track_id = label, np.array(box, np.float32), conf, -1

    @property
    def center(self):
        return float((self.box[0] + self.box[2]) / 2), float((self.box[1] + self.box[3]) / 2)


def test_phone_rule_in_hand_vs_far():
    tr = ByteTracker(min_hits=1)
    p = tr.update([_det(500, 300, 580, 540)], 0.0)
    rule = RULES["phone_use"]()
    cam = CameraConfig(id="c", name="c", source="x")
    in_hand = FrameContext(cam, 0, datetime.now(), 1280, 720, p, [], [_Obj("cell phone", [540, 380, 556, 405])])
    far = FrameContext(cam, 0, datetime.now(), 1280, 720, p, [], [_Obj("cell phone", [900, 380, 916, 405])])
    on_floor = FrameContext(cam, 0, datetime.now(), 1280, 720, p, [], [_Obj("cell phone", [530, 525, 546, 540])])
    assert len(rule.evaluate(in_hand)) == 1
    assert rule.evaluate(far) == [] and rule.evaluate(on_floor) == []


def test_dedup_gap_tolerance_per_rule():
    d = IncidentDeduplicator(gap_tolerance_s=0.6)
    key = ("c", 1, "phone_use")
    opened = 0
    for k in range(20):                   # телефон виден только на каждом третьем кадре (5 к/с)
        t = k * 0.2
        hits = [(key, "hit", 2.0, 1.5)] if k % 3 == 0 else []
        r = d.update(t, hits, {1})
        opened += len(r.opened)
        for kk, _ in r.opened:
            d.register(kk, "e", t)
    assert opened == 1

if __name__ == "__main__":
    fails = 0
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            try:
                fn(); print("ok  ", name)
            except Exception as e:  # noqa: BLE001
                fails += 1; print("FAIL", name, repr(e))
    sys.exit(1 if fails else 0)
