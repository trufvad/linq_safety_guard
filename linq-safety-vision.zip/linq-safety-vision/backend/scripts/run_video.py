"""Прогон видео через конвейер без API: события в консоль и в БД, размеченное видео на диск.

    python -m scripts.run_video --source video.mp4 --zones zones.json --out out.mp4

zones.json — список зон как в CONTRACT.md (координаты в долях кадра).
Удобно для чек-поинта и для наполнения БД демо-статистикой (Участник 4).
"""
from __future__ import annotations

import argparse
import json

import cv2
import numpy as np

from app.config import settings
from app.db import Database
from app.inference import create_engine
from app.pipeline import PipelineManager
from app.schemas import CameraConfig, Zone
from app.video.sources import open_source

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True, help="видеофайл, папка с кадрами или rtsp://")
    ap.add_argument("--camera-id", default="cam1")
    ap.add_argument("--camera-name", default="Камера 1")
    ap.add_argument("--area", default="Цех 1")
    ap.add_argument("--zones", help="json со списком зон")
    ap.add_argument("--out", help="сохранить размеченное видео .mp4")
    ap.add_argument("--max-seconds", type=float, default=0)
    a = ap.parse_args()

    zones = [Zone.model_validate(z) for z in json.load(open(a.zones, encoding="utf-8"))] if a.zones else []
    mgr = PipelineManager(settings, create_engine(settings), Database(settings.db_path))
    w = mgr.add_camera(CameraConfig(id=a.camera_id, name=a.camera_name, source=a.source, area=a.area,
                                    zones=zones), start=False)
    writer = None
    for f in open_source(a.source, settings.process_fps, realtime=False, loop=False).frames():
        if a.max_seconds and f.t > a.max_seconds:
            break
        for ev in w.process(f.image, f.t):
            print(f"[t={f.t:6.1f}s] {ev['title']:<32} track #{ev['track_id']:<4} {ev['details']}")
        if a.out and w.last_jpeg:
            frame = cv2.imdecode(np.frombuffer(w.last_jpeg, np.uint8), cv2.IMREAD_COLOR)
            if writer is None:
                writer = cv2.VideoWriter(a.out, cv2.VideoWriter_fourcc(*"mp4v"), settings.process_fps,
                                         (frame.shape[1], frame.shape[0]))
            writer.write(frame)
    if writer:
        writer.release()
    s = w.stats
    print(f"\nкадров: {s['frames']}, конвейер {s['pipeline_ms']:.1f} мс/кадр "
          f"(пре {s['preprocess_ms']:.1f} / инференс {s['inference_ms']:.1f} / пост {s['postprocess_ms']:.1f}), "
          f"подавлено дублей: {s['suppressed_duplicates']}")
    print("по типам:", {r["violation_type"]: r["n"] for r in mgr.db.stats()["by_type"]})
