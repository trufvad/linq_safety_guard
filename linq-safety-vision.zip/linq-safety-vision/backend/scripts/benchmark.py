"""Замеры для README/презентации: препроцессинг, чистый инференс, постпроцессинг,
FPS и задержка при 1 и нескольких параллельных потоках.

    ENGINE=tpu TPU_PROGRAM=/auto/cache/$LOGIN/yolov5s_detector.tpu \
        python -m scripts.benchmark --image samples/bus.jpg --iters 200 --streams 1 2 4 8

Результат: печать таблицы + benchmark_<engine>.json (для графиков Участника 4).
"""
from __future__ import annotations

import argparse
import json
import statistics as st
import threading
import time

import cv2
import numpy as np

from app.config import settings
from app.inference import create_engine


def pct(xs, p):
    return float(np.percentile(xs, p)) if xs else 0.0


def run(engine, img, iters: int, streams: int) -> dict:
    lat, pre, inf, post = [], [], [], []
    lock = threading.Lock()

    def worker(n):
        for _ in range(n):
            t0 = time.perf_counter()
            r = engine.detect(img)
            dt = (time.perf_counter() - t0) * 1e3
            with lock:
                lat.append(dt); pre.append(r.timings.preprocess_ms)
                inf.append(r.timings.inference_ms); post.append(r.timings.postprocess_ms)

    per = max(1, iters // streams)
    th = [threading.Thread(target=worker, args=(per,)) for _ in range(streams)]
    t0 = time.perf_counter()
    for t in th: t.start()
    for t in th: t.join()
    wall = time.perf_counter() - t0
    total = per * streams
    return {"streams": streams, "frames": total, "total_fps": round(total / wall, 2),
            "fps_per_stream": round(total / wall / streams, 2),
            "latency_ms_mean": round(st.mean(lat), 2), "latency_ms_p95": round(pct(lat, 95), 2),
            "preprocess_ms": round(st.mean(pre), 2), "inference_ms": round(st.mean(inf), 2),
            "postprocess_ms": round(st.mean(post), 2)}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", default="samples/bus.jpg")
    ap.add_argument("--iters", type=int, default=100)
    ap.add_argument("--warmup", type=int, default=5)
    ap.add_argument("--streams", type=int, nargs="+", default=[1, 2, 4])
    ap.add_argument("--target-fps", type=float, default=5.0, help="кадр/с на камеру для расчёта ёмкости")
    a = ap.parse_args()

    img = cv2.imread(a.image)
    assert img is not None, a.image
    eng = create_engine(settings)
    for _ in range(a.warmup):
        eng.detect(img)
    print(f"engine={eng.name}  image={a.image} {img.shape[1]}x{img.shape[0]}  "
          f"detections={len(eng.detect(img).detections)}")
    rows = [run(eng, img, a.iters, s) for s in a.streams]
    hdr = ["streams", "total_fps", "fps_per_stream", "latency_ms_mean", "latency_ms_p95",
           "preprocess_ms", "inference_ms", "postprocess_ms"]
    print(" | ".join(hdr))
    for r in rows:
        print(" | ".join(str(r[h]) for h in hdr))
    best = max(r["total_fps"] for r in rows)
    cams = int(best // a.target_fps)
    print(f"\nЁмкость одного ускорителя при {a.target_fps:g} к/с на камеру: ~{cams} камер "
          f"(пик {best} к/с). Цех 5 камер -> {max(1, -(-5 // max(cams, 1)))} шт., "
          f"завод 100 камер -> {-(-100 // max(cams, 1))} шт.")
    out = f"benchmark_{eng.name}.json"
    json.dump({"engine": eng.name, "image": a.image, "rows": rows, "cameras_per_device": cams},
              open(out, "w"), ensure_ascii=False, indent=2)
    print("saved", out)
