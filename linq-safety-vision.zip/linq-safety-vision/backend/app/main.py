"""FastAPI: REST + WebSocket + MJPEG. Запуск: uvicorn app.main:app --host 0.0.0.0 --port 8000"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import threading
import time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from typing import List, Optional, Set

from fastapi import FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response, StreamingResponse

from .config import APP_VERSION, settings
from .db import Database
from .inference import create_engine
from .pipeline import PipelineManager, now_local
from .reports import build_report
from .rules import RULES
from .schemas import CameraConfig, CameraPatch, EventPatch, RuleConfig, Zone
from .videos import create_router as create_videos_router

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("api")


class WsHub:
    def __init__(self) -> None:
        self.clients: Set[asyncio.Queue] = set()
        self.loop: Optional[asyncio.AbstractEventLoop] = None

    def publish_threadsafe(self, msg: dict) -> None:     # вызывается из потоков камер
        if self.loop:
            self.loop.call_soon_threadsafe(self._fanout, msg)

    def _fanout(self, msg: dict) -> None:
        for q in list(self.clients):
            if q.qsize() < 500:
                q.put_nowait(msg)


hub = WsHub()
state: dict = {}


async def _stats_pusher() -> None:
    while True:
        await asyncio.sleep(1.0)
        if hub.clients and "manager" in state:
            hub._fanout({"type": "camera.stats", "data": _cameras_status()})


def _open_browser_when_ready() -> None:
    """Открыть интерфейс в браузере, как только сервер начал принимать соединения.

    Включается OPEN_BROWSER=1 (так делает start.bat). Проверяем 127.0.0.1 по IPv4:
    на Windows «localhost» может сначала пойти по IPv6, где сервер не слушает.
    """
    import socket
    import webbrowser

    port = int(os.getenv("PORT", "8000"))
    for _ in range(120):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=1):
                break
        except OSError:
            time.sleep(0.5)
    url = f"http://localhost:{port}"
    try:
        if not webbrowser.open(url):
            log.info("откройте в браузере: %s", url)
    except Exception:  # noqa: BLE001
        log.info("откройте в браузере: %s", url)


def _purge_legacy_demo(db: Database, mgr: PipelineManager, configs: List[CameraConfig]) -> List[CameraConfig]:
    """Миграция со старых версий: удалить синтетическую «демо-камеру» и всё, что она насобирала."""
    legacy = [c.id for c in configs if c.source.strip().lower() == "demo"]
    if not legacy:
        return configs
    for cam_id in legacy:
        db.delete_camera(cam_id)
    removed = db.delete_events(legacy)
    _remove_snapshots(mgr, removed)
    log.info("удалена демо-камера из прошлой версии: %s (событий: %d)", legacy, len(removed))
    return [c for c in configs if c.id not in legacy]


def _remove_snapshots(mgr: PipelineManager, event_ids: List[str]) -> None:
    for ev_id in event_ids:
        for path in mgr.snapshot_paths(ev_id):
            path.unlink(missing_ok=True)


@asynccontextmanager
async def lifespan(_: FastAPI):
    hub.loop = asyncio.get_running_loop()
    db = Database(settings.db_path)
    engine = create_engine(settings)
    log.info("engine: %s", engine.name)
    mgr = PipelineManager(settings, engine, db)
    mgr.listeners.append(hub.publish_threadsafe)
    state.update(db=db, manager=mgr, started=time.time())

    configs = [CameraConfig.model_validate_json(c) for c in db.load_cameras()]
    configs = _purge_legacy_demo(db, mgr, configs)
    if not configs and settings.cameras_file.exists():
        configs = [CameraConfig.model_validate(c) for c in json.loads(settings.cameras_file.read_text("utf-8"))]
        for c in configs:
            db.save_camera(c.id, c.model_dump_json())
    for c in configs:
        mgr.add_camera(c)
    task = asyncio.create_task(_stats_pusher())
    if os.getenv("OPEN_BROWSER") == "1":
        threading.Thread(target=_open_browser_when_ready, daemon=True, name="open-browser").start()
    yield
    task.cancel()
    mgr.stop_all()
    engine.close()


app = FastAPI(title="LinQ Safety Vision API", version="1.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_methods=["*"], allow_headers=["*"])
app.include_router(create_videos_router(lambda: state["manager"], lambda: state["db"], settings))


def _mgr() -> PipelineManager:
    return state["manager"]


def _db() -> Database:
    return state["db"]


def _worker(cam_id: str):
    w = _mgr().workers.get(cam_id)
    if not w:
        raise HTTPException(404, f"camera {cam_id} not found")
    return w


def _camera_out(w) -> dict:
    return {**w.cfg.model_dump(), "status": w.status, "error": w.error, "stats": w.stats}


def _cameras_status() -> List[dict]:
    return [{"id": w.cfg.id, "status": w.status, "error": w.error, **w.stats} for w in _mgr().workers.values()]


def _persist(w) -> None:
    _db().save_camera(w.cfg.id, w.cfg.model_dump_json())


# --- сервис ------------------------------------------------------------------
@app.get("/api/health")
def health():
    m = _mgr()
    info = getattr(m.engine, "model_info", None)
    return {"status": "degraded" if m.engine.warnings else "ok", "version": APP_VERSION, "engine": m.engine.name,
            "cameras": len(m.workers), "uptime_s": round(time.time() - state["started"]),
            "labels": len(settings.labels), "warnings": m.engine.warnings,
            "telegram": m.telegram.enabled,
            "model": info.to_dict() if info else None}


@app.get("/api/rules")
def rules_catalog():
    """Каталог правил для чекбоксов в конфигураторе."""
    return [cls.describe(settings.labels) for cls in RULES.values()]


@app.post("/api/notify/test")
def notify_test():
    """Проверка Telegram-бота: шлёт тестовое сообщение в TELEGRAM_CHAT_ID."""
    tg = _mgr().telegram
    if not tg.enabled:
        raise HTTPException(400, "Telegram не настроен: задайте TELEGRAM_BOT_TOKEN и TELEGRAM_CHAT_ID в .env")
    ok, detail = tg.send_text_sync("✅ LinQ Safety Vision: бот подключён, тревоги будут приходить сюда.")
    if not ok:
        raise HTTPException(502, f"Telegram ответил ошибкой: {detail}")
    return {"ok": True}


# --- камеры ------------------------------------------------------------------
@app.get("/api/cameras")
def list_cameras():
    return [_camera_out(w) for w in _mgr().workers.values()]


@app.post("/api/cameras", status_code=201)
def create_camera(cfg: CameraConfig):
    if cfg.id in _mgr().workers:
        raise HTTPException(409, "camera id already exists")
    w = _mgr().add_camera(cfg)
    _persist(w)
    return _camera_out(w)


@app.get("/api/cameras/{cam_id}")
def get_camera(cam_id: str):
    return _camera_out(_worker(cam_id))


@app.patch("/api/cameras/{cam_id}")
def patch_camera(cam_id: str, patch: CameraPatch):
    w = _worker(cam_id)
    cfg = w.cfg.model_copy(update=patch.model_dump(exclude_none=True))
    w.reload(cfg)
    _persist(w)
    if patch.enabled is False:
        w.stop()
    elif patch.enabled is True:
        w.start()
    return _camera_out(w)


@app.delete("/api/cameras/{cam_id}", status_code=204)
def delete_camera(cam_id: str):
    _worker(cam_id)
    _mgr().remove_camera(cam_id)
    _db().delete_camera(cam_id)


@app.put("/api/cameras/{cam_id}/zones")
def put_zones(cam_id: str, zones: List[Zone]):
    """Полигоны из Canvas-редактора (координаты в долях кадра 0..1)."""
    w = _worker(cam_id)
    cfg = w.cfg.model_copy(update={"zones": zones})
    w.reload(cfg); _persist(w)
    return cfg.zones


@app.put("/api/cameras/{cam_id}/rules")
def put_rules(cam_id: str, rules: dict[str, RuleConfig]):
    unknown = set(rules) - set(RULES)
    if unknown:
        raise HTTPException(422, f"unknown rules: {sorted(unknown)}")
    w = _worker(cam_id)
    cfg = w.cfg.model_copy(update={"rules": rules})
    w.reload(cfg); _persist(w)
    return cfg.rules


@app.post("/api/cameras/{cam_id}/start")
def start_camera(cam_id: str):
    w = _worker(cam_id); w.start()
    return {"status": w.status}


@app.post("/api/cameras/{cam_id}/stop")
def stop_camera(cam_id: str):
    w = _worker(cam_id); w.stop()
    return {"status": w.status}


@app.get("/api/cameras/{cam_id}/frame.jpg")
def camera_frame(cam_id: str, annotated: bool = False):
    """Стоп-кадр для рисования полигонов (annotated=false — чистый кадр)."""
    import cv2

    w = _worker(cam_id)
    if annotated and w.last_jpeg:
        return Response(w.last_jpeg, media_type="image/jpeg")
    if w.last_frame is None:
        raise HTTPException(503, "no frame yet")
    ok, buf = cv2.imencode(".jpg", w.last_frame)
    return Response(buf.tobytes(), media_type="image/jpeg")


@app.get("/api/cameras/{cam_id}/stream.mjpg")
def camera_stream(cam_id: str):
    """MJPEG с разметкой: <img src=".../stream.mjpg"> в сетке видеопотоков."""
    w = _worker(cam_id)

    def gen():
        last = None
        while True:
            jpg = w.last_jpeg
            if jpg is not None and jpg is not last:
                last = jpg
                yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)

    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")


# --- события -----------------------------------------------------------------
@app.get("/api/events")
def list_events(camera_id: Optional[str] = None, violation_type: Optional[str] = None,
                status: Optional[str] = None, area: Optional[str] = None, zone_id: Optional[str] = None,
                date_from: Optional[datetime] = None, date_to: Optional[datetime] = None,
                limit: int = Query(100, le=1000), offset: int = 0):
    """Фильтры через запятую: ?violation_type=fall,danger_zone&status=new"""
    return _db().list_events(camera_id=camera_id, violation_type=violation_type, status=status, area=area,
                             zone_id=zone_id, date_from=date_from, date_to=date_to, limit=limit, offset=offset)


@app.delete("/api/events")
def clear_events(camera_id: Optional[str] = None):
    """Очистить журнал (и тем самым статистику): все события или только одной камеры."""
    removed = _db().delete_events([camera_id] if camera_id else None)
    _remove_snapshots(_mgr(), removed)
    hub._fanout({"type": "events.cleared", "data": {"camera_id": camera_id, "count": len(removed)}})
    return {"deleted": len(removed)}


@app.get("/api/events/{event_id}")
def get_event(event_id: str):
    ev = _db().get_event(event_id)
    if not ev:
        raise HTTPException(404, "event not found")
    return ev


@app.patch("/api/events/{event_id}")
def patch_event(event_id: str, patch: EventPatch):
    """Валидация оператором: confirmed / false (в датасет дообучения) / escalated (мастеру)."""
    if not _db().get_event(event_id):
        raise HTTPException(404, "event not found")
    ev = _db().update_event(event_id, status=patch.status, comment=patch.comment, operator=patch.operator)
    if patch.status == "false":
        _save_false_positive(ev)
    hub._fanout({"type": "event.updated", "data": ev})
    return ev


def _save_false_positive(ev: dict) -> None:
    """Ложное срабатывание -> data/false_positives/{images,labels} в формате YOLO."""
    _, raw = _mgr().snapshot_paths(ev["id"])
    if not raw.exists():
        return
    base = settings.data_dir / "false_positives"
    (base / "images").mkdir(parents=True, exist_ok=True)
    (base / "labels").mkdir(parents=True, exist_ok=True)
    shutil.copy(raw, base / "images" / raw.name)
    x1, y1, x2, y2 = ev["bbox"]
    (base / "labels" / f"{ev['id']}.txt").write_text(
        f"# {ev['violation_type']} false alarm, person box (yolo xywh)\n"
        f"0 {(x1 + x2) / 2:.5f} {(y1 + y2) / 2:.5f} {x2 - x1:.5f} {y2 - y1:.5f}\n", "utf-8")


@app.get("/api/events/{event_id}/snapshot.jpg")
def event_snapshot(event_id: str, raw: bool = False):
    snap, raw_p = _mgr().snapshot_paths(event_id)
    p = raw_p if raw else snap
    if not p.exists():
        raise HTTPException(404, "snapshot not found")
    return FileResponse(p, media_type="image/jpeg")


# --- аналитика ---------------------------------------------------------------
@app.get("/api/stats/summary")
def stats_summary(date_from: Optional[datetime] = None, date_to: Optional[datetime] = None,
                  camera_id: Optional[str] = None, area: Optional[str] = None):
    return _db().stats(date_from, date_to, camera_id, area)


@app.get("/api/stats/performance")
def stats_performance():
    """FPS и задержка по камерам (для дашборда и бенчмарков LinQ)."""
    return {"engine": _mgr().engine.name, "cameras": _cameras_status()}


@app.get("/api/reports")
def report(period: str = Query("shift", pattern="^(shift|day|week|month)$")):
    """Авто-отчёт по ТБ за смену/сутки/неделю/месяц (markdown + цифры)."""
    now = now_local()
    span = {"shift": timedelta(hours=8), "day": timedelta(days=1), "week": timedelta(days=7),
            "month": timedelta(days=30)}[period]
    stats = _db().stats(now - span, now)
    events = _db().list_events(date_from=now - span, date_to=now, limit=1000)["items"]
    return build_report(period, now - span, now, stats, events)


# --- WebSocket ---------------------------------------------------------------
@app.websocket("/ws/events")
async def ws_events(ws: WebSocket):
    await ws.accept()
    q: asyncio.Queue = asyncio.Queue()
    hub.clients.add(q)
    try:
        await ws.send_json({"type": "hello", "data": {"engine": _mgr().engine.name, "cameras": _cameras_status()}})
        while True:
            await ws.send_text(json.dumps(await q.get(), ensure_ascii=False, default=str))
    except WebSocketDisconnect:
        pass
    finally:
        hub.clients.discard(q)


# --- Веб-интерфейс -------------------------------------------------------------
# Backend сам раздаёт предсобранный фронтенд (frontend/dist): один сервер, один адрес,
# Node.js для запуска не нужен. Объявлено последним, чтобы не перекрывать /api, /ws, /docs.
_UI_RESERVED = ("api/", "ws/", "docs", "redoc", "openapi.json")


@app.get("/{full_path:path}", include_in_schema=False)
def web_ui(full_path: str):
    dist = settings.frontend_dist.resolve()
    if full_path.startswith(_UI_RESERVED):
        raise HTTPException(404, "not found")
    index = dist / "index.html"
    if not index.is_file():
        return Response(
            "<h3>LinQ Safety Vision API работает.</h3><p>Веб-интерфейс не найден "
            f"({dist}). Документация API: <a href='/docs'>/docs</a></p>",
            media_type="text/html; charset=utf-8")
    target = (dist / full_path).resolve()
    if full_path and target.is_file() and dist in target.parents:
        headers = {"Cache-Control": "public, max-age=604800"} if full_path.startswith("assets/") else {}
        return FileResponse(target, headers=headers)
    return FileResponse(index, headers={"Cache-Control": "no-cache"})   # SPA-маршруты React
