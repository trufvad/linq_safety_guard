"""Шаблонный авто-отчёт по охране труда (кнопка «Сгенерировать отчёт»)."""
from __future__ import annotations

from datetime import datetime
from typing import List

PERIOD_RU = {"shift": "смену", "day": "сутки", "week": "неделю", "month": "месяц"}

ADVICE = {
    "danger_zone": "Проверить ограждение и разметку опасных зон, провести внеплановый инструктаж.",
    "machine_proximity": "Разделить маршруты пешеходов и техники, включить звуковую сигнализацию погрузчиков.",
    "fall": "Проверить состояние покрытий и освещённость проходов, разобрать каждый случай с мастером.",
    "running": "Напомнить о запрете бега в цехе, проверить причины спешки (нехватка времени на операции).",
    "no_ppe": "Усилить контроль выдачи СИЗ на входе в цех, применить меры дисциплинарного воздействия.",
}


def build_report(period: str, start: datetime, end: datetime, stats: dict, events: List[dict]) -> dict:
    total = stats["total"]
    status = {r["status"]: r["n"] for r in stats["by_status"]}
    false_n = status.get("false", 0)
    precision = (1 - false_n / total) if total else None
    critical = [e for e in events if e["severity"] == "critical"]
    heat_hours = [sum(row[h] for row in stats["heatmap"]) for h in range(24)]
    peak_hour = max(range(24), key=lambda h: heat_hours[h]) if total else None

    lines = [f"# Отчёт по охране труда за {PERIOD_RU[period]}",
             f"Период: {start:%d.%m.%Y %H:%M} — {end:%d.%m.%Y %H:%M}", "",
             f"**Всего нарушений:** {total}, из них критических: {len(critical)}."]
    if precision is not None:
        lines.append(f"**Подтверждено оператором как реальные:** {precision:.0%} (ложных: {false_n}).")
    if peak_hour is not None:
        lines.append(f"**Пиковый час:** {peak_hour:02d}:00–{peak_hour + 1:02d}:00.")
    lines += ["", "## По типам нарушений"]
    lines += [f"- {r['title']}: {r['n']}" for r in stats["by_type"]] or ["- нарушений нет"]
    lines += ["", "## По участкам"] + [f"- {r['area']}: {r['n']}" for r in stats["by_area"]]
    if stats["by_type"]:
        lines += ["", "## Рекомендации"]
        lines += [f"- {ADVICE.get(r['violation_type'], 'Разобрать случаи с ответственными.')}"
                  for r in stats["by_type"][:3]]
    return {"period": period, "from": start.isoformat(), "to": end.isoformat(), "total": total,
            "critical": len(critical), "precision": precision, "peak_hour": peak_hour,
            "markdown": "\n".join(lines), "stats": stats}
