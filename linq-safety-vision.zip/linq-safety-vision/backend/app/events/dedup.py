"""Таймер подтверждения + кэш активных инцидентов.

Ключ инцидента: (camera_id, track_id, violation_type).
  * pending: нарушение должно держаться непрерывно >= confirm_seconds
    (кратковременные пропуски <= gap_tolerance_s не сбрасывают таймер);
  * active: после подтверждения шлётся РОВНО ОДНО событие "opened",
    пока нарушитель в кадре повторы гасятся;
  * если нарушения нет > clear_s (или трек пропал) — событие "closed";
  * cooldown_s после закрытия не даёт тому же ключу «мигать».
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

Key = Tuple[str, int, str]


@dataclass
class _Pending:
    first_t: float
    last_t: float
    gap: float = 0.6


@dataclass
class ActiveIncident:
    event_id: str
    key: Key
    opened_t: float
    last_t: float
    payload: dict = field(default_factory=dict)


@dataclass
class DedupResult:
    opened: List[Tuple[Key, object]] = field(default_factory=list)   # (key, hit) — создать событие
    closed: List[ActiveIncident] = field(default_factory=list)       # закрыть событие


class IncidentDeduplicator:
    def __init__(self, gap_tolerance_s: float = 0.6, clear_s: float = 4.0, cooldown_s: float = 10.0):
        self.gap, self.clear, self.cooldown = gap_tolerance_s, clear_s, cooldown_s
        self.pending: Dict[Key, _Pending] = {}
        self.active: Dict[Key, ActiveIncident] = {}
        self.closed_at: Dict[Key, float] = {}
        self.suppressed = 0          # счётчик подавленных дублей (для метрик/демо)

    def update(self, t: float, hits: List[tuple], alive_track_ids: set) -> DedupResult:
        """hits: [(key, hit, confirm_seconds[, gap_tolerance_s])] нарушений текущего кадра.

        gap_tolerance_s у правила — сколько можно «не видеть» нарушение, не сбрасывая таймер
        (мелкие предметы вроде телефона детектор видит не на каждом кадре).
        """
        res = DedupResult()
        seen = set()
        for item in hits:
            key, hit, confirm_s = item[:3]
            gap = item[3] if len(item) > 3 and item[3] is not None else self.gap
            seen.add(key)
            if key in self.active:
                self.active[key].last_t = t
                self.suppressed += 1
                continue
            if t - self.closed_at.get(key, -1e9) < self.cooldown:
                self.suppressed += 1
                continue
            p = self.pending.get(key)
            if p is None or t - p.last_t > gap:
                p = self.pending[key] = _Pending(t, t, gap)
            p.last_t = t
            if t - p.first_t >= confirm_s:
                res.opened.append((key, hit))
                del self.pending[key]

        for key in [k for k, p in self.pending.items() if k not in seen and t - p.last_t > p.gap]:
            del self.pending[key]
        for key, inc in list(self.active.items()):
            if key not in seen and (t - inc.last_t > self.clear or key[1] not in alive_track_ids):
                res.closed.append(inc)
                self.closed_at[key] = t
                del self.active[key]
        return res

    def register(self, key: Key, event_id: str, t: float, payload: dict | None = None) -> None:
        self.active[key] = ActiveIncident(event_id, key, t, t, payload or {})
