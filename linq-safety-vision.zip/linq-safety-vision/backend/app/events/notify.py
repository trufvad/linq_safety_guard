"""Telegram-уведомления мастеру смены.

Настройка (.env в корне проекта):
    TELEGRAM_BOT_TOKEN=123456:ABC...   токен от @BotFather
    TELEGRAM_CHAT_ID=-100123456789     id чата/группы (узнать: написать боту и открыть
                                       https://api.telegram.org/bot<TOKEN>/getUpdates)
    TELEGRAM_API_URL=https://api.telegram.org   (необязательно: свой прокси/зеркало)

На каждый подтверждённый инцидент уходит ОДНО фото: кадр с выделенным
нарушителем и подписью (тип, опасность, камера, зона, время, уверенность).
Отправка в фоновом потоке с очередью, чтобы сеть не тормозила видеоконвейер;
при ошибке сети — 3 попытки, при ответе 429 — пауза, которую просит Telegram.
"""
from __future__ import annotations

import html
import logging
import os
import queue
import threading
import time
from typing import Optional, Tuple

log = logging.getLogger(__name__)

SEVERITY = {"critical": "🔴 КРИТИЧНО", "warning": "🟠 Предупреждение", "info": "🔵 Инфо"}


def format_caption(ev: dict) -> str:
    """Подпись к фото инцидента (HTML, до 1024 символов — лимит Telegram)."""
    e = lambda v: html.escape(str(v))  # noqa: E731
    lines = [
        f"<b>⚠️ {e(ev.get('title', ev.get('violation_type', 'Нарушение')))}</b>",
        SEVERITY.get(ev.get("severity", ""), e(ev.get("severity", ""))),
        "",
        f"📷 Камера: {e(ev.get('camera_name', ev.get('camera_id', '')))}",
        f"🏭 Участок: {e(ev.get('area', ''))}",
    ]
    if ev.get("zone_name"):
        lines.append(f"🚧 Зона: {e(ev['zone_name'])}")
    started = str(ev.get("started_at", ""))
    lines.append(f"🕒 Время: {e(started[:19].replace('T', ' '))}")
    lines.append(f"🎯 Объект #{e(ev.get('track_id', '?'))}, уверенность {float(ev.get('confidence', 0)):.0%}")
    det = ev.get("details") or {}
    if "lying_seconds" in det:
        lines.append(f"Лежит без движения {det['lying_seconds']} с")
    if "gap_heights" in det and det.get("machine_label"):
        lines.append(f"Рядом техника: {e(det['machine_label'])}")
    if "speed_heights_per_s" in det:
        lines.append(f"Скорость {det['speed_heights_per_s']} ростов/с")
    if det.get("missing"):
        lines.append(f"Нет СИЗ: {e(', '.join(det['missing']))}")
    lines.append(f"\nID: <code>{e(ev.get('id', ''))}</code>")
    return "\n".join(lines)[:1024]


class TelegramNotifier:
    def __init__(self, token: str, chat_id: str, api_url: Optional[str] = None):
        self.enabled = bool(token and chat_id)
        base = (api_url or os.getenv("TELEGRAM_API_URL") or "https://api.telegram.org").rstrip("/")
        self._base = f"{base}/bot{token}"
        self._chat = chat_id
        self._q: "queue.Queue[tuple[str, bytes]]" = queue.Queue(maxsize=200)
        self.sent = self.failed = 0
        if self.enabled:
            threading.Thread(target=self._loop, daemon=True, name="telegram").start()
            log.info("Telegram-уведомления включены (chat_id=%s)", chat_id)
        else:
            log.info("Telegram-уведомления выключены: нет TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID")

    # --- публичное API -------------------------------------------------------
    def send_incident(self, ev: dict, jpeg: bytes) -> None:
        self.send(format_caption(ev), jpeg)

    def send(self, caption: str, jpeg: bytes) -> None:
        if not self.enabled:
            return
        try:
            self._q.put_nowait((caption, jpeg))
        except queue.Full:
            self.failed += 1
            log.warning("очередь Telegram переполнена, тревога пропущена")

    def send_text_sync(self, text: str) -> Tuple[bool, str]:
        """Синхронная отправка текста — для проверки настроек из API."""
        return self._post("sendMessage", data={"chat_id": self._chat, "text": text})

    # --- внутреннее ------------------------------------------------------------
    def _post(self, method: str, data: dict, files: Optional[dict] = None) -> Tuple[bool, str]:
        import requests

        err = "нет ответа"
        for attempt in range(3):
            try:
                r = requests.post(f"{self._base}/{method}", data=data, files=files, timeout=15)
                if r.status_code == 429:
                    wait = float(r.json().get("parameters", {}).get("retry_after", 3))
                    time.sleep(min(wait, 30))
                    continue
                body = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
                if r.ok and body.get("ok", True):
                    return True, "ok"
                return False, body.get("description", f"HTTP {r.status_code}")
            except Exception as e:  # noqa: BLE001
                err = str(e)
                time.sleep(1.5 * (attempt + 1))
        return False, err

    def _loop(self) -> None:
        while True:
            caption, jpeg = self._q.get()
            ok, detail = self._post(
                "sendPhoto",
                data={"chat_id": self._chat, "caption": caption, "parse_mode": "HTML"},
                files={"photo": ("incident.jpg", jpeg, "image/jpeg")},
            )
            if ok:
                self.sent += 1
            else:
                self.failed += 1
                log.warning("Telegram: не удалось отправить тревогу: %s", detail)
