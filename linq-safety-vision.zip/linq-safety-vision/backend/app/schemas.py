"""JSON-контракт бэкенд <-> фронтенд (Участник 3). Подробно — ../CONTRACT.md."""
from __future__ import annotations

from datetime import datetime, time
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, field_validator

Point = List[float]   # [x, y] в долях кадра 0..1 (не зависит от разрешения)


class Schedule(BaseModel):
    """Окно активности, например 08:00–12:00. Через полночь тоже можно: 22:00–06:00."""
    start: str = "00:00"
    end: str = "23:59"
    weekdays: List[int] = Field(default_factory=lambda: [0, 1, 2, 3, 4, 5, 6])  # 0 = Пн

    def is_active(self, now: datetime) -> bool:
        if now.weekday() not in self.weekdays:
            return False
        s, e, cur = time.fromisoformat(self.start), time.fromisoformat(self.end), now.time()
        return s <= cur <= e if s <= e else (cur >= s or cur <= e)


class Zone(BaseModel):
    id: str
    name: str
    kind: Literal["danger", "machine", "restricted"] = "danger"
    polygon: List[Point]
    schedule: Optional[Schedule] = None
    enabled: bool = True

    @field_validator("polygon")
    @classmethod
    def _poly(cls, v: List[Point]) -> List[Point]:
        if len(v) < 3:
            raise ValueError("polygon needs >= 3 points")
        for p in v:
            if len(p) != 2 or not all(-0.01 <= c <= 1.01 for c in p):
                raise ValueError("points must be [x, y] normalized to 0..1")
        return v


class RuleConfig(BaseModel):
    enabled: bool = True
    params: Dict[str, Any] = Field(default_factory=dict)
    schedule: Optional[Schedule] = None


class CameraConfig(BaseModel):
    id: str
    name: str
    source: str                                   # путь к видео, rtsp://..., папка с кадрами или "0" (веб-камера)
    area: str = "Цех 1"                            # участок/цех для фильтров и аналитики
    enabled: bool = True
    zones: List[Zone] = Field(default_factory=list)
    rules: Dict[str, RuleConfig] = Field(default_factory=dict)   # ключ = rule type


class CameraPatch(BaseModel):
    name: Optional[str] = None
    source: Optional[str] = None
    area: Optional[str] = None
    enabled: Optional[bool] = None


EventStatus = Literal["new", "confirmed", "false", "escalated", "resolved"]


class EventOut(BaseModel):
    id: str
    camera_id: str
    camera_name: str
    area: str
    zone_id: Optional[str] = None
    zone_name: Optional[str] = None
    violation_type: str
    title: str
    severity: Literal["critical", "warning", "info"]
    track_id: int
    confidence: float
    bbox: List[float]                  # [x1,y1,x2,y2] в долях кадра
    started_at: datetime
    ended_at: Optional[datetime] = None
    status: EventStatus = "new"
    comment: Optional[str] = None
    snapshot_url: str
    details: Dict[str, Any] = Field(default_factory=dict)


class EventPatch(BaseModel):
    status: Literal["new", "confirmed", "false", "escalated", "resolved"]
    comment: Optional[str] = None
    operator: Optional[str] = None
