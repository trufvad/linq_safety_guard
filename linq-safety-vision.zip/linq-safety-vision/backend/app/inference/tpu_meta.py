"""Чтение паспорта .tpu (это zip с metadata.json) и проверка совместимости с бэкендом.

Главная проверка — диапазон и шаг int8 на выходе.
Соглашение о шкалах (выведено из паспортов наших моделей, в документации не описано):
  * вход:  q = x * scale       (images: scale 127 -> диапазон [0, 1]);
  * выход: x = q * scale       (output0: scale ~5 -> ±638 = координаты до 640;
                                головы: scale ~0.13 -> ±16 = реальный диапазон логитов).
Если в .tpu вошёл хвост Detect (выход (1, 25200, 85)), координаты и вероятности
делят одну шкалу на строку: шаг ~5 px нормален для рамок, но вероятности 0..1
округляются в 0 — детекций нет. Поэтому для YOLOv5s граф режут до трёх свёрток
головы (глава 6, сноска 5 документации), а хвост считает бэкенд на CPU.
"""
from __future__ import annotations

import json
import zipfile
from dataclasses import dataclass, field
from typing import Dict, List, Tuple


@dataclass
class TensorInfo:
    name: str
    shape: Tuple[int, ...]
    dtype: str
    tpu_dtype: str
    max_abs: float               # максимум по модулю после деквантования (127 / min scale)


@dataclass
class TpuModelInfo:
    path: str
    inputs: List[TensorInfo] = field(default_factory=list)
    outputs: List[TensorInfo] = field(default_factory=list)
    kind: str = "unknown"         # decoded | raw_heads | unknown
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        t = lambda x: {"name": x.name, "shape": list(x.shape), "dtype": x.dtype, "tpu_dtype": x.tpu_dtype,
                       "max_abs": round(x.max_abs, 2)}
        return {"path": self.path, "kind": self.kind, "inputs": [t(i) for i in self.inputs],
                "outputs": [t(o) for o in self.outputs], "warnings": self.warnings}


def _tensors(section: Dict, is_output: bool) -> List[TensorInfo]:
    out = []
    for group in section.values():                 # {"1": {"images": {...}}}
        for name, v in group.items():
            scales = [abs(x) for x in (v.get("scales") or [1.0])]
            qmax = 127.0 if v.get("tpu_dtype", "int8") == "int8" else 32767.0
            if not v.get("tpu_dtype", "").startswith("int"):
                max_abs = float("inf")
            elif is_output:                        # x = q * scale
                max_abs = qmax * max(min(scales), 1e-12)
            else:                                  # q = x * scale
                max_abs = qmax / max(min(scales), 1e-12)
            out.append(TensorInfo(name, tuple(v["user_shape"]), v.get("user_dtype", "?"), v.get("tpu_dtype", "?"), max_abs))
    return out


def read_tpu_info(path: str, input_size: int = 640, num_classes: int = 80) -> TpuModelInfo:
    with zipfile.ZipFile(path) as z:
        meta = json.loads(z.read("metadata.json"))
    info = TpuModelInfo(path, _tensors(meta["inputs"], False), _tensors(meta["outputs"], True))
    no = 5 + num_classes

    for i in info.inputs:
        if len(i.shape) != 4 or i.shape[1] != 3 or i.shape[2] != input_size:
            info.warnings.append(f"вход {i.name}{list(i.shape)} не совпадает с контрактом [1, 3, {input_size}, {input_size}]")
        if i.max_abs < 0.99:
            info.warnings.append(f"вход {i.name} квантован до {i.max_abs:.2f}, а пиксели нормализованы в [0, 1]")

    decoded = [o for o in info.outputs if len(o.shape) == 3 and o.shape[-1] == no]
    heads = [o for o in info.outputs if len(o.shape) in (4, 5) and 3 * no in o.shape or (len(o.shape) == 5 and o.shape[-1] == no)]
    if decoded:
        info.kind = "decoded"
        o = decoded[0]
        step = o.max_abs / 127.0
        if o.max_abs < input_size * 0.9:
            info.warnings.append(
                f"выход {o.name}{list(o.shape)} уже декодирован (в .tpu вошёл хвост Detect), "
                f"int8 вмещает только ±{o.max_abs:.1f}, а координаты рамок доходят до {input_size}: рамки обрежутся.")
        if step > 0.05:
            info.warnings.append(
                f"выход {o.name}{list(o.shape)} уже декодирован (в .tpu вошёл хвост Detect): координаты и "
                f"вероятности делят одну шкалу, шаг {step:.2f}. Вероятности 0..1 округлятся до нуля — "
                f"детекций не будет. Нужно обрезать граф до трёх свёрток головы (см. README, «Модель для TPU»).")
    elif len(heads) == 3:
        info.kind = "raw_heads"
        for o in heads:
            step = o.max_abs / 127.0
            # Реальные логиты голов YOLOv5s примерно в [-16, 8]
            if o.max_abs < 8:
                info.warnings.append(f"голова {o.name}: int8 вмещает только ±{o.max_abs:.1f}, "
                                     f"логиты обрежутся — уверенность и рамки исказятся. Проверьте калибровку.")
            elif step > 0.5:
                info.warnings.append(f"голова {o.name}: int8 рассчитан на ±{o.max_abs:.0f} (шаг {step:.1f}) при реальных "
                                     f"логитах примерно в [-16, 8] — уверенность схлопнется. Проверьте калибровку.")
    else:
        info.warnings.append(f"неожиданные выходы: {[ (o.name, list(o.shape)) for o in info.outputs ]}")
    return info


if __name__ == "__main__":
    import sys

    res = read_tpu_info(sys.argv[1])
    print(json.dumps(res.to_dict(), ensure_ascii=False, indent=2))
    sys.exit(1 if res.warnings else 0)
