"""Абстрактный движок инференса.

Бэкенд работает только с InferenceEngine.detect(frame) -> DetectionResult.
Конкретный бэкенд (ONNX Runtime локально, LinQ TPU через pytpu, удалённый
TPU-воркер по HTTP) подменяется одной переменной окружения ENGINE.
"""
from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Sequence

import numpy as np

from .postprocess import decode_outputs
from .preprocess import LetterboxMeta, preprocess


@dataclass
class Detection:
    x1: float
    y1: float
    x2: float
    y2: float
    conf: float
    cls: int
    label: str = ""

    @property
    def xyxy(self) -> np.ndarray:
        return np.array([self.x1, self.y1, self.x2, self.y2], dtype=np.float32)

    @property
    def w(self) -> float:
        return self.x2 - self.x1

    @property
    def h(self) -> float:
        return self.y2 - self.y1


@dataclass
class Timings:
    preprocess_ms: float = 0.0
    inference_ms: float = 0.0
    postprocess_ms: float = 0.0

    @property
    def total_ms(self) -> float:
        return self.preprocess_ms + self.inference_ms + self.postprocess_ms


@dataclass
class DetectionResult:
    detections: List[Detection] = field(default_factory=list)
    timings: Timings = field(default_factory=Timings)


class InferenceEngine(ABC):
    """Шаблон: preprocess (CPU) -> infer (ONNX/TPU) -> postprocess (CPU, NMS).

    Наследники реализуют только `_infer` — запуск сети на готовом тензоре.
    """

    name: str = "abstract"

    def __init__(
        self,
        labels: Sequence[str],
        input_name: str = "images",
        input_size: int = 640,
        conf_thres: float = 0.35,
        iou_thres: float = 0.45,
        keep_classes: Sequence[int] | None = None,
    ) -> None:
        self.labels = list(labels)
        self.input_name = input_name
        self.input_size = input_size
        self.conf_thres = conf_thres
        self.iou_thres = iou_thres
        self.keep_classes = list(keep_classes) if keep_classes else None
        self.warnings: List[str] = []   # проблемы модели, видны в /api/health

    # --- обязательная часть для наследников -------------------------------
    @abstractmethod
    def _infer(self, inputs: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        """Принимает {"images": float32 (1,3,640,640)}, возвращает сырые выходы."""

    def close(self) -> None:  # pragma: no cover - переопределяется при нужде
        pass

    # --- общая логика ------------------------------------------------------
    def detect(self, frame_bgr: np.ndarray) -> DetectionResult:
        t0 = time.perf_counter()
        tensor, meta = preprocess(frame_bgr, self.input_size)
        t1 = time.perf_counter()
        raw = self._infer({self.input_name: tensor})
        t2 = time.perf_counter()
        dets = self.postprocess(raw, meta)
        t3 = time.perf_counter()
        return DetectionResult(
            detections=dets,
            timings=Timings((t1 - t0) * 1e3, (t2 - t1) * 1e3, (t3 - t2) * 1e3),
        )

    def postprocess(self, raw: Dict[str, np.ndarray], meta: LetterboxMeta) -> List[Detection]:
        boxes = decode_outputs(
            raw,
            num_classes=len(self.labels),
            conf_thres=self.conf_thres,
            iou_thres=self.iou_thres,
            keep_classes=self.keep_classes,
        )
        boxes = meta.unletterbox(boxes)
        return [
            Detection(float(b[0]), float(b[1]), float(b[2]), float(b[3]), float(b[4]),
                      int(b[5]), self.labels[int(b[5])] if int(b[5]) < len(self.labels) else str(int(b[5])))
            for b in boxes
        ]

    def __enter__(self) -> "InferenceEngine":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
