"""Конкретные движки: ONNX Runtime, LinQ TPU (pytpu или облако хакатона), эмуляция TPU, удалённый TPU-воркер."""
from __future__ import annotations

import io
import json
import logging
import os
import threading
import time
import uuid
from contextlib import ExitStack
from typing import Dict

import numpy as np

from .base import InferenceEngine


log = logging.getLogger(__name__)


def _check_tpu(program_path: str, engine: InferenceEngine):
    """Читает паспорт .tpu, подхватывает имя входа и громко сообщает о проблемах."""
    from .tpu_meta import read_tpu_info

    info = read_tpu_info(program_path, engine.input_size, len(engine.labels))
    if info.inputs:
        engine.input_name = info.inputs[0].name
    engine.warnings = list(info.warnings)
    log.info("tpu model %s: kind=%s inputs=%s outputs=%s", program_path, info.kind,
             [(i.name, i.shape) for i in info.inputs], [(o.name, o.shape) for o in info.outputs])
    for w in info.warnings:
        log.error("TPU MODEL PROBLEM: %s", w)
    return info


class OnnxEngine(InferenceEngine):
    """Локальная отладка на CPU/GPU, пока Участник 1 собирает .tpu."""

    name = "onnxruntime"

    def __init__(self, model_path: str, **kw) -> None:
        import onnxruntime as ort

        self.session = ort.InferenceSession(
            model_path, providers=["CUDAExecutionProvider", "CPUExecutionProvider"]
            if "CUDAExecutionProvider" in ort.get_available_providers() else ["CPUExecutionProvider"],
        )
        inp = self.session.get_inputs()[0]
        kw.setdefault("input_name", inp.name)
        super().__init__(**kw)
        self._dtype = np.float16 if "float16" in inp.type else np.float32
        self._outputs = [o.name for o in self.session.get_outputs()]
        self._lock = threading.Lock()

    def _infer(self, inputs: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        feed = {k: v.astype(self._dtype) for k, v in inputs.items()}
        with self._lock:
            res = self.session.run(self._outputs, feed)
        return dict(zip(self._outputs, res))


class TpuEngine(InferenceEngine):
    """LinQ TPU через pytpu (запускать на машине с /dev/tpu*).

    Программа загружается один раз и держится открытой; вызовы sync()
    сериализуются локом — один ускоритель обслуживает все камеры по очереди.
    """

    name = "linq_tpu"

    def __init__(self, program_path: str, device_index: int = 0, **kw) -> None:
        super().__init__(**kw)
        self.model_info = _check_tpu(program_path, self)
        import pytpu as tpu  # доступен только на сервере хакатона

        devices = tpu.Device.list_devices()
        if not devices:
            raise RuntimeError("TPU not found, check `ls /dev/tpu*`")
        self._stack = ExitStack()
        dev = self._stack.enter_context(tpu.Device.open(devices[device_index]))
        prog = self._stack.enter_context(dev.load(program_path))
        self._inference = self._stack.enter_context(prog.inference())
        self._lock = threading.Lock()

    def _infer(self, inputs: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        with self._lock:
            return self._inference.sync(inputs)

    def close(self) -> None:
        self._stack.close()


class TpuSimEngine(OnnxEngine):
    """Эмуляция TPU на обычном компьютере: ONNX + квантование выходов шкалами из .tpu.

    Работает, если выходы ONNX совпадают по форме с выходами .tpu (полный граф
    с output0, или обрезанный ONNX с тремя головами). Нужен, чтобы до сервера
    увидеть, как int8 на выходе повлияет на детекции.
    """

    name = "linq_tpu_sim"

    def __init__(self, model_path: str, program_path: str, **kw) -> None:
        import json
        import zipfile

        super().__init__(model_path, **kw)
        self.model_info = _check_tpu(program_path, self)
        with zipfile.ZipFile(program_path) as z:
            meta = json.loads(z.read("metadata.json"))
        self._qparams = {}
        for group in meta["outputs"].values():
            for name, v in group.items():
                scales = np.asarray(v["scales"], np.float32).reshape(v.get("scale_shape") or [1])
                zp = np.asarray(v.get("zero_points") or [0.0], np.float32).reshape(scales.shape)
                self._qparams[tuple(v["user_shape"])] = (scales, zp)

    def _infer(self, inputs):
        out = super()._infer(inputs)
        res = {}
        for k, v in out.items():
            qp = self._qparams.get(tuple(v.shape))
            if qp is None:
                res[k] = v
                continue
            s, zp = qp                                     # выход: x = q * scale
            q = np.clip(np.round(v.astype(np.float32) / s + zp), -128, 127)
            res[k] = (q - zp) * s
        return res


class RemoteTpuEngine(InferenceEngine):
    """Бэкенд крутится у нас, TPU — на сервере LinQ (tpu_worker/server.py).

    Тензор уходит как .npy, ответ приходит как .npz со всеми выходами.
    Через прокси JupyterHub (https://hackathon.lin-q.ru/user/<LOGIN>/proxy/8500) нужен
    API-токен Jupyter: REMOTE_TOKEN (заголовок «Authorization: token …»).
    """

    name = "linq_tpu_remote"

    def __init__(self, url: str, timeout: float = 5.0, token: str = "", **kw) -> None:
        super().__init__(**kw)
        import requests

        self._session = requests.Session()
        if token:
            self._session.headers["Authorization"] = f"token {token}"
        self._url = url.rstrip("/") + "/infer"
        self._timeout = timeout

    def _infer(self, inputs: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        buf = io.BytesIO()
        np.save(buf, inputs[self.input_name], allow_pickle=False)
        r = self._session.post(self._url, data=buf.getvalue(), timeout=self._timeout,
                               headers={"Content-Type": "application/octet-stream",
                                        "X-Input-Name": self.input_name})
        if r.status_code in (401, 403):
            raise RuntimeError("TPU-воркер отказал в доступе: проверьте REMOTE_TOKEN (токен JupyterHub)")
        r.raise_for_status()
        if not r.content.startswith(b"PK"):
            raise RuntimeError("вместо ответа воркера пришла страница (скорее всего, вход в Jupyter): нужен REMOTE_TOKEN")
        with np.load(io.BytesIO(r.content), allow_pickle=False) as z:
            return {k: z[k] for k in z.files}


class CloudTpuEngine(InferenceEngine):
    """LinQ TPU через облако хакатона (брокер RabbitMQ + пакет tpu_pycloud_format).

    Так ускоритель вызывается из Jupyter на hackathon.lin-q.ru: кадр уходит в очередь
    ``input`` обменника ``tpu.direct``, воркер облака запускает на TPU программу .tpu
    из общей папки ``/auto/cache/<LOGIN>/`` и присылает выходы в нашу очередь ответов.

    У каждого потока (камеры) своё соединение: камеры не ждут друг друга, если в облаке
    несколько воркеров. Разрыв соединения (брокер закрыл простаивающее) лечится
    переподключением и повтором запроса.
    """

    name = "linq_tpu_cloud"

    def __init__(self, program_uri_path: str, local_program: str, host: str, port: int = 5672,
                 user: str = "guest", password: str = "guest", timeout: float = 15.0,
                 exchange: str = "tpu.direct", input_queue: str = "input", **kw) -> None:
        super().__init__(**kw)
        import pika  # noqa: F401  (есть в Jupyter LinQ; иначе: pip install pika)
        import tpu_pycloud_format  # noqa: F401  (~/work/packages/tpu_pycloud_format-*.whl)

        if os.path.isfile(local_program):
            self.model_info = _check_tpu(local_program, self)
        self._uri = f"file://{program_uri_path}?raw=False"
        self._host, self._port, self._cred = host, int(port), (user, password)
        self._timeout = float(timeout)
        self._exchange, self._input_queue = exchange, input_queue
        self._local = threading.local()
        self._all: list = []
        self._all_lock = threading.Lock()
        log.info("LinQ cloud: broker %s:%s, program %s", host, port, self._uri)
        # пробный кадр: сразу понятная ошибка, если облако недоступно или не принимает программу
        t0 = time.perf_counter()
        out = self._infer({self.input_name: np.zeros((1, 3, self.input_size, self.input_size), np.float32)})
        log.info("LinQ cloud: ответ за %.0f мс, выходы %s", (time.perf_counter() - t0) * 1e3,
                 [(k, tuple(v.shape)) for k, v in out.items()])

    # --- соединение на поток ---------------------------------------------------
    def _connect(self):
        import pika

        conn = pika.BlockingConnection(pika.ConnectionParameters(
            self._host, self._port, credentials=pika.PlainCredentials(*self._cred),
            heartbeat=60, blocked_connection_timeout=30, socket_timeout=10,
            connection_attempts=2, retry_delay=1))
        ch = conn.channel()
        reply = f"lsv_{uuid.uuid4().hex[:12]}"
        ch.queue_declare(queue=reply, exclusive=True, auto_delete=True)
        ch.queue_bind(exchange=self._exchange, queue=reply, routing_key=reply)
        st = self._local
        st.conn, st.ch, st.reply, st.answers = conn, ch, reply, {}

        def on_answer(_ch, _method, props, body, answers=st.answers):
            from tpu_pycloud_format import MESSAGE_ID_ATTR_NAME
            answers[(props.headers or {}).get(MESSAGE_ID_ATTR_NAME)] = body

        ch.basic_consume(queue=reply, on_message_callback=on_answer, auto_ack=True)
        with self._all_lock:
            self._all.append(conn)

    def _drop(self) -> None:
        conn = getattr(self._local, "conn", None)
        self._local.conn = None
        if conn is not None:
            with self._all_lock:
                if conn in self._all:
                    self._all.remove(conn)
            try:
                conn.close()
            except Exception:
                pass

    def _call(self, inputs: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        import pika
        from tpu_pycloud_format import (MESSAGE_ID_ATTR_NAME, RESPONSE_ROUTING_KEYS_ATTR_NAME,
                                        TARGET_URI_ATTR_NAME, PyTask, deserialize, serialize)

        if getattr(self._local, "conn", None) is None:
            self._connect()
        st = self._local
        st.answers.clear()                     # опоздавшие ответы на прошлые (отменённые) кадры
        task_id = uuid.uuid4().hex
        tensors = {k: np.ascontiguousarray(v, dtype=np.float32) for k, v in inputs.items()}
        st.ch.basic_publish(
            exchange=self._exchange, routing_key=self._input_queue,
            body=serialize(PyTask(tensors)),
            properties=pika.BasicProperties(headers={
                TARGET_URI_ATTR_NAME: self._uri,
                RESPONSE_ROUTING_KEYS_ATTR_NAME: json.dumps([st.reply]),
                MESSAGE_ID_ATTR_NAME: task_id,
            }))
        deadline = time.monotonic() + self._timeout
        while task_id not in st.answers:
            if time.monotonic() > deadline:
                raise TimeoutError(
                    f"облако LinQ не ответило за {self._timeout:.0f} с (брокер {self._host}:{self._port}). "
                    "Проверьте, что программа запущена в Jupyter хакатона и .tpu лежит в /auto/cache/<LOGIN>/")
            st.conn.process_data_events(time_limit=0.005)
        data, _meta, worker = deserialize(st.answers.pop(task_id))
        if not data or not isinstance(data, dict):
            raise RuntimeError(f"воркер LinQ вернул ошибку (status_code={worker.get('status_code')}): "
                               f"{worker.get('error_message') or 'нет данных'}")
        return {k: np.asarray(v, dtype=np.float32) for k, v in data.items()}

    def _infer(self, inputs: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        import pika

        try:
            return self._call(inputs)
        except TimeoutError:                   # (до OSError: TimeoutError — его подкласс)
            self._drop()                       # очередь ответов могла «залипнуть» — начнём с чистой
            raise
        except (pika.exceptions.AMQPError, ConnectionError, OSError) as e:
            # брокер закрыл простаивавшее соединение или сеть моргнула — один повтор
            log.warning("LinQ cloud: соединение потеряно (%s), переподключаюсь", e.__class__.__name__)
            self._drop()
            return self._call(inputs)

    def close(self) -> None:
        with self._all_lock:
            conns, self._all = self._all, []
        for c in conns:
            try:
                c.close()
            except Exception:
                pass
