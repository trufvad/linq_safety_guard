import glob
import logging
import os

from .base import Detection, DetectionResult, InferenceEngine, Timings
from .engines import CloudTpuEngine, OnnxEngine, RemoteTpuEngine, TpuEngine, TpuSimEngine

log = logging.getLogger(__name__)


def tpu_available(cfg) -> tuple[bool, str]:
    """Есть ли физический LinQ TPU: модуль pytpu, устройство /dev/tpu* и файл .tpu."""
    try:
        import pytpu  # noqa: F401
    except Exception:  # noqa: BLE001
        return False, "модуль pytpu не установлен"
    if not glob.glob("/dev/tpu*"):
        return False, "устройство /dev/tpu* не найдено"
    if not os.path.isfile(cfg.tpu_program):
        return False, f"нет файла модели {cfg.tpu_program}"
    return True, "ok"


def _login() -> str:
    import getpass
    return os.getenv("JUPYTERHUB_USER") or os.getenv("LOGIN") or os.getenv("USER") or getpass.getuser()


def cloud_available(cfg) -> tuple[bool, str]:
    """Облако LinQ хакатона: есть pika, tpu_pycloud_format и общая папка программ /auto/cache."""
    for mod in ("pika", "tpu_pycloud_format"):
        try:
            __import__(mod)
        except Exception:
            return False, f"нет модуля {mod}"
    if not os.path.isdir(cfg.cloud_cache_dir):
        return False, f"нет папки {cfg.cloud_cache_dir} (запуск не в Jupyter хакатона)"
    return True, "ok"


def cloud_program_path(cfg) -> str:
    """Путь к .tpu в общей папке, которую видит воркер облака; копирует туда модель из models/."""
    import shutil

    if cfg.cloud_program:
        if not os.path.isfile(cfg.cloud_program):
            raise FileNotFoundError(f"CLOUD_PROGRAM={cfg.cloud_program}: файла нет")
        return cfg.cloud_program
    folder = os.path.join(cfg.cloud_cache_dir, _login())
    dst = os.path.join(folder, os.path.basename(cfg.tpu_program))
    if not os.path.isfile(cfg.tpu_program):
        if os.path.isfile(dst):
            return dst
        raise FileNotFoundError(f"нет модели {cfg.tpu_program}")
    if not os.path.isfile(dst) or os.path.getsize(dst) != os.path.getsize(cfg.tpu_program):
        os.makedirs(folder, exist_ok=True)
        shutil.copyfile(cfg.tpu_program, dst)
        log.info("модель скопирована для облака LinQ: %s", dst)
    return dst


def _cloud_engine(cfg, common):
    return CloudTpuEngine(cloud_program_path(cfg), cfg.tpu_program, host=cfg.cloud_host, port=cfg.cloud_port,
                          user=cfg.cloud_user, password=cfg.cloud_password, timeout=cfg.cloud_timeout,
                          input_name=cfg.input_name, **common)


def create_engine(cfg) -> InferenceEngine:
    """ENGINE=auto|tpu|cloud|onnx|tpu_sim|remote — переключение без правок кода конвейера.

    auto: LinQ TPU (локальный /dev/tpu, затем облако хакатона), иначе ONNX Runtime на CPU/GPU. Ошибка при
    открытии TPU тоже приводит к откату на ONNX — проект запускается на любой машине.
    """
    common = dict(
        labels=cfg.labels, input_size=cfg.input_size,
        conf_thres=min(cfg.conf_thres, getattr(cfg, "phone_conf", cfg.conf_thres),
                       getattr(cfg, "extra_conf", cfg.conf_thres)),   # общий порог — в конвейере
        iou_thres=cfg.iou_thres, keep_classes=cfg.keep_class_ids,
    )
    kind = cfg.engine.lower()
    if kind == "auto":
        ok, reason = tpu_available(cfg)
        if ok:
            try:
                eng = TpuEngine(cfg.tpu_program, input_name=cfg.input_name, **common)
                log.info("ENGINE=auto -> LinQ TPU (%s)", cfg.tpu_program)
                return eng
            except Exception as e:  # noqa: BLE001
                log.warning("ENGINE=auto: TPU не открылся (%s), откат на ONNX", e)
        else:
            log.info("ENGINE=auto: локального TPU нет (%s)", reason)
        ok, reason = cloud_available(cfg)
        if ok:
            try:
                eng = _cloud_engine(cfg, common)
                log.info("ENGINE=auto -> LinQ TPU через облако хакатона")
                return eng
            except Exception as e:  # noqa: BLE001
                log.warning("ENGINE=auto: облако LinQ не ответило (%s), откат на ONNX", e)
        else:
            log.info("ENGINE=auto: облака LinQ нет (%s) -> ONNX Runtime", reason)
        return OnnxEngine(cfg.model_path, **common)
    if kind == "onnx":
        return OnnxEngine(cfg.model_path, **common)
    if kind == "tpu":
        return TpuEngine(cfg.tpu_program, input_name=cfg.input_name, **common)
    if kind == "cloud":
        return _cloud_engine(cfg, common)
    if kind == "tpu_sim":
        return TpuSimEngine(cfg.model_path, cfg.tpu_program, **common)
    if kind == "remote":
        return RemoteTpuEngine(cfg.remote_url, token=getattr(cfg, "remote_token", ""), input_name=cfg.input_name, **common)
    raise ValueError(f"unknown ENGINE={cfg.engine}")


__all__ = ["Detection", "DetectionResult", "InferenceEngine", "Timings", "create_engine", "tpu_available", "cloud_available", "cloud_program_path",
           "CloudTpuEngine", "OnnxEngine", "TpuEngine", "TpuSimEngine", "RemoteTpuEngine"]
