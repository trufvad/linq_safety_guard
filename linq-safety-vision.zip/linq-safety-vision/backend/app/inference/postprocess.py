"""Постпроцессинг YOLOv5 на CPU: декод голов + NMS.

LinQ TPU не исполняет хвост Detect-слоя: по главе 6 tpu_framework (сноска 5,
yolo5s) граф обрезан до трёх выходов свёрток головы
{'onnx::Shape_327', 'onnx::Shape_663', 'onnx::Shape_999'} — это сырые логиты
формы (1, 255, 80/40/20, 80/40/20) = 3 якоря x (4 bbox + 1 obj + 80 cls).
Sigmoid, сетка, якоря и NMS делаются здесь.

Поддерживаемые формы выходов (определяются автоматически):
  * (1, N, 5+nc)           — полный ONNX с декодированным выходом (локальная отладка)
  * (1, 3*(5+nc), H, W)    — сырые головы, NCHW (TPU / обрезанный ONNX)
  * (1, H, W, 3*(5+nc))    — то же в NHWC (TF-конвертер TPU может отдать так)
  * (1, 3, H, W, 5+nc)     — после reshape/permute
"""
from __future__ import annotations

from typing import Dict, List, Sequence

import numpy as np

# Якоря YOLOv5s (P3/8, P4/16, P5/32) в пикселях входа 640
ANCHORS = np.array(
    [[10, 13, 16, 30, 33, 23], [30, 61, 62, 45, 59, 119], [116, 90, 156, 198, 373, 326]],
    dtype=np.float32,
).reshape(3, 3, 2)
STRIDES = (8, 16, 32)


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -50, 50)))


def _head_to_5d(t: np.ndarray, no: int) -> np.ndarray:
    """Любая форма головы -> (1, 3, H, W, no)."""
    t = np.asarray(t, dtype=np.float32)
    if t.ndim == 5:
        return t
    if t.ndim != 4:
        raise ValueError(f"unexpected head shape {t.shape}")
    if t.shape[1] == 3 * no:                      # NCHW
        b, _, h, w = t.shape
        return t.reshape(b, 3, no, h, w).transpose(0, 1, 3, 4, 2)
    if t.shape[-1] == 3 * no:                     # NHWC
        b, h, w, _ = t.shape
        return t.reshape(b, h, w, 3, no).transpose(0, 3, 1, 2, 4)
    raise ValueError(f"cannot interpret head shape {t.shape} for no={no}")


def decode_heads(heads: Sequence[np.ndarray], num_classes: int) -> np.ndarray:
    """Сырые логиты трёх голов -> (N, 5+nc) [cx,cy,w,h,obj,cls...] в пикселях 640."""
    no = 5 + num_classes
    heads5 = [_head_to_5d(h, no) for h in heads]
    heads5.sort(key=lambda h: -h.shape[2])  # 80x80 -> stride 8 первым
    out = []
    for i, h in enumerate(heads5):
        _, na, ny, nx, _ = h.shape
        y = _sigmoid(h[0])                                    # (3, ny, nx, no)
        gy, gx = np.meshgrid(np.arange(ny), np.arange(nx), indexing="ij")
        grid = np.stack((gx, gy), -1)[None].astype(np.float32)  # (1, ny, nx, 2)
        xy = (y[..., 0:2] * 2 - 0.5 + grid) * STRIDES[i]
        wh = (y[..., 2:4] * 2) ** 2 * ANCHORS[i][:, None, None, :]
        out.append(np.concatenate((xy, wh, y[..., 4:]), -1).reshape(-1, no))
    return np.concatenate(out, 0)


def nms(boxes: np.ndarray, scores: np.ndarray, iou_thres: float) -> List[int]:
    order = scores.argsort()[::-1]
    areas = (boxes[:, 2] - boxes[:, 0]) * (boxes[:, 3] - boxes[:, 1])
    keep: List[int] = []
    while order.size:
        i = int(order[0])
        keep.append(i)
        if order.size == 1:
            break
        rest = order[1:]
        xx1 = np.maximum(boxes[i, 0], boxes[rest, 0])
        yy1 = np.maximum(boxes[i, 1], boxes[rest, 1])
        xx2 = np.minimum(boxes[i, 2], boxes[rest, 2])
        yy2 = np.minimum(boxes[i, 3], boxes[rest, 3])
        inter = np.clip(xx2 - xx1, 0, None) * np.clip(yy2 - yy1, 0, None)
        iou = inter / (areas[i] + areas[rest] - inter + 1e-9)
        order = rest[iou <= iou_thres]
    return keep


def decode_outputs(
    raw: Dict[str, np.ndarray],
    num_classes: int = 80,
    conf_thres: float = 0.35,
    iou_thres: float = 0.45,
    keep_classes: Sequence[int] | None = None,
    max_det: int = 300,
) -> np.ndarray:
    """Сырые выходы сети -> (M, 6) [x1,y1,x2,y2,conf,cls] в пикселях входа 640."""
    no = 5 + num_classes
    arrays = [np.asarray(v) for v in raw.values()]
    decoded = [a for a in arrays if a.ndim == 3 and a.shape[-1] == no]
    if decoded:
        pred = decoded[0][0].astype(np.float32)
    else:
        pred = decode_heads([a for a in arrays if a.ndim in (4, 5)], num_classes)

    pred = pred[pred[:, 4] > conf_thres * 0.5]            # быстрый отсев по objectness
    if not len(pred):
        return np.zeros((0, 6), np.float32)
    cls_scores = pred[:, 5:] * pred[:, 4:5]
    cls = cls_scores.argmax(1)
    conf = cls_scores[np.arange(len(cls)), cls]
    m = conf > conf_thres
    if keep_classes is not None:
        m &= np.isin(cls, keep_classes)
    pred, cls, conf = pred[m], cls[m], conf[m]
    if not len(pred):
        return np.zeros((0, 6), np.float32)

    xyxy = np.empty((len(pred), 4), np.float32)
    xyxy[:, 0] = pred[:, 0] - pred[:, 2] / 2
    xyxy[:, 1] = pred[:, 1] - pred[:, 3] / 2
    xyxy[:, 2] = pred[:, 0] + pred[:, 2] / 2
    xyxy[:, 3] = pred[:, 1] + pred[:, 3] / 2

    offset = cls[:, None].astype(np.float32) * 4096.0     # NMS по классам одним вызовом
    keep = nms(xyxy + offset, conf, iou_thres)[:max_det]
    return np.concatenate((xyxy[keep], conf[keep, None], cls[keep, None].astype(np.float32)), 1)
