"""Препроцессинг по контракту Участника 1.

Вход сети: {"images": float32 (1, 3, 640, 640)}, RGB, значения /255.0 -> [0, 1].
Кадр вписывается с сохранением пропорций (letterbox, серый паддинг 114) —
так обучался YOLOv5. ВАЖНО: калибровка квантования (Участник 1) должна
использовать ровно эту функцию, иначе пороги int8 разъедутся с реальными кадрами.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import cv2
import numpy as np


@dataclass
class LetterboxMeta:
    ratio: float
    pad_x: float
    pad_y: float
    orig_w: int
    orig_h: int

    def unletterbox(self, boxes: np.ndarray) -> np.ndarray:
        """boxes (N, 6) [x1,y1,x2,y2,conf,cls] в координатах 640 -> исходный кадр."""
        if len(boxes) == 0:
            return boxes
        out = boxes.copy()
        out[:, [0, 2]] = (out[:, [0, 2]] - self.pad_x) / self.ratio
        out[:, [1, 3]] = (out[:, [1, 3]] - self.pad_y) / self.ratio
        out[:, [0, 2]] = out[:, [0, 2]].clip(0, self.orig_w)
        out[:, [1, 3]] = out[:, [1, 3]].clip(0, self.orig_h)
        return out


def letterbox(img: np.ndarray, size: int = 640, color=(114, 114, 114)) -> Tuple[np.ndarray, LetterboxMeta]:
    h, w = img.shape[:2]
    r = min(size / h, size / w)
    nw, nh = int(round(w * r)), int(round(h * r))
    if (nw, nh) != (w, h):
        img = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_LINEAR)
    pad_x, pad_y = (size - nw) / 2, (size - nh) / 2
    top, bottom = int(round(pad_y - 0.1)), int(round(pad_y + 0.1))
    left, right = int(round(pad_x - 0.1)), int(round(pad_x + 0.1))
    img = cv2.copyMakeBorder(img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)
    return img, LetterboxMeta(r, left, top, w, h)


def preprocess(frame_bgr: np.ndarray, size: int = 640) -> Tuple[np.ndarray, LetterboxMeta]:
    img, meta = letterbox(frame_bgr, size)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    tensor = img.transpose(2, 0, 1)[None].astype(np.float32) / 255.0  # (1,3,640,640)
    return np.ascontiguousarray(tensor), meta
