"""SQLite-журнал событий (доказательная база) + хранение конфигов камер."""
from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    id TEXT PRIMARY KEY,
    camera_id TEXT NOT NULL,
    camera_name TEXT,
    area TEXT,
    zone_id TEXT,
    zone_name TEXT,
    violation_type TEXT NOT NULL,
    title TEXT,
    severity TEXT,
    track_id INTEGER,
    confidence REAL,
    bbox TEXT,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    status TEXT NOT NULL DEFAULT 'new',
    comment TEXT,
    operator TEXT,
    details TEXT
);
CREATE INDEX IF NOT EXISTS ix_events_started ON events(started_at);
CREATE INDEX IF NOT EXISTS ix_events_cam ON events(camera_id);
CREATE INDEX IF NOT EXISTS ix_events_type ON events(violation_type);
CREATE TABLE IF NOT EXISTS cameras (id TEXT PRIMARY KEY, config TEXT NOT NULL);
"""

JSON_COLS = ("bbox", "details")


class Database:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(SCHEMA)
        self._lock = threading.Lock()

    # --- события ---------------------------------------------------------
    def insert_event(self, ev: Dict[str, Any]) -> None:
        row = {k: (json.dumps(v, ensure_ascii=False) if k in JSON_COLS else v) for k, v in ev.items()
               if k != "snapshot_url"}
        cols = ",".join(row)
        with self._lock, self._conn:
            self._conn.execute(f"INSERT INTO events ({cols}) VALUES ({','.join('?' * len(row))})", list(row.values()))

    def update_event(self, event_id: str, **fields) -> Optional[Dict[str, Any]]:
        fields = {k: v for k, v in fields.items() if v is not None}
        if fields:
            sets = ",".join(f"{k}=?" for k in fields)
            with self._lock, self._conn:
                self._conn.execute(f"UPDATE events SET {sets} WHERE id=?", [*fields.values(), event_id])
        return self.get_event(event_id)

    def get_event(self, event_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            r = self._conn.execute("SELECT * FROM events WHERE id=?", (event_id,)).fetchone()
        return self._row(r) if r else None

    def list_events(self, *, camera_id=None, violation_type=None, status=None, area=None, zone_id=None,
                    date_from: Optional[datetime] = None, date_to: Optional[datetime] = None,
                    limit: int = 100, offset: int = 0) -> Dict[str, Any]:
        where, args = self._where(camera_id, violation_type, status, area, zone_id, date_from, date_to)
        with self._lock:
            total = self._conn.execute(f"SELECT COUNT(*) FROM events {where}", args).fetchone()[0]
            rows = self._conn.execute(f"SELECT * FROM events {where} ORDER BY started_at DESC LIMIT ? OFFSET ?",
                                      [*args, limit, offset]).fetchall()
        return {"total": total, "items": [self._row(r) for r in rows]}

    def stats(self, date_from=None, date_to=None, camera_id=None, area=None) -> Dict[str, Any]:
        where, args = self._where(camera_id, None, None, area, None, date_from, date_to)

        def q(sql):
            with self._lock:
                return [dict(r) for r in self._conn.execute(sql, args).fetchall()]

        # Час и день недели берём из локального времени строки (strftime перевёл бы в UTC)
        by_hour = q(f"SELECT CAST(strftime('%w', substr(started_at, 1, 10)) AS INT) AS dow, "
                    f"CAST(substr(started_at, 12, 2) AS INT) AS hour, COUNT(*) AS n FROM events {where} GROUP BY dow, hour")
        heat = [[0] * 24 for _ in range(7)]          # [Пн..Вс][0..23]
        for r in by_hour:
            heat[(r["dow"] + 6) % 7][r["hour"]] = r["n"]
        shifts = {"night (00-08)": 0, "day (08-16)": 0, "evening (16-24)": 0}
        for r in by_hour:
            shifts[list(shifts)[r["hour"] // 8]] += r["n"]
        return {
            "total": sum(r["n"] for r in by_hour),
            "by_type": q(f"SELECT violation_type, title, COUNT(*) AS n FROM events {where} GROUP BY violation_type ORDER BY n DESC"),
            "by_camera": q(f"SELECT camera_id, camera_name, COUNT(*) AS n FROM events {where} GROUP BY camera_id ORDER BY n DESC"),
            "by_area": q(f"SELECT area, COUNT(*) AS n FROM events {where} GROUP BY area ORDER BY n DESC"),
            "by_status": q(f"SELECT status, COUNT(*) AS n FROM events {where} GROUP BY status"),
            "by_day": q(f"SELECT substr(started_at, 1, 10) AS day, COUNT(*) AS n FROM events {where} GROUP BY day ORDER BY day"),
            "heatmap": heat,
            "by_shift": [{"shift": k, "n": v} for k, v in shifts.items()],
        }

    @staticmethod
    def _where(camera_id, violation_type, status, area, zone_id, date_from, date_to):
        cond, args = [], []
        for col, val in (("camera_id", camera_id), ("violation_type", violation_type), ("status", status),
                         ("area", area), ("zone_id", zone_id)):
            if val:
                vals = val.split(",") if isinstance(val, str) else list(val)
                cond.append(f"{col} IN ({','.join('?' * len(vals))})")
                args += vals
        if date_from:
            cond.append("started_at >= ?"); args.append(date_from.isoformat())
        if date_to:
            cond.append("started_at <= ?"); args.append(date_to.isoformat())
        return ("WHERE " + " AND ".join(cond)) if cond else "", args

    @staticmethod
    def _row(r: sqlite3.Row) -> Dict[str, Any]:
        d = dict(r)
        for k in JSON_COLS:
            d[k] = json.loads(d[k]) if d.get(k) else ({} if k == "details" else [])
        d["snapshot_url"] = f"/api/events/{d['id']}/snapshot.jpg"
        d.pop("operator", None)
        return d

    def delete_events(self, camera_ids: Optional[List[str]] = None) -> List[str]:
        """Удалить события (все или по камерам). Возвращает id удалённых — для чистки снимков."""
        with self._lock, self._conn:
            if camera_ids is None:
                ids = [r[0] for r in self._conn.execute("SELECT id FROM events")]
                self._conn.execute("DELETE FROM events")
            else:
                if not camera_ids:
                    return []
                q = ",".join("?" * len(camera_ids))
                ids = [r[0] for r in self._conn.execute(f"SELECT id FROM events WHERE camera_id IN ({q})", camera_ids)]
                self._conn.execute(f"DELETE FROM events WHERE camera_id IN ({q})", camera_ids)
        return ids

    # --- камеры ----------------------------------------------------------
    def save_camera(self, cam_id: str, cfg_json: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("INSERT OR REPLACE INTO cameras (id, config) VALUES (?, ?)", (cam_id, cfg_json))

    def delete_camera(self, cam_id: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("DELETE FROM cameras WHERE id=?", (cam_id,))

    def load_cameras(self) -> List[str]:
        with self._lock:
            return [r[0] for r in self._conn.execute("SELECT config FROM cameras").fetchall()]
