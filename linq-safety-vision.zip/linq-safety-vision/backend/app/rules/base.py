"""Плагинная архитектура правил.

Новое правило = новый файл в app/rules/ с классом-наследником BaseRule,
помеченным @register_rule. Конвейер правится не нужно: реестр подхватывает
все модули пакета автоматически, а включение/параметры/расписание задаются
в конфиге камеры (rules: {type: {enabled, params, schedule}}) из UI.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence, Tuple, Type

import cv2
import numpy as np

from ..schemas import CameraConfig, Zone
from ..tracking.bytetrack import Track


@dataclass
class FrameContext:
    camera: CameraConfig
    t: float                      # время потока, сек
    now: datetime                 # стенное время (для расписаний)
    frame_w: int
    frame_h: int
    persons: List[Track]
    machines: List[Track]
    others: List[Track]           # СИЗ и прочие классы
    image: Optional[np.ndarray] = None   # кадр BGR (для правил, которым нужен цвет, например каска)

    def zone_polygon_px(self, zone: Zone) -> np.ndarray:
        return (np.array(zone.polygon, np.float32) * [self.frame_w, self.frame_h]).astype(np.float32)

    def active_zones(self, kinds: Sequence[str]) -> List[Zone]:
        return [z for z in self.camera.zones
                if z.enabled and z.kind in kinds and (z.schedule is None or z.schedule.is_active(self.now))]

    def point_in_zone(self, pt: Tuple[float, float], zone: Zone) -> bool:
        return cv2.pointPolygonTest(self.zone_polygon_px(zone), (float(pt[0]), float(pt[1])), False) >= 0


@dataclass
class RuleHit:
    track: Track
    zone: Optional[Zone] = None
    details: Dict[str, Any] = field(default_factory=dict)


class BaseRule(ABC):
    type: str = ""                         # машинное имя = violation_type в событиях
    title: str = ""                        # для UI и уведомлений
    severity: str = "warning"              # critical | warning | info
    default_params: Dict[str, Any] = {}
    confirm_seconds: float = 2.0           # таймер подтверждения (фильтр одиночных кадров)
    requires_labels: Sequence[str] = ()    # каких классов модели правило требует

    def __init__(self, params: Optional[Dict[str, Any]] = None):
        self.params = {**self.default_params, **(params or {})}
        self.confirm_seconds = float(self.params.get("confirm_seconds", self.confirm_seconds))

    @abstractmethod
    def evaluate(self, ctx: FrameContext) -> List[RuleHit]:
        """Вернуть нарушения на текущем кадре. Дедупликация — не здесь."""

    @classmethod
    def available(cls, labels: Sequence[str]) -> bool:
        return all(any(l in labels for l in group.split("|")) for group in cls.requires_labels)

    @classmethod
    def describe(cls, labels: Sequence[str]) -> dict:
        return {"type": cls.type, "title": cls.title, "severity": cls.severity,
                "default_params": {**cls.default_params, "confirm_seconds": cls.confirm_seconds},
                "available": cls.available(labels),
                "requires_labels": list(cls.requires_labels)}


RULES: Dict[str, Type[BaseRule]] = {}


def register_rule(cls: Type[BaseRule]) -> Type[BaseRule]:
    if not cls.type:
        raise ValueError(f"{cls.__name__} has no type")
    RULES[cls.type] = cls
    return cls


# --- геометрия, общая для правил -------------------------------------------
def box_gap(a: np.ndarray, b: np.ndarray) -> float:
    """Расстояние между прямоугольниками (0, если пересекаются)."""
    dx = max(b[0] - a[2], a[0] - b[2], 0.0)
    dy = max(b[1] - a[3], a[1] - b[3], 0.0)
    return float(np.hypot(dx, dy))


def history_window(track: Track, seconds: float) -> List[Tuple[float, float, float, float, float]]:
    t_now = track.t_last
    return [h for h in track.history if t_now - h[0] <= seconds]
