"""Автозагрузка всех модулей правил из пакета: достаточно положить файл сюда."""
import importlib
import pkgutil

from .base import RULES, BaseRule, FrameContext, RuleHit, register_rule

for _m in pkgutil.iter_modules(__path__):
    if _m.name != "base":
        importlib.import_module(f"{__name__}.{_m.name}")

__all__ = ["RULES", "BaseRule", "FrameContext", "RuleHit", "register_rule"]
