"""Дополнительные паттерны опасного поведения (задание хакатона, п. 1).

* sudden_move_machine — резкие перемещения в зоне работы техники (01);
* open_fire          — курение / открытый огонь вне отведённых мест (04);
* climb_crawl        — перелезание через ограждение, пролезание под конвейером
                       или подвешенным грузом (05);
* height_no_harness  — работа на высоте без страховочной привязи (06);
* motionless         — неподвижное лежание, признаки потери сознания (07);
* cargo_violation    — переноска груза с нарушением правил (08).

Базовая модель — COCO-YOLOv5s: огня, сигарет, страховочных привязей и ящиков в ней
нет. Поэтому правила работают в двух режимах: если подключена модель с нужными
классами (LABELS в .env), используются её детекции; иначе — эвристики по геометрии
треков, цвету и зонам, которые оператор рисует в «Настройке камер»:
fence (ограждение), conveyor (конвейер), suspended_load (подвешенный груз),
height (работы на высоте), smoking_area (отведённое место для курения).
"""
from __future__ import annotations

from collections import deque
from typing import Deque, Dict, List, Optional, Tuple

import cv2
import numpy as np

from ..config import CARGO_LABELS, FIRE_LABELS, HARNESS_LABELS
from .base import BaseRule, FrameContext, RuleHit, box_gap, history_window, register_rule
from .builtin import foot_points


# --- общее ------------------------------------------------------------------------
def _hist_shape(x) -> Tuple[float, float, float, float]:
    """(cx, cy, w, h) из записи истории трека (t, x1, y1, x2, y2)."""
    w, h = max(x[3] - x[1], 1e-6), max(x[4] - x[2], 1e-6)
    return (x[1] + x[3]) / 2, (x[2] + x[4]) / 2, w, h


def standing_height(track, window_s: float = 6.0) -> float:
    """Рост «в полный рост»: 80-й перцентиль высоты рамки за последние секунды."""
    w = history_window(track, window_s)
    hs = [x[4] - x[2] for x in w] or [float(track.box[3] - track.box[1])]
    return max(float(np.percentile(hs, 80)), 1.0)


def foot_speed(track, window_s: float) -> Optional[float]:
    """Средняя скорость ступней за окно, в ростах человека в секунду."""
    w = history_window(track, window_s)
    if len(w) < 3 or w[-1][0] - w[0][0] < 0.4:
        return None
    (t0, a1, _, a2, a4), (t1, b1, _, b2, b4) = w[0], w[-1]
    h = float(np.median([x[4] - x[2] for x in w]))
    dist = np.hypot((b1 + b2) / 2 - (a1 + a2) / 2, b4 - a4)
    return float(dist / max(t1 - t0, 1e-3) / max(h, 1.0))


class _Spot:
    """Объект без трека человека (очаг огня): интерфейс трека для событий и дедупликации."""

    def __init__(self, track_id: int, label: str, box, conf: float):
        self.track_id, self.label, self.conf = track_id, label, conf
        self.box = np.asarray(box, np.float32)

    @property
    def center(self):
        return float((self.box[0] + self.box[2]) / 2), float((self.box[1] + self.box[3]) / 2)


# --- 01. резкие перемещения в зоне работы техники ------------------------------------
@register_rule
class SuddenMoveMachineRule(BaseRule):
    """Резкие перемещения рядом с техникой: быстрое движение или рывок (резкая смена скорости).

    Срабатывает, только когда человек в нарисованной «зоне техники» или ближе
    near_machine_heights роста к погрузчику/грузовику. Порог скорости здесь ниже,
    чем у общего правила «Бег по цеху»: рядом с техникой опасен и быстрый шаг.
    """

    type = "sudden_move_machine"
    title = "Резкие перемещения в зоне работы техники"
    severity = "critical"
    confirm_seconds = 0.6
    default_params = {"speed_heights_per_s": 1.0, "accel_heights_per_s2": 4.0, "min_speed": 0.5,
                      "near_machine_heights": 1.0, "window_s": 1.2}

    def evaluate(self, ctx: FrameContext) -> List[RuleHit]:
        zones = ctx.active_zones(["machine"])
        if not zones and not ctx.machines:
            return []
        p_, hits = self.params, []
        for p in ctx.persons:
            ph = max(float(p.box[3] - p.box[1]), 1.0)
            zone = next((z for z in zones if any(ctx.point_in_zone(pt, z) for pt in foot_points(p.box))), None)
            near = None
            if zone is None:
                near = next((m for m in ctx.machines if box_gap(p.box, m.box) / ph < p_["near_machine_heights"]), None)
                if near is None:
                    continue
            w = history_window(p, p_["window_s"])
            if len(w) < 3 or w[-1][0] - w[0][0] < 0.4:
                continue
            hh = max(float(np.median([x[4] - x[2] for x in w])), 1.0)
            pts = np.array([((x[1] + x[3]) / 2, x[4]) for x in w], np.float64)   # ступни
            ts = np.array([x[0] for x in w], np.float64)
            dt = np.maximum(np.diff(ts), 1e-3)
            v = np.diff(pts, axis=0) / dt[:, None] / hh
            avg = float(np.linalg.norm(pts[-1] - pts[0]) / max(ts[-1] - ts[0], 1e-3) / hh)
            accel = 0.0
            if len(v) >= 2:
                mid = np.maximum((dt[1:] + dt[:-1]) / 2, 1e-3)
                accel = float((np.linalg.norm(np.diff(v, axis=0), axis=1) / mid).max())
            jerk = accel >= p_["accel_heights_per_s2"] and float(np.linalg.norm(v, axis=1).max()) >= p_["min_speed"]
            if avg >= p_["speed_heights_per_s"] or jerk:
                d = {"speed_heights_per_s": round(avg, 2), "accel_heights_per_s2": round(accel, 2),
                     "kind": "jerk" if jerk and avg < p_["speed_heights_per_s"] else "fast"}
                if near is not None:
                    d.update(machine_track_id=near.track_id, machine_label=near.label)
                hits.append(RuleHit(p, zone, d))
        return hits


# --- 04. курение / открытый огонь ----------------------------------------------------
def flame_mask(img: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Маски «пламя» и «ядро пламени».

    Пламя: почти насыщенный красный канал и большой разрыв R-B (жёлто-оранжевый огонь);
    кожа (R-B ~ 60-90), красная спецодежда (G мал) и тёплый свет сюда не проходят.
    Ядро: почти белые пиксели (все каналы ярко) — у настоящего огня оно есть всегда.
    """
    b, g, r = (img[..., i].astype(np.int16) for i in range(3))
    flame = (r >= 230) & (g >= 100) & (r >= g) & (g > b) & ((r - b) >= 120)
    core = (r >= 235) & (g >= 215) & (b >= 150)
    k3 = np.ones((3, 3), np.uint8)
    return cv2.morphologyEx(flame.astype(np.uint8), cv2.MORPH_OPEN, k3), core.astype(np.uint8)


@register_rule
class OpenFireRule(BaseRule):
    """Курение или открытый огонь вне отведённого места (зона типа smoking_area).

    1. Если модель знает классы fire/flame/smoke/cigarette/lighter — берём её детекции.
    2. Иначе эвристика: яркое «тёплое» пятно, которое мерцает на месте (площадь пятна
       скачет от кадра к кадру, coefficient of variation >= flicker_cv). Каски и жилеты
       тоже жёлто-оранжевые, но они не мерцают и двигаются вместе с человеком.
    Огонь рядом с головой/руками человека привязывается к нему («Курение…»),
    иначе событие создаётся по самому очагу.
    """

    type = "open_fire"
    title = "Курение / открытый огонь вне отведённого места"
    severity = "critical"
    confirm_seconds = 1.5
    gap_tolerance_s = 1.0
    default_params = {"heuristic": True, "min_area_frac": 0.00015, "max_area_frac": 0.2,
                      "flicker_cv": 0.18, "flicker_window_s": 2.0, "min_presence": 0.6, "min_samples": 4}

    def __init__(self, params=None):
        super().__init__(params)
        self._cells: Dict[Tuple[int, int], Deque[Tuple[float, float, Tuple[float, ...]]]] = {}
        self._frames: Deque[float] = deque(maxlen=200)

    def _blobs(self, img: np.ndarray) -> List[Tuple[np.ndarray, float]]:
        H, W = img.shape[:2]
        k = 640.0 / W if W > 640 else 1.0
        small = cv2.resize(img, (int(W * k), int(H * k)), interpolation=cv2.INTER_AREA) if k < 1 else img
        flame, core = flame_mask(small)
        m = cv2.dilate(flame | core, np.ones((5, 5), np.uint8))
        n, labels, stats, _ = cv2.connectedComponentsWithStats(m, connectivity=8)
        total = m.shape[0] * m.shape[1]
        out = []
        for i in range(1, n):
            x, y, w, h, a = (int(v) for v in stats[i])
            if a < max(12, self.params["min_area_frac"] * total) or a > self.params["max_area_frac"] * total:
                continue
            sel = labels[y:y + h, x:x + w] == i
            n_flame = int(flame[y:y + h, x:x + w][sel].sum())
            n_core = int(core[y:y + h, x:x + w][sel].sum())
            # огонь = оранжевые края + белое ядро; одно белое (лампа, блик) или одно оранжевое — нет
            if n_flame < 6 or n_core < 2 or n_core > 4 * n_flame:
                continue
            out.append((np.array([x, y, x + w, y + h], np.float32) / k, a / (k * k)))
        return out

    def _flickering(self, t: float, blobs, W: int) -> List[Tuple[Tuple[int, int], np.ndarray, float]]:
        cs = max(W / 12.0, 1.0)
        self._frames.append(t)
        win = self.params["flicker_window_s"]
        for box, area in blobs:
            cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
            c = (int(cx // cs), int(cy // cs))
            key = next((kk for kk in self._cells if abs(kk[0] - c[0]) <= 1 and abs(kk[1] - c[1]) <= 1), c)
            self._cells.setdefault(key, deque(maxlen=60)).append((t, area, tuple(map(float, box))))
        n_frames = sum(1 for x in self._frames if t - x <= win)
        out = []
        for key in list(self._cells):
            dq = self._cells[key]
            while dq and t - dq[0][0] > win:
                dq.popleft()
            if not dq:
                del self._cells[key]
                continue
            if dq[-1][0] != t or len(dq) < self.params["min_samples"]:
                continue
            areas = np.array([a for _, a, _ in dq])
            cv = float(areas.std() / max(areas.mean(), 1e-6))
            # очаг стоит на месте: центр пятна гуляет меньше его размера (движущиеся предметы — мимо)
            cxy = np.array([((b[0] + b[2]) / 2, (b[1] + b[3]) / 2) for _, _, b in dq])
            size = float(np.median([max(b[2] - b[0], b[3] - b[1]) for _, _, b in dq]))
            steady = float(np.linalg.norm(cxy - cxy.mean(axis=0), axis=1).max()) <= 0.6 * max(size, 1.0)
            if steady and len(dq) / max(n_frames, 1) >= self.params["min_presence"] and cv >= self.params["flicker_cv"]:
                out.append((key, np.array(dq[-1][2], np.float32), min(0.99, 0.5 + cv)))
        return out

    @staticmethod
    def _owner(ctx: FrameContext, box):
        cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
        best = None
        for p in ctx.persons:
            x1, y1, x2, y2 = map(float, p.box)
            w, h = x2 - x1, y2 - y1
            if x1 - 0.35 * w <= cx <= x2 + 0.35 * w and y1 - 0.1 * h <= cy <= y1 + 0.75 * h:
                d = abs(cx - (x1 + x2) / 2)
                if best is None or d < best[0]:
                    best = (d, p)
        return best[1] if best else None

    def evaluate(self, ctx: FrameContext) -> List[RuleHit]:
        allowed = ctx.active_zones(["smoking_area"])

        def is_allowed(pt) -> bool:
            return any(ctx.point_in_zone(pt, z) for z in allowed)

        cands = []   # (box, label, conf, spot_key)
        for o in ctx.others:
            if o.label in FIRE_LABELS:
                c = o.center
                cands.append((np.asarray(o.box, np.float32), o.label, float(o.conf),
                              (int(c[0] // max(ctx.frame_w / 12, 1)), int(c[1] // max(ctx.frame_w / 12, 1)))))
        if self.params["heuristic"] and ctx.image is not None:
            for key, box, conf in self._flickering(ctx.t, self._blobs(ctx.image), ctx.frame_w):
                cands.append((box, "flame", conf, key))

        hits, used = [], set()
        for box, label, conf, key in cands:
            center = ((box[0] + box[2]) / 2, (box[1] + box[3]) / 2)
            if is_allowed(center):
                continue
            owner = self._owner(ctx, box)
            if owner is not None:
                if owner.track_id in used or any(is_allowed(pt) for pt in foot_points(owner.box)):
                    continue
                used.add(owner.track_id)
                title = "Курение вне отведённого места" if label in ("cigarette", "smoking") else \
                    "Курение или открытый огонь вне отведённого места"
                hits.append(RuleHit(owner, None, {"title": title, "source": label, "fire_conf": round(conf, 2),
                                                  "fire_box": [round(float(v), 1) for v in box]}))
            else:
                spot = _Spot(-(1000 + key[1] * 100 + key[0]), label, box, conf)
                if spot.track_id in used:
                    continue
                used.add(spot.track_id)
                hits.append(RuleHit(spot, None, {"title": "Открытый огонь вне отведённого места",
                                                 "source": label, "fire_conf": round(conf, 2)}))
        return hits


# --- 05. перелезание через ограждение, пролезание под конвейером/грузом ----------------
CLIMB_TITLES = {
    "fence": "Перелезание через ограждение",
    "conveyor": "Пролезание под конвейером",
    "suspended_load": "Нахождение под подвешенным грузом",
}


@register_rule
class ClimbCrawlRule(BaseRule):
    """Перелезание и пролезание — по зонам, которые оператор рисует на кадре.

    * fence — полоса вдоль ограждения: ступни в полосе (человек на/через ограждении)
      или корпус в полосе и ступни приподняты над прежним уровнем (лезет вверх);
    * conveyor — пространство под конвейером: человек в зоне пригнулся/ползёт
      (рамка ниже crouch_frac роста или почти квадратная);
    * suspended_load — зона под краном/подвешенным грузом: нахождение там запрещено,
      пригнувшийся человек — «пролезание под грузом».
    """

    type = "climb_crawl"
    title = "Перелезание через ограждение / пролезание под конвейером или грузом"
    severity = "critical"
    confirm_seconds = 0.8
    default_params = {"crouch_frac": 0.7, "crouch_ratio": 0.9, "raise_frac": 0.12, "baseline_s": 5.0}

    def evaluate(self, ctx: FrameContext) -> List[RuleHit]:
        zones = ctx.active_zones(["fence", "conveyor", "suspended_load"])
        if not zones:
            return []
        p_, hits = self.params, []
        for p in ctx.persons:
            x1, y1, x2, y2 = map(float, p.box)
            w, h = x2 - x1, max(y2 - y1, 1.0)
            feet = foot_points(p.box)
            center = ((x1 + x2) / 2, (y1 + y2) / 2)
            stand_h = max(standing_height(p, p_["baseline_s"]), h)
            crouched = h <= p_["crouch_frac"] * stand_h or w / h >= p_["crouch_ratio"]
            base = [x for x in history_window(p, p_["baseline_s"]) if x[0] <= p.t_last - 1.0]
            raised = len(base) >= 3 and float(np.median([x[4] for x in base])) - y2 >= p_["raise_frac"] * stand_h
            for z in zones:
                feet_in = any(ctx.point_in_zone(pt, z) for pt in feet)
                body_in = feet_in or ctx.point_in_zone(center, z)
                title = None
                if z.kind == "fence" and (feet_in or (body_in and raised)):
                    title = CLIMB_TITLES["fence"]
                elif z.kind == "conveyor" and body_in and crouched:
                    title = CLIMB_TITLES["conveyor"]
                elif z.kind == "suspended_load" and feet_in:
                    title = "Пролезание под подвешенным грузом" if crouched else CLIMB_TITLES["suspended_load"]
                if title:
                    hits.append(RuleHit(p, z, {"title": title, "zone_kind": z.kind, "crouched": bool(crouched),
                                               "feet_raised": bool(raised), "height_frac": round(h / stand_h, 2)}))
                    break
        return hits


# --- 06. работа на высоте без страховочной привязи ----------------------------------
@register_rule
class HeightHarnessRule(BaseRule):
    """Работа на высоте (зона типа height: леса, площадка, лестница) без страховки.

    Если модель знает класс harness/safety_harness/lanyard — нарушение, когда у человека
    в зоне на корпусе не найдена привязь. COCO-модель привязи не видит: тогда каждый
    человек в зоне высоты даёт событие «страховка не подтверждена» — оператор
    подтверждает или отклоняет его в журнале (отклонённые кадры идут в датасет).
    """

    type = "height_no_harness"
    title = "Работа на высоте без страховочной привязи"
    severity = "critical"
    confirm_seconds = 3.0
    gap_tolerance_s = 1.0
    default_params = {"torso_from": 0.1, "torso_to": 0.7}

    def evaluate(self, ctx: FrameContext) -> List[RuleHit]:
        zones = ctx.active_zones(["height"])
        if not zones:
            return []
        has_model = bool(set(getattr(self, "model_labels", ())) & HARNESS_LABELS)
        harness = [o for o in ctx.others if o.label in HARNESS_LABELS]
        hits = []
        for p in ctx.persons:
            x1, y1, x2, y2 = map(float, p.box)
            pts = foot_points(p.box) + [((x1 + x2) / 2, (y1 + y2) / 2)]
            zone = next((z for z in zones if any(ctx.point_in_zone(pt, z) for pt in pts)), None)
            if zone is None:
                continue
            h = y2 - y1
            ty1, ty2 = y1 + self.params["torso_from"] * h, y1 + self.params["torso_to"] * h
            found = any(x1 <= o.center[0] <= x2 and ty1 <= o.center[1] <= ty2 for o in harness)
            if found:
                continue
            if has_model:
                hits.append(RuleHit(p, zone, {"harness_check": "model", "missing": ["harness"]}))
            else:
                hits.append(RuleHit(p, zone, {"harness_check": "not_available",
                                              "title": "Работа на высоте: страховочная привязь не подтверждена"}))
        return hits


# --- 07. неподвижное лежание, признаки потери сознания -------------------------------
@register_rule
class MotionlessRule(BaseRule):
    """Человек лежит и не двигается дольше still_s — возможна потеря сознания.

    «Лежит»: рамка широкая (W/H >= lying_ratio) либо заметно ниже его же роста стоя.
    «Не двигается»: центр рамки сместился меньше max_shift её размера, а размер
    изменился меньше max_size_change. Отдельно от правила падения: падение — момент,
    это правило — состояние после него (эскалация).
    """

    type = "motionless"
    title = "Неподвижное лежание — признаки потери сознания"
    severity = "critical"
    confirm_seconds = 1.0
    default_params = {"still_s": 8.0, "max_shift": 0.12, "max_size_change": 0.2,
                      "lying_ratio": 1.1, "low_frac": 0.55, "low_ratio": 0.9}

    def evaluate(self, ctx: FrameContext) -> List[RuleHit]:
        p_, hits = self.params, []
        for tr in ctx.persons:
            hist = list(tr.history)
            if len(hist) < 5:
                continue
            t_now = hist[-1][0]
            cx, cy, w, h = _hist_shape(hist[-1])
            r = w / h
            stand_h = float(np.percentile([x[4] - x[2] for x in hist], 80))
            lying = r >= p_["lying_ratio"] or (h <= p_["low_frac"] * stand_h and r >= p_["low_ratio"])
            if not lying:
                continue
            size = max(w, h)
            k = len(hist) - 1
            while k > 0:
                px, py, pw, ph = _hist_shape(hist[k - 1])
                if np.hypot(px - cx, py - cy) / size > p_["max_shift"] or abs(max(pw, ph) / size - 1) > p_["max_size_change"]:
                    break
                k -= 1
            still = t_now - hist[k][0]
            if still >= p_["still_s"]:
                hits.append(RuleHit(tr, None, {"seconds_still": round(still, 1), "aspect_ratio": round(r, 2)}))
        return hits


# --- 08. переноска груза с нарушением правил -----------------------------------------
CARGO_TITLES = {
    "over_head": "Переноска груза над головой",
    "blocks_view": "Груз закрывает обзор при переноске",
    "oversize": "Переноска крупногабаритного груза в одиночку",
    "running": "Бег с грузом",
    "near_machine": "Переноска груза рядом с работающей техникой",
}


@register_rule
class CargoRule(BaseRule):
    """Переноска груза с нарушением правил (дополнительный сценарий).

    Груз — объект классов CARGO_LABELS (в COCO это suitcase; модель с классами
    box/package/crate распознаёт и коробки), который находится в руках/на плечах
    человека, а не стоит на полу рядом. Нарушения: груз над головой, груз закрывает
    лицо (нет обзора), груз крупнее oversize_area площади человека, бег с грузом,
    переноска ближе near_machine_heights роста к технике.
    """

    type = "cargo_violation"
    title = "Переноска груза с нарушением правил"
    severity = "warning"
    confirm_seconds = 1.5
    gap_tolerance_s = 1.0
    requires_labels = ("|".join(sorted(CARGO_LABELS)),)
    default_params = {"run_speed": 1.0, "oversize_area": 0.45, "view_block": 0.35,
                      "near_machine_heights": 0.5, "window_s": 1.0}

    def evaluate(self, ctx: FrameContext) -> List[RuleHit]:
        loads = [o for o in ctx.others if o.label in CARGO_LABELS]
        if not loads:
            return []
        p_, hits = self.params, []
        for p in ctx.persons:
            x1, y1, x2, y2 = map(float, p.box)
            w, h = x2 - x1, max(y2 - y1, 1.0)
            carried = []
            for o in loads:
                ox1, oy1, ox2, oy2 = map(float, o.box)
                cx, cy = (ox1 + ox2) / 2, (oy1 + oy2) / 2
                if not (x1 - 0.25 * w <= cx <= x2 + 0.25 * w and y1 - 0.4 * h <= cy <= y1 + 0.8 * h):
                    continue
                if oy2 >= y2 - 0.03 * h and cy > y1 + 0.6 * h:   # стоит на полу у ног
                    continue
                carried.append(o)
            if not carried:
                continue
            o = max(carried, key=lambda o: float((o.box[2] - o.box[0]) * (o.box[3] - o.box[1])))
            ox1, oy1, ox2, oy2 = map(float, o.box)
            reasons = []
            if oy2 <= y1 + 0.2 * h:
                reasons.append("over_head")
            fy1, fy2, fx1, fx2 = y1 + 0.03 * h, y1 + 0.2 * h, x1 + 0.25 * w, x2 - 0.25 * w
            face = max(fy2 - fy1, 1.0) * max(fx2 - fx1, 1.0)
            inter = max(0.0, min(oy2, fy2) - max(oy1, fy1)) * max(0.0, min(ox2, fx2) - max(ox1, fx1))
            if "over_head" not in reasons and inter / face >= p_["view_block"]:
                reasons.append("blocks_view")
            if (ox2 - ox1) * (oy2 - oy1) >= p_["oversize_area"] * w * h:
                reasons.append("oversize")
            speed = foot_speed(p, p_["window_s"])
            if speed is not None and speed >= p_["run_speed"]:
                reasons.append("running")
            if any(box_gap(p.box, m.box) / h < p_["near_machine_heights"] for m in ctx.machines):
                reasons.append("near_machine")
            if reasons:
                hits.append(RuleHit(p, None, {"title": CARGO_TITLES[reasons[0]], "reasons": reasons,
                                              "cargo_label": o.label, "cargo_conf": round(float(o.conf), 2),
                                              "speed_heights_per_s": round(speed, 2) if speed is not None else None}))
        return hits
