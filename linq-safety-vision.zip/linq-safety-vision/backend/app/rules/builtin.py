"""Правила охраны труда.

Пороги — в относительных единицах (доли роста человека), чтобы правила одинаково
работали на дальних и ближних камерах. Все параметры можно менять из UI (params).
"""
from __future__ import annotations

from typing import List, Optional, Tuple

import cv2
import numpy as np

from .base import BaseRule, FrameContext, RuleHit, box_gap, history_window, register_rule

ZONE_TITLES = {
    "danger": "Нахождение в опасной зоне",
    "restricted": "Проход в запретную зону",
    "machine": "Нахождение в зоне работы техники",
}


def foot_points(box: np.ndarray) -> List[Tuple[float, float]]:
    """Точки опоры человека: низ-центр и низ на 25/75% ширины (устойчиво к дрожанию рамки)."""
    x1, y1, x2, y2 = map(float, box)
    w = x2 - x1
    y = y2 - 0.03 * (y2 - y1)
    return [((x1 + x2) / 2, y), (x1 + 0.25 * w, y), (x1 + 0.75 * w, y)]


@register_rule
class DangerZoneRule(BaseRule):
    """Человек стоит в нарисованной зоне (любого типа: опасная, запретная, зона техники).

    Проверяются ступни (нижняя часть рамки), а не центр: так человек «за» зоной
    в перспективе не считается вошедшим. Заголовок события зависит от типа зоны.
    """

    type = "danger_zone"
    title = "Нахождение в опасной зоне"
    severity = "critical"
    confirm_seconds = 1.0
    default_params = {"zone_kinds": ["danger", "restricted", "machine"], "min_points_inside": 1}

    def evaluate(self, ctx: FrameContext) -> List[RuleHit]:
        hits = []
        zones = ctx.active_zones(self.params["zone_kinds"])
        if not zones:
            return hits
        for p in ctx.persons:
            pts = foot_points(p.box)
            for z in zones:
                inside = sum(ctx.point_in_zone(pt, z) for pt in pts)
                if inside >= self.params["min_points_inside"]:
                    hits.append(RuleHit(p, z, {
                        "point": [round(pts[0][0], 1), round(pts[0][1], 1)],
                        "zone_kind": z.kind,
                        "title": ZONE_TITLES.get(z.kind, self.title),
                    }))
                    break
        return hits


@register_rule
class MachineProximityRule(BaseRule):
    """Опасное сближение человека с техникой (погрузчик, грузовик, станок).

    Зазор между рамками меньше max_gap_heights роста человека. Вход в нарисованную
    «зону техники» обрабатывает правило зон, чтобы одно нарушение не давало два события.
    """

    type = "machine_proximity"
    title = "Опасное сближение с техникой"
    severity = "critical"
    confirm_seconds = 1.5
    default_params = {"max_gap_heights": 0.3}

    def evaluate(self, ctx: FrameContext) -> List[RuleHit]:
        hits = []
        for p in ctx.persons:
            ph = max(p.box[3] - p.box[1], 1.0)
            best = None
            for m in ctx.machines:
                gap = box_gap(p.box, m.box) / ph
                if gap < self.params["max_gap_heights"] and (best is None or gap < best[0]):
                    best = (gap, m)
            if best:
                hits.append(RuleHit(p, None, {"machine_track_id": best[1].track_id,
                                              "machine_label": best[1].label,
                                              "gap_heights": round(best[0], 2)}))
        return hits


def _shape(x) -> Tuple[float, float, float]:
    """(соотношение W/H, высота, площадь) рамки из записи истории (t, x1, y1, x2, y2)."""
    w, h = max(x[3] - x[1], 1e-6), max(x[4] - x[2], 1e-6)
    return w / h, h, w * h


@register_rule
class FallRule(BaseRule):
    """Падение человека — работает при любом ракурсе камеры (сбоку, сверху, под углом).

    Сравниваем силуэт человека с ним же самим секунды назад, а не с «нормой»:
    при съёмке сверху стоящий человек выглядит компактным пятном, и абсолютные
    пороги вида «высокий -> широкий» не работают.

    1. Резкое падение: за ≤ change_window_s силуэт сильно изменился — соотношение
       сторон в ≥ change_factor раз (в любую сторону) или высота упала до ≤ drop_height_frac,
       и остаётся изменённым ≥ stay_changed_s, при этом человек почти не идёт
       (медленнее max_speed размеров тела в секунду — лента конвейера допустима).
       Присел или наклонился и выпрямился — силуэт вернулся, тревоги нет.
    2. Лежит: рамка «лежачая» (W/H ≥ lying_ratio) дольше lying_s и человек не идёт —
       даже если сам момент падения камера не застала.
    """

    type = "fall"
    title = "Падение человека"
    severity = "critical"
    confirm_seconds = 0.3
    default_params = {
        "change_window_s": 1.2,
        "change_factor": 1.6,
        "final_factor": 3.0,
        "drop_height_frac": 0.65,
        "stay_changed_s": 1.5,
        "stay_factor": 1.35,
        "max_speed": 0.6,
        "baseline_s": 4.0,
        "lying_ratio": 1.3,
        "lying_s": 3.0,
    }

    def _changed(self, x, R0: float, H0: float, factor: float, h_frac: float) -> bool:
        r, h, _ = _shape(x)
        return max(r / R0, R0 / r) >= factor or h <= h_frac * H0

    @staticmethod
    def _known_posture(hist, t_before: float, r_f: float, h_f: float) -> bool:
        """Был ли человек раньше (до t_before) в такой же позе ≥ 0.8 с подряд."""
        early = [x for x in hist if x[0] < t_before]
        if len(early) < 4:
            return False
        t0 = early[0][0]
        while t0 + 0.8 <= early[-1][0]:
            win = [x for x in early if t0 <= x[0] < t0 + 0.8]
            if len(win) >= 3:
                r = float(np.median([_shape(x)[0] for x in win]))
                h = float(np.median([_shape(x)[1] for x in win]))
                if max(r / r_f, r_f / r) <= 1.25 and max(h / h_f, h_f / h) <= 1.25:
                    return True
            t0 += 0.4
        return False

    @staticmethod
    def _speed(seg) -> float:
        """Скорость центра рамки в размерах тела в секунду."""
        if len(seg) < 2 or seg[-1][0] - seg[0][0] <= 0:
            return 0.0
        c0 = np.array([(seg[0][1] + seg[0][3]) / 2, (seg[0][2] + seg[0][4]) / 2])
        c1 = np.array([(seg[-1][1] + seg[-1][3]) / 2, (seg[-1][2] + seg[-1][4]) / 2])
        size = np.median([max(x[3] - x[1], x[4] - x[2]) for x in seg])
        return float(np.linalg.norm(c1 - c0) / max(size, 1.0) / (seg[-1][0] - seg[0][0]))

    def evaluate(self, ctx: FrameContext) -> List[RuleHit]:
        hits, p_ = [], self.params
        for tr in ctx.persons:
            hist = list(tr.history)
            if len(hist) < 3:
                continue
            t_now = hist[-1][0]

            # --- 1. резкое изменение силуэта -------------------------------------
            # ищем момент k, с которого силуэт непрерывно «изменён» относительно базового
            for k in range(len(hist) - 1, 0, -1):
                t_k = hist[k][0]
                if t_now - t_k < p_["stay_changed_s"]:
                    continue
                base = [x for x in hist if t_k - p_["baseline_s"] <= x[0] <= t_k - 0.4]
                if len(base) < 3:
                    break
                R0 = float(np.median([_shape(x)[0] for x in base]))
                H0 = float(np.median([_shape(x)[1] for x in base]))
                after = [x for x in hist if x[0] >= t_k]
                if not all(self._changed(x, R0, H0, p_["stay_factor"], p_["drop_height_frac"] + 0.1) for x in after):
                    continue
                if not self._changed(hist[k], R0, H0, p_["change_factor"], p_["drop_height_frac"]) and \
                        not any(self._changed(x, R0, H0, p_["change_factor"], p_["drop_height_frac"]) for x in after[:4]):
                    continue
                # итоговое положение: медиана последних 0.8 с
                tail = [x for x in hist if x[0] >= t_now - 0.8]
                r_f = float(np.median([_shape(x)[0] for x in tail]))
                final_factor = max(r_f / R0, R0 / r_f)
                h_f = float(np.median([_shape(x)[1] for x in tail]))
                lay_wide = r_f >= 1.0 and r_f / R0 >= 1.5          # лёг поперёк кадра (сбоку или сверху)
                lay_long = h_f >= 1.6 * H0 and R0 / r_f >= 1.6     # сверху: лёг вдоль кадра — рамка вытянулась
                if not (lay_wide or lay_long or final_factor >= p_["final_factor"]):
                    continue      # присел/наклонился: рамка стала ниже, но осталась узкой
                if self._known_posture(hist, t_k - 0.4, r_f, h_f):
                    continue      # вернулся в позу, в которой уже был (например, встал после приседа)
                # переход был быстрым: от «обычного» силуэта до итогового ≤ change_window_s
                t_start = max((x[0] for x in hist if x[0] <= t_k and not self._changed(x, R0, H0, 1.15, 0.85)), default=None)
                t_plateau = min((x[0] for x in after if max(_shape(x)[0] / r_f, r_f / _shape(x)[0]) <= 1.15), default=None)
                if t_start is None or t_plateau is None or t_plateau - t_start > p_["change_window_s"]:
                    continue
                if self._speed(after) > p_["max_speed"]:
                    continue
                r, h, _ = _shape(hist[-1])
                hits.append(RuleHit(tr, None, {"kind": "sudden", "aspect_ratio": round(r, 2),
                                               "aspect_before": round(R0, 2),
                                               "seconds_down": round(t_now - t_k, 1)}))
                break
            if hits and hits[-1].track is tr:
                continue

            # --- 2. лежит -------------------------------------------------------
            r, _, _ = _shape(hist[-1])
            if r >= p_["lying_ratio"]:
                k = len(hist) - 1
                while k > 0 and _shape(hist[k - 1])[0] >= p_["lying_ratio"]:
                    k -= 1
                seg = hist[k:]
                if t_now - hist[k][0] >= p_["lying_s"] and self._speed(seg) <= p_["max_speed"]:
                    hits.append(RuleHit(tr, None, {"kind": "lying", "aspect_ratio": round(r, 2),
                                                   "seconds_down": round(t_now - hist[k][0], 1)}))
        return hits


@register_rule
class RunningRule(BaseRule):
    """Бег по цеху: скорость ступней > порога (ростов человека в секунду)."""

    type = "running"
    title = "Бег по цеху"
    severity = "warning"
    confirm_seconds = 1.5
    default_params = {"speed_heights_per_s": 1.6, "window_s": 1.0}

    def evaluate(self, ctx: FrameContext) -> List[RuleHit]:
        hits = []
        for tr in ctx.persons:
            w = history_window(tr, self.params["window_s"])
            if len(w) < 3 or w[-1][0] - w[0][0] < 0.5 * self.params["window_s"]:
                continue
            (t0, a1, _, a2, a4), (t1, b1, _, b2, b4) = w[0], w[-1]
            dist = np.hypot((b1 + b2) / 2 - (a1 + a2) / 2, b4 - a4)
            h = np.median([x[4] - x[2] for x in w])
            speed = dist / max(t1 - t0, 1e-3) / max(h, 1.0)
            if speed > self.params["speed_heights_per_s"]:
                hits.append(RuleHit(tr, None, {"speed_heights_per_s": round(float(speed), 2)}))
        return hits


@register_rule
class PhoneUseRule(BaseRule):
    """Работа с телефоном: в руках у человека виден мобильный телефон (класс COCO «cell phone»).

    Телефон считается «в руках», если его центр внутри рамки человека (с небольшим запасом
    по бокам) и на уровне от головы до пояса (верхние upper_fraction роста). Телефоны мелкие
    и детектор видит их не на каждом кадре, поэтому пропуски до gap_tolerance_s не сбрасывают
    таймер, а порог уверенности для телефона ниже основного (PHONE_CONF в .env).
    """

    type = "phone_use"
    title = "Использование телефона"
    severity = "warning"
    confirm_seconds = 2.0
    gap_tolerance_s = 1.5
    requires_labels = ("cell phone",)
    default_params = {"upper_fraction": 0.8, "side_margin": 0.15, "max_area_share": 0.25}

    def evaluate(self, ctx: FrameContext) -> List[RuleHit]:
        phones = [o for o in ctx.others if o.label == "cell phone"]
        if not phones:
            return []
        hits = []
        m, up = self.params["side_margin"], self.params["upper_fraction"]
        for p in ctx.persons:
            x1, y1, x2, y2 = map(float, p.box)
            bw, bh = x2 - x1, y2 - y1
            best = None
            for ph in phones:
                cx, cy = ph.center
                pb = ph.box
                area = (pb[2] - pb[0]) * (pb[3] - pb[1])
                if not (x1 - m * bw <= cx <= x2 + m * bw and y1 - 0.05 * bh <= cy <= y1 + up * bh):
                    continue
                if area > self.params["max_area_share"] * bw * bh:
                    continue
                if best is None or ph.conf > best.conf:
                    best = ph
            if best is not None:
                hits.append(RuleHit(p, None, {"phone_conf": round(float(best.conf), 2)}))
        return hits


# --- каска ------------------------------------------------------------------------
def _helmet_mask_share(patch: np.ndarray) -> Optional[float]:
    if patch.size == 0 or patch.shape[0] < 2 or patch.shape[1] < 2:
        return None
    hsv = cv2.cvtColor(patch, cv2.COLOR_BGR2HSV)
    h, s, v = hsv[..., 0].astype(np.int16), hsv[..., 1].astype(np.int16), hsv[..., 2].astype(np.int16)
    bright = v >= 120
    yellow = (h >= 18) & (h <= 35) & (s >= 120)
    orange = (h >= 5) & (h < 18) & (s >= 170)
    red = ((h < 5) | (h >= 170)) & (s >= 150)
    blue = (h >= 95) & (h <= 130) & (s >= 120)
    green = (h >= 40) & (h <= 85) & (s >= 120)
    white = (s <= 35) & (v >= 200)
    return float(((bright & (yellow | orange | red | blue | green)) | white).mean())


def helmet_color_share(img: np.ndarray, box: np.ndarray, head_fraction: float = 0.16) -> Optional[float]:
    """Насколько макушка человека «касочного» цвета по сравнению с фоном вокруг головы.

    Каски на производстве — насыщенные жёлтые, оранжевые, красные, синие, зелёные или
    белые; волосы, кожа и капюшоны тёмные или малонасыщенные. Берём верхнюю часть рамки
    (голова, центральные 60% ширины) и вычитаем долю тех же цветов в фоне рядом с головой
    (полоса над головой и полосы слева/справа на той же высоте). Иначе белая стена или
    жёлтый погрузчик за спиной выглядели бы как каска.
    """
    H, W = img.shape[:2]
    x1, y1, x2, y2 = map(float, box)
    bw, bh = x2 - x1, y2 - y1
    hx1, hx2 = int(max(0, x1 + 0.2 * bw)), int(min(W, x2 - 0.2 * bw))
    hy1, hy2 = int(max(0, y1)), int(min(H, y1 + head_fraction * bh))
    if hx2 - hx1 < 4 or hy2 - hy1 < 4:
        return None
    head = _helmet_mask_share(img[hy1:hy2, hx1:hx2])
    if head is None:
        return None
    hh = hy2 - hy1
    refs = []
    above = img[max(0, hy1 - hh):hy1, hx1:hx2]
    left = img[hy1:hy2, max(0, int(x1 - 0.35 * bw)):max(0, int(x1))]
    right = img[hy1:hy2, min(W, int(x2)):min(W, int(x2 + 0.35 * bw))]
    for patch in (above, left, right):
        share = _helmet_mask_share(patch) if patch.size and patch.shape[0] >= 2 and patch.shape[1] >= 2 else None
        if share is not None:
            refs.append(share)
    background = float(np.median(refs)) if refs else 0.0
    return max(0.0, head - background)


@register_rule
class HelmetColorRule(BaseRule):
    """Работа без каски — без отдельной нейросети СИЗ.

    Для каждого стоящего человека анализируется цвет макушки (см. helmet_color_share).
    Нужен достаточно крупный план (рост человека ≥ min_person_px пикселей); для мелких
    фигур правило молчит, чтобы не давать ложных тревог. Если подключить модель
    с классами helmet/hardhat, точнее работает правило no_ppe.
    """

    type = "no_helmet"
    title = "Работа без каски"
    severity = "warning"
    confirm_seconds = 3.0
    default_params = {"min_person_px": 80, "head_fraction": 0.16, "min_helmet_share": 0.18}

    @classmethod
    def available(cls, labels) -> bool:
        # если модель сама находит каски — работает правило no_ppe, этот эвристический путь не нужен
        return not any(l in labels for l in ("helmet", "hardhat"))

    def evaluate(self, ctx: FrameContext) -> List[RuleHit]:
        if ctx.image is None:
            return []
        hits = []
        for p in ctx.persons:
            x1, y1, x2, y2 = p.box
            bw, bh = x2 - x1, y2 - y1
            if bh < self.params["min_person_px"] or bw <= 0 or bh / bw < 1.3:   # мелко или не стоит
                continue
            fh, fw = ctx.image.shape[:2]
            if x1 <= 2 or x2 >= fw - 2 or y1 <= 2:      # человек обрезан краем кадра — головы может не быть в рамке
                continue
            share = helmet_color_share(ctx.image, p.box, self.params["head_fraction"])
            if share is not None and share < self.params["min_helmet_share"]:
                hits.append(RuleHit(p, None, {"missing": ["helmet"], "helmet_color_share": round(share, 2)}))
        return hits


@register_rule
class PpeRule(BaseRule):
    """Нет СИЗ по нейросети: внутри контура человека нет бокса нужного класса.

    Работает, только если модель детектирует СИЗ (helmet/vest/...). Базовая
    COCO-YOLOv5s их не знает — тогда правило помечается available=false,
    а каску проверяет правило no_helmet.
    """

    type = "no_ppe"
    title = "Работа без СИЗ"
    severity = "warning"
    confirm_seconds = 3.0
    requires_labels = ("helmet|hardhat",)
    default_params = {"required": ["helmet|hardhat"], "head_fraction": 0.35}

    def evaluate(self, ctx: FrameContext) -> List[RuleHit]:
        hits = []
        for p in ctx.persons:
            x1, y1, x2, y2 = p.box
            missing = []
            for group in self.params["required"]:
                names = set(group.split("|"))
                is_head = bool(names & {"helmet", "hardhat"})
                ry2 = y1 + (y2 - y1) * self.params["head_fraction"] if is_head else y2
                found = any(o.label in names and x1 <= o.center[0] <= x2 and y1 - 0.1 * (y2 - y1) <= o.center[1] <= ry2
                            for o in ctx.others)
                if not found:
                    missing.append(group.split("|")[0])
            if missing:
                hits.append(RuleHit(p, None, {"missing": missing}))
        return hits
