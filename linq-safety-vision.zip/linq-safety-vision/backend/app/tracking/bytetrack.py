"""Лёгкий ByteTrack: фильтр Калмана + двухэтапное сопоставление по IoU.

Этап 1 — уверенные детекции (conf >= high_thresh) с активными треками,
этап 2 — оставшиеся треки со слабыми детекциями (low..high): так трек не
рвётся, когда человек частично перекрыт и уверенность модели проседает.
Время жизни потерянного трека — в секундах (max_lost_s), а не кадрах,
чтобы не зависеть от FPS обработки. Классы трекаются раздельно.

У каждого трека хранится история (t, x1, y1, x2, y2) — её используют правила
(падение, бег, сближение).
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Tuple

import numpy as np
from scipy.optimize import linear_sum_assignment

from ..inference.base import Detection


class KalmanXYAH:
    """Состояние [cx, cy, a, h, vx, vy, va, vh], a = w/h (как в SORT/ByteTrack)."""

    _std_pos, _std_vel = 1 / 20, 1 / 160

    def __init__(self, xyah: np.ndarray):
        self.x = np.r_[xyah, np.zeros(4)].astype(np.float64)
        h = xyah[3]
        std = [2 * self._std_pos * h, 2 * self._std_pos * h, 1e-2, 2 * self._std_pos * h,
               10 * self._std_vel * h, 10 * self._std_vel * h, 1e-5, 10 * self._std_vel * h]
        self.P = np.diag(np.square(std))
        self.F = np.eye(8)
        self.H = np.eye(4, 8)

    def predict(self, dt: float = 1.0) -> None:
        self.F[:4, 4:] = np.eye(4) * dt
        h = self.x[3]
        std = [self._std_pos * h, self._std_pos * h, 1e-2, self._std_pos * h,
               self._std_vel * h, self._std_vel * h, 1e-5, self._std_vel * h]
        self.x = self.F @ self.x
        self.P = self.F @ self.P @ self.F.T + np.diag(np.square(std)) * max(dt, 1e-3)

    def update(self, z: np.ndarray) -> None:
        h = self.x[3]
        R = np.diag(np.square([self._std_pos * h, self._std_pos * h, 1e-1, self._std_pos * h]))
        S = self.H @ self.P @ self.H.T + R
        K = self.P @ self.H.T @ np.linalg.inv(S)
        self.x = self.x + K @ (z - self.H @ self.x)
        self.P = (np.eye(8) - K @ self.H) @ self.P

    @property
    def xyxy(self) -> np.ndarray:
        cx, cy, a, h = self.x[:4]
        w = a * h
        return np.array([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2])


def xyxy_to_xyah(b: np.ndarray) -> np.ndarray:
    w, h = b[2] - b[0], max(b[3] - b[1], 1e-6)
    return np.array([(b[0] + b[2]) / 2, (b[1] + b[3]) / 2, w / h, h])


def iou_matrix(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    if len(a) == 0 or len(b) == 0:
        return np.zeros((len(a), len(b)))
    x1 = np.maximum(a[:, None, 0], b[None, :, 0]); y1 = np.maximum(a[:, None, 1], b[None, :, 1])
    x2 = np.minimum(a[:, None, 2], b[None, :, 2]); y2 = np.minimum(a[:, None, 3], b[None, :, 3])
    inter = np.clip(x2 - x1, 0, None) * np.clip(y2 - y1, 0, None)
    aa = (a[:, 2] - a[:, 0]) * (a[:, 3] - a[:, 1]); ab = (b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1])
    return inter / (aa[:, None] + ab[None, :] - inter + 1e-9)


@dataclass
class Track:
    track_id: int
    cls: int
    label: str
    kf: KalmanXYAH
    conf: float
    t_start: float
    t_last: float
    det_box: np.ndarray                     # последняя реальная (не предсказанная) рамка
    hits: int = 1
    history: Deque[Tuple[float, float, float, float, float]] = field(default_factory=lambda: deque(maxlen=150))
    state: Dict = field(default_factory=dict)   # память правил (например, фаза падения)

    @property
    def box(self) -> np.ndarray:
        return self.det_box

    @property
    def bottom_center(self) -> Tuple[float, float]:
        b = self.det_box
        return float((b[0] + b[2]) / 2), float(b[3])

    @property
    def center(self) -> Tuple[float, float]:
        b = self.det_box
        return float((b[0] + b[2]) / 2), float((b[1] + b[3]) / 2)

    def to_dict(self) -> dict:
        return {"track_id": self.track_id, "label": self.label, "conf": round(self.conf, 3),
                "bbox": [round(float(v), 1) for v in self.det_box]}


class ByteTracker:
    def __init__(self, high_thresh: float = 0.5, low_thresh: float = 0.15, new_track_thresh: float = 0.5,
                 match_iou: float = 0.2, low_match_iou: float = 0.3, max_lost_s: float = 1.5, min_hits: int = 2,
                 dist_gate: float = 0.6):
        # dist_gate — макс. смещение центра за 0.2 с (кадр при 5 FPS), в ростах человека
        self.dist_gate = dist_gate
        self.high, self.low, self.new_thr = high_thresh, low_thresh, new_track_thresh
        self.match_iou, self.low_match_iou = match_iou, low_match_iou
        self.max_lost_s, self.min_hits = max_lost_s, min_hits
        self.tracks: List[Track] = []
        self._next_id = 1
        self._t_prev: float | None = None

    def _assign(self, tracks: List[Track], dets: List[Detection], thr: float):
        if not tracks or not dets:
            return [], list(range(len(tracks))), list(range(len(dets)))
        tb = np.array([t.kf.xyxy for t in tracks])
        db = np.array([d.xyxy for d in dets])
        iou = iou_matrix(tb, db)
        cost = 1 - iou
        cost[np.array([[t.cls != d.cls for d in dets] for t in tracks])] = 1e6
        r, c = linear_sum_assignment(cost)
        matches = [(i, j) for i, j in zip(r, c) if iou[i, j] >= thr and cost[i, j] < 1e5]
        mt = {i for i, _ in matches}; md = {j for _, j in matches}
        return matches, [i for i in range(len(tracks)) if i not in mt], [j for j in range(len(dets)) if j not in md]

    def _assign_by_distance(self, tracks: List[Track], dets: List[Detection], det_idx: List[int], t: float) -> List[int]:
        if not tracks or not det_idx:
            return det_idx
        cost = np.full((len(tracks), len(det_idx)), 1e6)
        for i, tr in enumerate(tracks):
            th = max(tr.det_box[3] - tr.det_box[1], 1.0)
            # Кандидаты прогноза: последняя позиция и экстраполяция по двум последним
            # реальным детекциям (Калман на 5 FPS разгоняется слишком медленно).
            lx, ly = tr.center
            preds = [(lx, ly)]
            if len(tr.history) >= 2:
                (t0, *b0), (t1, *b1) = tr.history[-2], tr.history[-1]
                k_ = (t - t1) / max(t1 - t0, 1e-3)
                preds.append((lx + ((b1[0] + b1[2]) - (b0[0] + b0[2])) / 2 * k_,
                              ly + ((b1[1] + b1[3]) - (b0[1] + b0[3])) / 2 * k_))
            tw = max(tr.det_box[2] - tr.det_box[0], 1.0)
            fx, fy = (tr.det_box[0] + tr.det_box[2]) / 2, tr.det_box[3]      # точка опоры (ступни)
            for k, j in enumerate(det_idx):
                d = dets[j]
                if d.cls != tr.cls:
                    continue
                dcx, dcy = (d.x1 + d.x2) / 2, (d.y1 + d.y2) / 2
                if 0.6 < d.h / th < 1.6:
                    dist = min(np.hypot(dcx - px, dcy - py) for px, py in preds) / th
                    if dist < self.dist_gate * max(t - tr.t_last, 0.2) / 0.2:
                        cost[i, k] = dist
                        continue
                # Резкая смена формы рамки (падение, присел): ступни остаются почти на месте,
                # а рамка «ложится». Без этого человек при падении получал бы новый номер
                # и правило падения теряло бы историю.
                area_ratio = (d.w * d.h) / (tw * th)
                size = max(th, tw, d.h, d.w)
                foot_dist = np.hypot((d.x1 + d.x2) / 2 - fx, d.y2 - fy) / size
                center_dist = np.hypot(dcx - lx, dcy - ly) / size
                near = min(foot_dist, center_dist)
                if 0.15 < area_ratio < 6 and near < 0.6 and t - tr.t_last <= 1.0:
                    cost[i, k] = 0.5 + near
        r, c = linear_sum_assignment(cost)
        used = set()
        for i, k in zip(r, c):
            if cost[i, k] < 1e5:
                self._update_track(tracks[i], dets[det_idx[k]], t)
                used.add(det_idx[k])
        return [j for j in det_idx if j not in used]

    def _update_track(self, tr: Track, d: Detection, t: float) -> None:
        tr.kf.update(xyxy_to_xyah(d.xyxy))
        tr.det_box, tr.conf, tr.t_last = d.xyxy.copy(), d.conf, t
        tr.hits += 1
        tr.history.append((t, *map(float, d.xyxy)))

    def update(self, dets: List[Detection], t: float) -> List[Track]:
        """Возвращает подтверждённые треки, обновлённые на этом кадре."""
        dt = 1.0 if self._t_prev is None else max(t - self._t_prev, 1e-3)
        self._t_prev = t
        for tr in self.tracks:
            tr.kf.predict(dt)

        high = [d for d in dets if d.conf >= self.high]
        low = [d for d in dets if self.low <= d.conf < self.high]

        m1, um_tr, um_high = self._assign(self.tracks, high, self.match_iou)
        for i, j in m1:
            self._update_track(self.tracks[i], high[j], t)
        rest = [self.tracks[i] for i in um_tr]
        m2, um_rest, _ = self._assign(rest, low, self.low_match_iou)
        for i, j in m2:
            self._update_track(rest[i], low[j], t)

        # Этап 3: быстрые объекты при низком FPS обработки (5 к/с) смещаются больше
        # своей ширины, IoU = 0. Добираем по расстоянию центров в долях роста.
        rest3 = [rest[i] for i in um_rest]
        um_high = self._assign_by_distance(rest3, high, um_high, t)

        for j in um_high:
            d = high[j]
            if d.conf < self.new_thr:
                continue
            tr = Track(self._next_id, d.cls, d.label, KalmanXYAH(xyxy_to_xyah(d.xyxy)), d.conf, t, t, d.xyxy.copy())
            tr.history.append((t, *map(float, d.xyxy)))
            self._next_id += 1
            self.tracks.append(tr)

        self.tracks = [tr for tr in self.tracks if t - tr.t_last <= self.max_lost_s]
        return [tr for tr in self.tracks if tr.t_last == t and tr.hits >= self.min_hits]

    @property
    def alive_ids(self) -> set:
        return {tr.track_id for tr in self.tracks}
