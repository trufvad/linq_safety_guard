"""Конвейер видеоаналитики: по потоку на камеру, один общий движок инференса."""
from __future__ import annotations

import logging
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, List, Optional

import cv2
import numpy as np

from .config import PHONE_LABELS, PPE_LABELS, Settings
from .db import Database
from .events.dedup import IncidentDeduplicator
from .events.notify import TelegramNotifier
from .inference import InferenceEngine
from .rules import RULES, BaseRule, FrameContext
from .schemas import CameraConfig
from .tracking.bytetrack import ByteTracker
from .video.sources import open_source

log = logging.getLogger(__name__)
Listener = Callable[[dict], None]

RED, GREEN, ORANGE, YELLOW = (40, 40, 230), (80, 200, 80), (0, 160, 255), (0, 220, 255)


def now_local() -> datetime:
    return datetime.now().astimezone()


def _jsonable(o):
    """numpy-скаляры/массивы -> обычные типы Python (для JSON/WebSocket)."""
    if isinstance(o, dict):
        return {k: _jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_jsonable(v) for v in o]
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, np.generic):
        return o.item()
    return o


class CameraWorker:
    def __init__(self, cfg: CameraConfig, manager: "PipelineManager"):
        self.cfg = cfg
        self.m = manager
        self._new_cfg: Optional[CameraConfig] = None
        self._restart = False
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.tracker = ByteTracker()
        self.dedup = IncidentDeduplicator()
        self.rules: List[BaseRule] = []
        self._build_rules()
        self.last_frame: Optional[np.ndarray] = None
        self.last_jpeg: Optional[bytes] = None
        self.status, self.error = "stopped", None
        self.stats = {"fps": 0.0, "latency_ms": 0.0, "preprocess_ms": 0.0, "inference_ms": 0.0,
                      "postprocess_ms": 0.0, "pipeline_ms": 0.0, "tracks": 0, "frames": 0,
                      "suppressed_duplicates": 0, "engine": manager.engine.name}

    # --- управление ------------------------------------------------------
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._new_cfg, self._restart = None, False   # свежий старт уже читает актуальный cfg
        self._build_rules()
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True, name=f"cam-{self.cfg.id}")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        self.status = "stopped"

    def reload(self, cfg: CameraConfig) -> None:
        """Новые зоны/правила применяются на следующем кадре без остановки потока;
        смена source перезапускает чтение."""
        self._restart = self._restart or cfg.source != self.cfg.source
        self.cfg = cfg
        self._new_cfg = cfg

    def _build_rules(self) -> None:
        labels = self.m.settings.labels
        self.rules = []
        for rtype, cls in RULES.items():
            rc = self.cfg.rules.get(rtype)
            if (rc is not None and not rc.enabled) or not cls.available(labels):
                continue
            rule = cls(rc.params if rc else None)
            rule.schedule = rc.schedule if rc else None
            self.rules.append(rule)

    # --- основной цикл ---------------------------------------------------
    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self.status, self.error = "starting", None
                src = open_source(self.cfg.source, self.m.settings.process_fps)
                self.status = "running"
                restarted = False
                for frame in src.frames():
                    if self._stop.is_set():
                        break
                    if self._new_cfg is not None:
                        self._new_cfg = None
                        self._build_rules()
                        if self._restart:
                            self._restart, restarted = False, True
                            self.tracker, self.dedup = ByteTracker(), IncidentDeduplicator()
                            break
                    self.process(frame.image, frame.t)
                src.close()
                if not self._stop.is_set() and not restarted:
                    self.status = "finished"
                    return
            except Exception as e:  # noqa: BLE001
                log.exception("camera %s failed", self.cfg.id)
                self.status, self.error = "error", str(e)
                self._stop.wait(5.0)

    def process(self, img: np.ndarray, t: float) -> List[dict]:
        """Один кадр через весь конвейер. Возвращает созданные события (удобно для тестов)."""
        t0 = time.perf_counter()
        res = self.m.engine.detect(img)
        s = self.m.settings
        # пороги уверенности по классам: основной для людей/техники, пониженный для телефонов
        small = PPE_LABELS | PHONE_LABELS
        dets = [d for d in res.detections
                if d.conf >= (s.phone_conf if d.label in PHONE_LABELS else s.conf_thres)]
        tracks = self.tracker.update([d for d in dets if d.label not in small], t)
        persons = [tr for tr in tracks if tr.label == s.person_label]
        machines = [tr for tr in tracks if tr.label in s.machine_labels]
        others = [tr for tr in tracks if tr not in persons and tr not in machines]
        # СИЗ мелкие и мигают — для них берём сырые детекции, а не треки
        others += [_DetAsTrack(d) for d in dets if d.label in small]
        h, w = img.shape[:2]
        now = now_local()
        ctx = FrameContext(self.cfg, t, now, w, h, persons, machines, others, img)

        hits = []
        for rule in self.rules:
            sch = getattr(rule, "schedule", None)
            if sch is not None and not sch.is_active(now):
                continue
            for hit in rule.evaluate(ctx):
                hits.append(((self.cfg.id, hit.track.track_id, rule.type), (rule, hit), rule.confirm_seconds,
                             getattr(rule, "gap_tolerance_s", None)))
        dres = self.dedup.update(t, hits, self.tracker.alive_ids)

        violators = {k[1] for k in self.dedup.active} | {k[1] for k, _ in dres.opened}
        annotated = self._annotate(img, ctx, violators)
        created = []
        for key, (rule, hit) in dres.opened:
            ev = self._make_event(rule, hit, ctx, now)
            self.dedup.register(key, ev["id"], t)
            self.m.save_event(ev, img, annotated, hit.track.box)
            created.append(ev)
        for inc in dres.closed:
            self.m.close_event(inc.event_id, now)

        self.last_frame = img
        ok, buf = cv2.imencode(".jpg", annotated, [cv2.IMWRITE_JPEG_QUALITY, 75])
        if ok:
            self.last_jpeg = buf.tobytes()
        self._update_stats(res.timings, (time.perf_counter() - t0) * 1e3, len(tracks))
        return created

    # --- вспомогательное -------------------------------------------------
    def _make_event(self, rule: BaseRule, hit, ctx: FrameContext, now: datetime) -> dict:
        b = hit.track.box
        return {
            "id": uuid.uuid4().hex[:12],
            "camera_id": self.cfg.id, "camera_name": self.cfg.name, "area": self.cfg.area,
            "zone_id": hit.zone.id if hit.zone else None, "zone_name": hit.zone.name if hit.zone else None,
            "violation_type": rule.type, "title": hit.details.get("title", rule.title), "severity": rule.severity,
            "track_id": hit.track.track_id, "confidence": round(float(hit.track.conf), 3),
            "bbox": [round(float(b[0]) / ctx.frame_w, 4), round(float(b[1]) / ctx.frame_h, 4),
                     round(float(b[2]) / ctx.frame_w, 4), round(float(b[3]) / ctx.frame_h, 4)],
            "started_at": now.isoformat(timespec="seconds"), "ended_at": None,
            "status": "new", "comment": None,
            "details": _jsonable({k: v for k, v in hit.details.items() if k != "title"}),
        }

    def _annotate(self, img: np.ndarray, ctx: FrameContext, violators: set) -> np.ndarray:
        out = img.copy()
        overlay = out.copy()
        for z in self.cfg.zones:
            if not z.enabled:
                continue
            active = z.schedule is None or z.schedule.is_active(ctx.now)
            poly = ctx.zone_polygon_px(z).astype(np.int32)
            color = RED if z.kind != "machine" else ORANGE
            if active:
                cv2.fillPoly(overlay, [poly], color)
            cv2.polylines(out, [poly], True, color if active else (150, 150, 150), 2)
            cv2.putText(out, z.name, tuple(poly[0]), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        out = cv2.addWeighted(overlay, 0.18, out, 0.82, 0)
        for tr in ctx.persons + ctx.machines:
            x1, y1, x2, y2 = map(int, tr.box)
            color = RED if tr.track_id in violators and tr in ctx.persons else (GREEN if tr in ctx.persons else ORANGE)
            cv2.rectangle(out, (x1, y1), (x2, y2), color, 3 if color == RED else 2)
            cv2.putText(out, f"{tr.label} #{tr.track_id}", (x1, max(y1 - 6, 12)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)
        st = self.stats
        cv2.putText(out, f"{self.cfg.name} | {st['fps']:.1f} FPS | {st['latency_ms']:.0f} ms | {self.m.engine.name}",
                    (10, out.shape[0] - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.6, YELLOW, 2)
        return out

    def _update_stats(self, tm, pipeline_ms: float, ntracks: int) -> None:
        st, a = self.stats, 0.2
        now = time.perf_counter()
        prev = getattr(self, "_t_prev_frame", None)
        self._t_prev_frame = now
        if prev:
            st["fps"] = (1 - a) * st["fps"] + a * (1.0 / max(now - prev, 1e-6))
        for k, v in (("preprocess_ms", tm.preprocess_ms), ("inference_ms", tm.inference_ms),
                     ("postprocess_ms", tm.postprocess_ms), ("latency_ms", tm.total_ms), ("pipeline_ms", pipeline_ms)):
            st[k] = round((1 - a) * st[k] + a * v, 2) if st["frames"] else round(v, 2)
        st["fps"] = round(st["fps"], 2)
        st["tracks"], st["frames"] = ntracks, st["frames"] + 1
        st["suppressed_duplicates"] = self.dedup.suppressed


class _DetAsTrack:
    """Обёртка детекции СИЗ с интерфейсом трека (label/box/center)."""

    track_id = -1

    def __init__(self, d):
        self.label, self.box, self.conf = d.label, d.xyxy, d.conf

    @property
    def center(self):
        return float((self.box[0] + self.box[2]) / 2), float((self.box[1] + self.box[3]) / 2)


class PipelineManager:
    def __init__(self, settings: Settings, engine: InferenceEngine, db: Database):
        self.settings, self.engine, self.db = settings, engine, db
        self.workers: Dict[str, CameraWorker] = {}
        self.listeners: List[Listener] = []
        self.snap_dir = settings.data_dir / "snapshots"
        self.raw_dir = settings.data_dir / "raw"
        for d in (self.snap_dir, self.raw_dir):
            d.mkdir(parents=True, exist_ok=True)
        self.telegram = TelegramNotifier(settings.telegram_token, settings.telegram_chat_id)

    def emit(self, msg: dict) -> None:
        for fn in list(self.listeners):
            try:
                fn(msg)
            except Exception:  # noqa: BLE001
                log.exception("listener failed")

    def add_camera(self, cfg: CameraConfig, start: bool = True) -> CameraWorker:
        if cfg.id in self.workers:
            self.workers[cfg.id].reload(cfg)
            return self.workers[cfg.id]
        w = self.workers[cfg.id] = CameraWorker(cfg, self)
        if start and cfg.enabled:
            w.start()
        return w

    def remove_camera(self, cam_id: str) -> None:
        w = self.workers.pop(cam_id, None)
        if w:
            w.stop()

    def stop_all(self) -> None:
        for w in self.workers.values():
            w.stop()

    def save_event(self, ev: dict, raw: np.ndarray, annotated: np.ndarray, box) -> None:
        snap = annotated.copy()
        x1, y1, x2, y2 = map(int, box)
        cv2.rectangle(snap, (x1, y1), (x2, y2), RED, 4)
        cv2.putText(snap, ev["title"], (x1, max(y1 - 28, 24)), cv2.FONT_HERSHEY_SIMPLEX, 0.8, RED, 2)
        ok, buf = cv2.imencode(".jpg", snap, [cv2.IMWRITE_JPEG_QUALITY, 85])
        jpeg = buf.tobytes() if ok else b""
        (self.snap_dir / f"{ev['id']}.jpg").write_bytes(jpeg)
        cv2.imwrite(str(self.raw_dir / f"{ev['id']}.jpg"), raw)          # чистый кадр — для дообучения
        self.db.insert_event(ev)
        ev = {**ev, "snapshot_url": f"/api/events/{ev['id']}/snapshot.jpg"}
        self.emit({"type": "event.created", "data": ev})
        self.telegram.send_incident(ev, jpeg)

    def close_event(self, event_id: str, now: datetime) -> None:
        ev = self.db.update_event(event_id, ended_at=now.isoformat(timespec="seconds"))
        if ev:
            self.emit({"type": "event.updated", "data": ev})

    def snapshot_paths(self, event_id: str) -> tuple[Path, Path]:
        return self.snap_dir / f"{event_id}.jpg", self.raw_dir / f"{event_id}.jpg"
