"""Источники кадров: видеофайл, RTSP/веб-камера, папка стоп-кадров.

Каждый кадр несёт метку времени `t` (сек). Для файлов это время по видео
(номер кадра / fps), поэтому правила «N секунд» работают одинаково при любой
скорости обработки. Для RTSP — реальное время.
"""
from __future__ import annotations

import glob
import os
import time
from dataclasses import dataclass, field
from typing import Iterator, List, Optional

import cv2
import numpy as np


@dataclass
class Frame:
    image: np.ndarray
    t: float                 # секунды от начала потока
    index: int


class FrameSource:
    def frames(self) -> Iterator[Frame]:
        raise NotImplementedError

    def close(self) -> None:
        pass


class VideoSource(FrameSource):
    """Файл (.mp4/.avi), RTSP/HTTP-URL или индекс веб-камеры ("0")."""

    def __init__(self, uri: str, process_fps: float = 5.0, loop: bool = True, realtime: bool = True):
        self.uri = uri
        self.is_file = os.path.isfile(uri)
        self.process_fps = process_fps
        self.loop = loop and self.is_file
        self.realtime = realtime            # файл проигрывается в темпе живой камеры
        self.cap: Optional[cv2.VideoCapture] = None

    def _open(self) -> cv2.VideoCapture:
        src = int(self.uri) if self.uri.isdigit() else self.uri
        cap = cv2.VideoCapture(src, cv2.CAP_FFMPEG) if isinstance(src, str) and src.startswith("rtsp") else cv2.VideoCapture(src)
        if not cap.isOpened():
            raise RuntimeError(f"cannot open video source {self.uri}")
        return cap

    def frames(self) -> Iterator[Frame]:
        idx, t_offset = 0, 0.0
        while True:
            self.cap = self._open()
            src_fps = self.cap.get(cv2.CAP_PROP_FPS) or 25.0
            step = max(1, int(round(src_fps / self.process_fps))) if self.is_file else 1
            start, last_emit, n, t = time.monotonic(), -1e9, 0, 0.0
            while True:
                ok, img = self.cap.read()
                if not ok:
                    break
                if self.is_file:
                    t = t_offset + n / src_fps
                    n += 1
                    if (n - 1) % step:
                        continue
                    if self.realtime:
                        delay = (t - t_offset) - (time.monotonic() - start)
                        if delay > 0:
                            time.sleep(delay)
                else:
                    t = time.monotonic() - start
                    if t - last_emit < 1.0 / self.process_fps:   # прореживание живого потока
                        continue
                    last_emit = t
                yield Frame(img, t, idx)
                idx += 1
            self.cap.release()
            if not self.loop:
                if not self.is_file:          # RTSP оборвался — переподключаемся
                    time.sleep(2.0)
                    continue
                return
            t_offset = t + 1.0 / src_fps

    def close(self) -> None:
        if self.cap is not None:
            self.cap.release()


class ImageFolderSource(FrameSource):
    """Папка стоп-кадров: кадры идут с шагом 1/process_fps по времени."""

    def __init__(self, folder: str, process_fps: float = 5.0, loop: bool = True):
        exts = ("*.jpg", "*.jpeg", "*.png", "*.bmp")
        self.paths: List[str] = sorted(p for e in exts for p in glob.glob(os.path.join(folder, e)))
        if not self.paths:
            raise RuntimeError(f"no images in {folder}")
        self.dt, self.loop = 1.0 / process_fps, loop

    def frames(self) -> Iterator[Frame]:
        idx = 0
        while True:
            for p in self.paths:
                img = cv2.imread(p)
                if img is not None:
                    yield Frame(img, idx * self.dt, idx)
                    idx += 1
                    time.sleep(self.dt)
            if not self.loop:
                return


def open_source(uri: str, process_fps: float = 5.0, realtime: bool = True, loop: bool = True) -> FrameSource:
    if os.path.isdir(uri):
        return ImageFolderSource(uri, process_fps, loop=loop)
    return VideoSource(uri, process_fps, loop=loop, realtime=realtime)
