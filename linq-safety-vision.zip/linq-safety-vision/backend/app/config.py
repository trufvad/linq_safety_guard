"""Настройки из переменных окружения и файла .env (см. .env.example в корне проекта)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List


def _load_dotenv() -> None:
    """Минимальный загрузчик .env без внешних зависимостей.

    Ищет .env в текущей папке и в родительской (корень проекта). Переменные,
    уже заданные в окружении (docker-compose, командная строка), не перезаписываются.
    """
    for candidate in (Path.cwd() / ".env", Path.cwd().parent / ".env"):
        if not candidate.is_file():
            continue
        for raw in candidate.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            value = value.split(" #", 1)[0].strip().strip('"').strip("'")
            os.environ.setdefault(key.strip(), value)
        return


_load_dotenv()

COCO_LABELS = [
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat",
    "traffic light", "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog",
    "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella",
    "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard", "sports ball", "kite",
    "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle",
    "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
    "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch", "potted plant",
    "bed", "dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard", "cell phone",
    "microwave", "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors",
    "teddy bear", "hair drier", "toothbrush",
]


def _env_list(name: str, default: str) -> List[str]:
    return [s.strip() for s in os.getenv(name, default).split(",") if s.strip()]


APP_VERSION = "1.5.0"


@dataclass
class Settings:
    engine: str = os.getenv("ENGINE", "auto")                 # auto | tpu | onnx | tpu_sim | remote
    model_path: str = os.getenv("MODEL_PATH", "../models/yolov5s.onnx")
    tpu_program: str = os.getenv("TPU_PROGRAM", "../models/yolov5s_cut_b1_o1_h1m.tpu")
    remote_url: str = os.getenv("REMOTE_URL", "http://127.0.0.1:8500")
    remote_token: str = os.getenv("REMOTE_TOKEN", "")          # API-токен JupyterHub для REMOTE_URL через прокси
    input_name: str = os.getenv("INPUT_NAME", "images")
    input_size: int = int(os.getenv("INPUT_SIZE", "640"))
    conf_thres: float = float(os.getenv("CONF_THRES", "0.35"))
    # телефон в руке мелкий, модель видит его с меньшей уверенностью — свой порог
    phone_conf: float = float(os.getenv("PHONE_CONF", "0.2"))
    iou_thres: float = float(os.getenv("IOU_THRES", "0.45"))
    # Если подключите модель людей+СИЗ — перечислите её классы через запятую
    labels: List[str] = field(default_factory=lambda: _env_list("LABELS", ",".join(COCO_LABELS)))
    person_label: str = os.getenv("PERSON_LABEL", "person")
    machine_labels: List[str] = field(default_factory=lambda: _env_list("MACHINE_LABELS", "truck,car,bus,forklift"))
    process_fps: float = float(os.getenv("PROCESS_FPS", "5"))

    data_dir: Path = Path(os.getenv("DATA_DIR", "data"))
    db_path: Path = Path(os.getenv("DB_PATH", "data/events.db"))
    cameras_file: Path = Path(os.getenv("CAMERAS_FILE", "cameras.json"))
    uploads_dir: Path = Path(os.getenv("UPLOADS_DIR", "uploads"))
    frontend_dist: Path = Path(os.getenv("FRONTEND_DIST", "../frontend/dist"))
    max_upload_mb: int = int(os.getenv("MAX_UPLOAD_MB", "2048"))
    cors_origins: List[str] = field(default_factory=lambda: _env_list("CORS_ORIGINS", "*"))

    telegram_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID", "")

    @property
    def keep_class_ids(self) -> List[int]:
        wanted = {self.person_label, *self.machine_labels, *[l for l in self.labels if l in PPE_LABELS | PHONE_LABELS]}
        return [i for i, l in enumerate(self.labels) if l in wanted]


# Классы СИЗ, которые понимает правило ppe (если они есть в модели)
PPE_LABELS = {"helmet", "hardhat", "vest", "safety_vest", "respirator", "mask"}
# Мелкие предметы при человеке: берутся сырыми детекциями (не треками), со своим порогом уверенности
PHONE_LABELS = {"cell phone"}

settings = Settings()
