"""Загрузка локальных видеофайлов и подключение их к конвейеру как камер.

POST   /api/videos            multipart: file + (mode=new: name, area) | (mode=replace: camera_id)
GET    /api/videos            список загруженных файлов
DELETE /api/videos/{file_id}  удалить файл (если к нему не подключена камера)

Файл сохраняется в UPLOADS_DIR потоково (кусками по 1 МБ), проверяется
OpenCV (открывается, читается первый кадр), после чего становится источником
камеры: VideoSource проигрывает его по кругу в темпе живой камеры, кадры идут
через детектор, трекер и правила, а разметка — во фронтенд по MJPEG/WebSocket.
"""
from __future__ import annotations

import re
import time
import uuid
from pathlib import Path
from typing import Callable, Literal, Optional

import cv2
from fastapi import APIRouter, File, Form, HTTPException, UploadFile

from .schemas import CameraConfig

ALLOWED_EXT = {".mp4", ".avi", ".mkv", ".mov", ".m4v", ".webm"}
CHUNK = 1024 * 1024


def _safe_name(name: str) -> str:
    stem, ext = Path(name).stem, Path(name).suffix.lower()
    stem = re.sub(r"[^\w\-. ]+", "_", stem, flags=re.UNICODE).strip(" ._") or "video"
    return f"{stem[:60]}{ext}"


def probe_video(path: Path) -> dict:
    """Проверить, что OpenCV читает файл, и вернуть его параметры."""
    cap = cv2.VideoCapture(str(path))
    try:
        if not cap.isOpened():
            raise ValueError("OpenCV не открыл файл: формат или кодек не поддерживается")
        ok, frame = cap.read()
        if not ok or frame is None:
            raise ValueError("не удалось прочитать ни одного кадра")
        fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
        frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        h, w = frame.shape[:2]
        return {"width": w, "height": h, "fps": round(fps, 2), "frames": frames,
                "duration_s": round(frames / fps, 1) if fps > 0 and frames > 0 else None}
    finally:
        cap.release()


def create_router(get_manager: Callable, get_db: Callable, settings) -> APIRouter:
    router = APIRouter(prefix="/api/videos", tags=["videos"])
    uploads: Path = settings.uploads_dir
    uploads.mkdir(parents=True, exist_ok=True)

    def _info(p: Path) -> dict:
        cams = [w.cfg.id for w in get_manager().workers.values() if Path(w.cfg.source).resolve() == p.resolve()]
        st = p.stat()
        return {"id": p.name, "name": p.name.split("__", 1)[-1], "path": str(p), "size_mb": round(st.st_size / 2**20, 2),
                "uploaded_at": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(st.st_mtime)), "cameras": cams}

    @router.get("")
    def list_videos():
        files = sorted((p for p in uploads.iterdir() if p.suffix.lower() in ALLOWED_EXT),
                       key=lambda p: p.stat().st_mtime, reverse=True)
        return [_info(p) for p in files]

    @router.post("", status_code=201)
    async def upload_video(
        file: UploadFile = File(...),
        mode: Literal["new", "replace"] = Form("new"),
        camera_id: Optional[str] = Form(None),
        name: Optional[str] = Form(None),
        area: str = Form("Цех 1"),
    ):
        filename = file.filename or "video.mp4"
        ext = Path(filename).suffix.lower()
        if ext not in ALLOWED_EXT:
            raise HTTPException(415, f"поддерживаются {', '.join(sorted(ALLOWED_EXT))}")
        mgr = get_manager()
        if mode == "replace" and (not camera_id or camera_id not in mgr.workers):
            raise HTTPException(404, "камера для замены источника не найдена")

        dest = uploads / f"{uuid.uuid4().hex[:8]}__{_safe_name(filename)}"
        limit, size = settings.max_upload_mb * 2**20, 0
        try:
            with dest.open("wb") as out:
                while chunk := await file.read(CHUNK):
                    size += len(chunk)
                    if size > limit:
                        raise HTTPException(413, f"файл больше {settings.max_upload_mb} МБ")
                    out.write(chunk)
            meta = probe_video(dest)
        except HTTPException:
            dest.unlink(missing_ok=True)
            raise
        except ValueError as e:
            dest.unlink(missing_ok=True)
            raise HTTPException(422, str(e))
        finally:
            await file.close()

        if mode == "replace":
            w = mgr.workers[camera_id]
            cfg = w.cfg.model_copy(update={"source": str(dest), "enabled": True})
            w.reload(cfg)
            w.start()
        else:
            cam_id = f"video-{uuid.uuid4().hex[:6]}"
            cfg = CameraConfig(id=cam_id, name=(name or Path(filename).stem)[:80], source=str(dest), area=area)
            w = mgr.add_camera(cfg)
        get_db().save_camera(w.cfg.id, w.cfg.model_dump_json())
        return {"video": {**_info(dest), **meta}, "camera_id": w.cfg.id}

    @router.delete("/{file_id}", status_code=204)
    def delete_video(file_id: str):
        p = (uploads / file_id).resolve()
        if p.parent != uploads.resolve() or not p.is_file():
            raise HTTPException(404, "файл не найден")
        if _info(p)["cameras"]:
            raise HTTPException(409, "файл используется камерой — сначала удалите или переключите камеру")
        p.unlink()

    return router
