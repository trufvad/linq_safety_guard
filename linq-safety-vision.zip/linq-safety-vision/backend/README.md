# Бэкенд видеоаналитики ТБ на LinQ TPU (Участник 2)

```
кадр (OpenCV: видеофайл / RTSP / папка с кадрами)
  └─ InferenceEngine.detect ── препроцессинг (CPU) → сеть (ONNX | LinQ TPU | удалённый TPU) → декод голов + NMS (CPU)
       └─ ByteTracker (track_id, история позиций)
            └─ правила-плагины (BaseRule): опасная зона · сближение с техникой · падение · бег · нет СИЗ
                 └─ таймер подтверждения + кэш инцидентов (camera_id, track_id, violation_type)
                      └─ SQLite журнал · WebSocket · стоп-кадр · Telegram мастеру
```

## Запуск

```bash
pip install -r requirements.txt
export $(grep -v '^#' .env.example | xargs)        # или свои значения

ENGINE=auto uvicorn app.main:app --host 0.0.0.0 --port 8000          # TPU, если есть; иначе ONNX (по умолчанию)
ENGINE=onnx MODEL_PATH=../models/yolov5s.onnx uvicorn app.main:app --port 8000
ENGINE=tpu  TPU_PROGRAM=../models/yolov5s_cut_b1_o1_h1m.tpu uvicorn app.main:app --port 8000
```

Проверить `.tpu` без ускорителя: `ENGINE=tpu_sim` (ONNX + int8-квантование выходов по шкалам из паспорта `.tpu`).

Если бэкенд работает не на сервере LinQ, а TPU — там: на сервере
`python tpu_worker/server.py --program /auto/cache/$LOGIN/yolov5s_detector.tpu --port 8500`,
у себя `ENGINE=remote REMOTE_URL=http://<сервер>:8500`. Проверка протокола без TPU: `--dry-run`.

Прогон видео без API (чек-поинт, наполнение БД): 
`python -m scripts.run_video --source video.mp4 --zones zones.json --out out.mp4`

Тесты: `python tests/test_core.py` (или `pytest -q`), сквозной тест запущенного сервера — `python tests/test_api_e2e.py`.

## Контракт с Участником 1 (модель)

| | |
|---|---|
| Вход | `{"images": float32 (1, 3, 640, 640)}`, RGB, `/255.0` → [0, 1] |
| Ресайз | letterbox с сохранением пропорций, паддинг 114 — **калибровать квантование этой же функцией** (`app/inference/preprocess.py`) |
| Выход TPU | три сырые головы `(1, 255, 80/40/20, …)`; NCHW или NHWC, порядок ключей — любой, определяются автоматически |
| NMS | на CPU в бэкенде (`app/inference/postprocess.py`) |

Для yolo5s в главе 6 документации (сноска 5) граф обрезан до `onnx::Shape_327`, `onnx::Shape_663`, `onnx::Shape_999` — выходы трёх свёрток головы (в ONNX Ultralytics v7: `/model.24/m.{0,1,2}/Conv_output_0`). Если в `.tpu` вошёл хвост Detect, int8 обрежет координаты — см. корневой README. Узлы `/model.21/Div_1_output_0`, `/model.21/Sigmoid_output_0` относятся к сноске 4 — это **yolo12m**, не наш YOLOv5s.

## Загрузка видео

`POST /api/videos` (multipart, `app/videos.py`): файл потоково пишется в `UPLOADS_DIR`, проверяется OpenCV и становится источником новой или существующей камеры. `VideoSource` проигрывает его по кругу в темпе живой камеры (`PROCESS_FPS`), так что правила «N секунд» работают как на настоящем потоке.

Весь проект целиком (с фронтендом, Docker и скриптами) запускается из корня: `./start.sh` или `start.bat`, см. корневой README.

## Как добавить правило

Новый файл `app/rules/my_rule.py`:

```python
from .base import BaseRule, RuleHit, register_rule

@register_rule
class NightPresence(BaseRule):
    type, title, severity = "night_presence", "Человек в цехе ночью", "warning"
    def evaluate(self, ctx):
        return [RuleHit(p) for p in ctx.persons]
```

Конвейер, API и UI подхватят его автоматически (`GET /api/rules`), расписание — `schedule` в конфиге камеры.

## Правила и пороги

| Правило | Логика | Подтверждение |
|---|---|---|
| `danger_zone` | ступни (низ-центр бокса) внутри полигона, с учётом расписания зоны | 2 с |
| `machine_proximity` | зазор до бокса техники < 0.3 роста человека, или человек в зоне `kind=machine` | 1.5 с |
| `fall` | W/H > 1.2 после вертикальной позы и смещение центра < 0.25 роста за 3 с | 0.5 с (+3 с внутри правила) |
| `running` | скорость ступней > 1.6 роста/с на окне 1 с | 1.5 с |
| `no_ppe` | нет бокса каски в верхних 35% контура человека; **нужна модель с классами СИЗ** | 3 с |

Пороги в ростах человека, а не пикселях — правила одинаково работают на ближних и дальних камерах. Все меняются через `params` из UI.
Кратковременный пропуск до 0.6 с не сбрасывает таймер; инцидент закрывается через 4 с без нарушения, повтор того же ключа подавляется ещё 10 с.

## Бенчмарк

```bash
ENGINE=tpu TPU_PROGRAM=... python -m scripts.benchmark --image samples/bus.jpg --iters 200 --streams 1 2 4 8
```

Печатает пре/инференс/пост, FPS, p95-задержку для 1…N потоков и ёмкость ускорителя (камер при 5 к/с) → `benchmark_<engine>.json` для калькулятора Участника 4.
Опорная точка: ONNX Runtime на CPU — 8.7 к/с, 104 мс на инференс (1 поток, 640×640).
