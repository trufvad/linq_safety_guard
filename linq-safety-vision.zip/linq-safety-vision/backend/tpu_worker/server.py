"""TPU-воркер: запускается на сервере LinQ (терминал Jupyter), держит .tpu открытой
и отвечает на POST /infer. Только стандартная библиотека + numpy + pytpu.

    python tpu_worker/server.py --program /auto/cache/$LOGIN/yolov5s_detector.tpu --port 8500

Протокол:
    POST /infer   тело = .npy тензора float32 (1,3,640,640), заголовок X-Input-Name (по умолчанию images)
                  ответ = .npz со всеми выходами TPU (сырые головы, до NMS)
    GET  /health  {"status":"ok","outputs":{name:shape},"infer_ms":...}

Бэкенд подключается так: ENGINE=remote REMOTE_URL=http://<host>:8500
"""
from __future__ import annotations

import argparse
import io
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np


class TpuRunner:
    def __init__(self, program: str, device_index: int = 0, dry_run: bool = False):
        self.lock = threading.Lock()
        self.last_ms = 0.0
        self.calls = 0
        self.outputs_info = {}
        if dry_run:   # проверка протокола без ускорителя: случайные головы YOLOv5s
            self.infer = lambda x: {f"head{i}": np.random.randn(1, 255, s, s).astype(np.float32) - 4
                                    for i, s in enumerate((80, 40, 20))}
            return
        import pytpu as tpu
        from contextlib import ExitStack

        devices = tpu.Device.list_devices()
        assert devices, "TPU not found, check ls /dev/tpu*"
        self._stack = ExitStack()
        dev = self._stack.enter_context(tpu.Device.open(devices[device_index]))
        prog = self._stack.enter_context(dev.load(program))
        self._inference = self._stack.enter_context(prog.inference())
        self.infer = lambda x: self._inference.sync(x)

    def run(self, name: str, tensor: np.ndarray) -> dict:
        with self.lock:
            t0 = time.perf_counter()
            out = self.infer({name: tensor})
            self.last_ms = (time.perf_counter() - t0) * 1e3
            self.calls += 1
        self.outputs_info = {k: list(np.asarray(v).shape) for k, v in out.items()}
        return out


def make_handler(runner: TpuRunner):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):  # тише в консоли
            pass

        def _send(self, code: int, body: bytes, ctype: str):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Infer-Ms", f"{runner.last_ms:.2f}")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path.startswith("/health"):
                body = json.dumps({"status": "ok", "calls": runner.calls, "infer_ms": round(runner.last_ms, 2),
                                   "outputs": runner.outputs_info}).encode()
                self._send(200, body, "application/json")
            else:
                self._send(404, b"not found", "text/plain")

        def do_POST(self):
            if not self.path.startswith("/infer"):
                return self._send(404, b"not found", "text/plain")
            try:
                n = int(self.headers.get("Content-Length", 0))
                x = np.load(io.BytesIO(self.rfile.read(n)), allow_pickle=False).astype(np.float32)
                out = runner.run(self.headers.get("X-Input-Name", "images"), x)
                buf = io.BytesIO()
                np.savez(buf, **{k: np.asarray(v) for k, v in out.items()})
                self._send(200, buf.getvalue(), "application/octet-stream")
            except Exception as e:  # noqa: BLE001
                self._send(500, str(e).encode(), "text/plain")

    return H


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--program", default="yolov5s_detector.tpu")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8500)
    ap.add_argument("--device", type=int, default=0)
    ap.add_argument("--dry-run", action="store_true", help="без TPU, случайные выходы")
    a = ap.parse_args()
    runner = TpuRunner(a.program, a.device, a.dry_run)
    print(f"TPU worker on http://{a.host}:{a.port}  program={a.program}  dry_run={a.dry_run}")
    ThreadingHTTPServer((a.host, a.port), make_handler(runner)).serve_forever()
