@echo off
rem LinQ Safety Vision - запуск двойным щелчком (Windows).
rem
rem   start.bat          запустить (Python, если есть; иначе Docker Desktop) и открыть браузер
rem   start.bat docker   запустить в Docker
rem   start.bat stop     остановить Docker-контейнер
rem   start.bat reset    очистить журнал, статистику, камеры и загруженные видео
rem
rem Всё работает на одном адресе: http://localhost:8000 (порт меняется в .env: PORT=...)
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title LinQ Safety Vision
set "MODE=%~1"
if "%MODE%"=="" set "MODE=auto"

if not exist ".env" (
  copy /Y ".env.example" ".env" >nul
  echo [ok] создан файл настроек .env
)
for %%D in (data uploads models .run) do if not exist "%%D" mkdir "%%D"

set "PORT=8000"
for /f "usebackq tokens=1,* delims==" %%A in (".env") do (
  if /i "%%A"=="PORT" if not "%%B"=="" set "PORT=%%B"
)
set "URL=http://localhost:%PORT%"

if /i "%MODE%"=="stop" ( docker compose down & goto :end )
if /i "%MODE%"=="reset" goto :reset

rem ---- если на порту уже работает LinQ Safety Vision (например, старая версия) - останавливаем её ----
powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 'http://127.0.0.1:%PORT%/api/health' | Out-Null; exit 0 } catch { exit 1 }" >nul 2>&1
if not errorlevel 1 (
  echo ^> найдена ранее запущенная копия программы - перезапускаю...
  powershell -NoProfile -Command "$ids = Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique; foreach ($i in $ids) { Get-Process -Id $i -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'python*' } | Stop-Process -Force -ErrorAction SilentlyContinue }; Start-Sleep -Seconds 2"
)
powershell -NoProfile -Command "try { $c = New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1', %PORT%); $c.Close(); exit 0 } catch { exit 1 }" >nul 2>&1
if not errorlevel 1 (
  echo [x] Порт %PORT% занят другой программой. Укажите другой порт в файле .env: PORT=8010
  goto :fail
)

rem ---- браузер открывается сразу: страница запуска сама перейдёт в программу, когда сервер будет готов ----
>".run\port.js" echo window.LINQ_PORT=%PORT%;
start "" "%~dp0frontend\loading.html"
if /i "%MODE%"=="docker" goto :docker

rem ---- ищем Python 3.10+ ----
call :find_python
if defined PY goto :python

rem ---- нет Python: Docker Desktop? ----
docker info >nul 2>&1 && (echo [ok] Python не найден, запускаю в Docker & goto :docker)

echo.
echo [!] Для работы нужен Python 3.10 или новее (или Docker Desktop).
where winget >nul 2>&1
if errorlevel 1 goto :manual_python
choice /C YN /M "Установить Python автоматически сейчас"
if errorlevel 2 goto :manual_python
winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
if errorlevel 1 goto :manual_python
rem после установки PATH текущего окна не обновился - ищем установленный Python напрямую
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY="%LOCALAPPDATA%\Programs\Python\Python312\python.exe""
if not defined PY call :find_python
if defined PY goto :python

:manual_python
echo.
echo Установите Python: https://www.python.org/downloads/
echo При установке отметьте галочку "Add python.exe to PATH", затем снова запустите start.bat
start "" "https://www.python.org/downloads/"
goto :fail

rem =========================== Python ===========================
:python
for /f "delims=" %%V in ('%PY% --version 2^>^&1') do echo [ok] %%V

if not exist ".venv\Scripts\python.exe" (
  echo ^> создаю виртуальное окружение ^(.venv^)...
  %PY% -m venv .venv || (echo [x] не удалось создать окружение & goto :fail)
)
set "VPY=.venv\Scripts\python.exe"
set "REQHASH="
for /f "delims=" %%H in ('certutil -hashfile backend\requirements.txt SHA256 ^| findstr /v ":"') do if not defined REQHASH set "REQHASH=%%H"
set "OLDHASH="
if exist ".venv\requirements.sha" set /p OLDHASH=<".venv\requirements.sha"
if not "%SKIP_INSTALL%"=="1" if not "!REQHASH!"=="!OLDHASH!" (
  echo ^> первый запуск: устанавливаю компоненты ^(2-5 минут, нужен интернет^)...
  "%VPY%" -m pip install --upgrade pip -q
  "%VPY%" -m pip install -r backend\requirements.txt -q || (echo [x] не удалось установить компоненты - проверьте интернет и запустите снова & goto :fail)
  >".venv\requirements.sha" echo !REQHASH!
)
echo [ok] компоненты установлены



echo.
echo ==============================================================
echo   LinQ Safety Vision:  %URL%
echo   Программа откроется в браузере. Чтобы остановить - закройте это окно.
echo ==============================================================
echo.
cd backend
set "DATA_DIR=..\data"
set "DB_PATH=..\data\events.db"
set "UPLOADS_DIR=..\uploads"
set "FRONTEND_DIST=..\frontend\dist"
"..\%VPY%" -m uvicorn app.main:app --host 0.0.0.0 --port %PORT% --no-use-colors
cd ..
echo.
echo [!] Сервер остановлен.
goto :fail

rem =========================== Docker ===========================
:docker
docker compose version >nul 2>&1 || (echo [x] Docker Desktop не найден или не запущен & goto :fail)
echo ^> сборка и запуск контейнера ^(первый раз - несколько минут^)...
docker compose up --build -d || (echo [x] docker compose завершился с ошибкой & goto :fail)
echo ^> жду готовности...
powershell -NoProfile -Command "for($i=0;$i -lt 180;$i++){ try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 'http://127.0.0.1:%PORT%/api/health' | Out-Null; exit 0 } catch { Start-Sleep 1 } }; exit 1"
if errorlevel 1 (docker compose logs --tail 60 app & echo [x] сервис не поднялся & goto :fail)
echo [ok] готово: %URL%     остановить: start.bat stop
goto :end

rem ---- поиск Python 3.10+ ----
:find_python
rem сначала версии, под которые точно есть готовые пакеты ONNX Runtime / OpenCV
set "PY="
where py >nul 2>&1 || goto :find_python_plain
for %%V in (3.12 3.11 3.13 3.10) do (
  if not defined PY py -%%V -c "import sys" >nul 2>&1 && set "PY=py -%%V"
)
if defined PY exit /b 0
py -3 -c "import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>&1 && set "PY=py -3"
if defined PY exit /b 0
:find_python_plain
where python >nul 2>&1 && python -c "import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>&1 && set "PY=python"
exit /b 0

:reset
powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 'http://127.0.0.1:%PORT%/api/health' | Out-Null; exit 0 } catch { exit 1 }" >nul 2>&1
if not errorlevel 1 (
  echo ^> останавливаю запущенную программу...
  powershell -NoProfile -Command "$ids = Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique; foreach ($i in $ids) { Get-Process -Id $i -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'python*' } | Stop-Process -Force -ErrorAction SilentlyContinue }; Start-Sleep -Seconds 2"
)
echo Будут удалены: журнал нарушений, статистика, снимки, подключённые камеры и загруженные видео.
choice /C YN /M "Очистить все данные"
if errorlevel 2 goto :end
if exist "data" rd /s /q "data"
if exist "uploads" rd /s /q "uploads"
mkdir "data" & mkdir "uploads"
echo [ok] Данные очищены. Запустите start.bat
goto :fail

:fail
echo.
pause
exit /b 1

:end
endlocal
